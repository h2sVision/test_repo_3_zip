/* ============================================================
   manage.js — the five-rung canvas, and the public page
   ============================================================ */

const RUNGS = [
  ['design',  'Initiative page',        'what it is, and how it looks'],
  ['process', 'Participant journey', 'what they do, in order'],
  ['timeline','Timeline',           'when each part happens'],
  ['approval','Approval',            'H2S checks it, then it goes out'],
  ['live',    'Live',                'while it runs'],
  ['result',  'Result',              'who won, and how it was decided']
];

const MG = {

  /* ---------------- shell ---------------- */
  render(p, rung, step){
    /* The manage shell now carries the same identity strip the initiative page
       uses — name, state, address — so walking into Manage does not feel like
       walking into a different product. "See the public page" was a large ghost
       button competing with the H1 while saying the same thing as the address
       beside it; the address is now the link. */
    const url = 'hack2skill.com/p/' + p.slug;
    const published = p.state === 'live' || p.state === 'closed' || p.visibility === 'public';
    const st = { live:['ok','Live'], draft:['warn','In draft'],
                 unscoped:['warn','Not scoped yet'], closed:['','Closed'] }[p.state];
    const body =
      '<div class="mghead"><div class="wrap wide" style="padding-top:20px;padding-bottom:0">' +
        '<div class="crumb"><a href="#/initiatives">Initiatives</a><i>&#8250;</i>' +
          '<a href="#/p/' + p.id + '">' + esc(p.name) + '</a><i>&#8250;</i>' +
          '<span style="color:var(--ink);font-weight:500">' +
          RUNGS.find(r => r[0] === rung)[1] + '</span></div>' +
        '<div class="mgtitle">' +
          '<div style="min-width:0">' +
            '<h1 style="font-size:26px;font-weight:900">' + esc(p.name) + '</h1>' +
            '<div class="mgmeta">' +
              '<span class="pill ' + (st[0] || '') + '"' +
                (st[0] ? '' : ' style="background:var(--line-soft);color:var(--muted)"') + '>' +
                (p.state === 'live' ? '<span style="display:inline-block;width:6px;height:6px;' +
                  'border-radius:50%;background:var(--ok);margin-right:6px"></span>' : '') +
                st[1] + '</span>' +
              (published
                ? '<a class="mgurl" href="#/public/' + p.id + '">' + ic('globe',14,1.8) +
                  '<span class="num">' + esc(url) + '</span></a>'
                : '<span class="mgurl off">' + ic('globe',14,1.8) +
                  '<span class="num">' + esc(url) + '</span>' +
                  '<span style="font-size:11px;color:var(--faint)">not published yet</span>' +
                  '</span>') +
            '</div>' +
          '</div>' +
        '</div>' +
        MG.ladder(p, rung) +
      '</div></div>' +
      '<div class="mgbody">' + MG[rung](p, step) + '</div>';
    return V.chrome(body, 'initiatives', true);
  },

  /* one config row: a label, the control, and what that control resolves to —
     "0 days after start" is arithmetic; "5 Oct 2026" is an answer */
  cfg(cells){ return '<div class="cfg">' + cells.join('') + '</div>'; },
  cfgNum(label, k, control, resolved){
    return '<div class="cfgf"><span class="cfgl">' + label + '</span>' +
      '<span class="cfgv">' + control + '</span>' +
      '<span class="cfgr">' + (resolved || '') + '</span></div>';
  },

  ladder(p, active){
    /* Chevron stepper: two chained groups of arrow-shaped tabs — Initiative
       page → Participant journey → Timeline → Approval, then a gap, then
       Live → Result (the two that become true on their own rather than being
       walked through). chevfirst/chevlast strip the notch/point at each
       chain's open end so the arrows read as one continuous flow. */
    return '<div class="ladder">' + RUNGS.map((r, i) => {
      const st = M.rungState(p, r[0]);
      const dormant = (st === 'idle');
      const dot = st === 'done' ? 'done' : st === 'todo' ? 'todo' : st === 'on' ? 'done' : 'idle';
      const chevfirst = (i === 0 || i === 4);
      const chevlast = (i === 3 || i === 5);
      return (i === 4 ? '<span class="hair"></span>' : '') +
        '<a class="rung' + (active === r[0] ? ' on' : '') + (dormant ? ' dormant' : '') +
        (chevfirst ? ' chevfirst' : '') + (chevlast ? ' chevlast' : '') +
        '" href="#/p/' + p.id + '/manage/' + r[0] + '">' +
        '<span style="display:flex;align-items:center;gap:8px"><span class="rd ' + dot +
        '"></span><span class="rt">' + r[1] + '</span></span>' +
        '<span class="rs">' + MG.rungSub(p, r[0], r[2]) + '</span></a>';
    }).join('') + '</div>';
  },
  rungSub(p, k, fallback){
    if(k === 'process') return p.modules.length + ' modules in the flow';
    if(k === 'timeline'){
      const d = M.dated(p).length;
      return d === p.modules.length && d ? 'all ' + d + ' dated' : d + ' of ' + p.modules.length + ' dated';
    }
    return fallback;
  },
  ladderNote(rung){
    if(rung === 'process') return 'What happens, and in what order.';
    if(rung === 'timeline') return 'Only <b>when</b>. The list itself comes from the journey.';
    if(rung === 'approval') return 'One handoff. Nothing here is yours to fill in.';
    if(rung === 'live') return 'Nobody authored this. It became true on its own.';
    if(rung === 'result') return 'Open early, so the rules are settled before the leaderboard is.';
    return 'Nothing is locked. Go in any order.';
  },

  /* =============== DESIGN PAGE =============== */
  design(p, step){
    step = step || 'details';
    const steps = M.designSteps(p);
    if(!steps.some(s => s.id === step)) step = 'details';
    const rail = '<div><div class="lbl" style="padding:0 12px 8px">Initiative page</div>' +
      steps.map(s => {
        const done = M.stepDone(p, s.id);
        return '<a class="sn' + (step === s.id ? ' on' : '') + '" href="#/p/' + p.id +
          '/manage/design/' + s.id + '" style="justify-content:flex-start">' +
          '<span class="sd ' + (done ? 'done' : (s.id === 'branding' || s.id === 'partners' ? '' : 'todo')) + '">' +
          (done ? '<svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="#fff" ' +
            'stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round">' + ICON.tick +
            '</svg>' : '') + '</span><span>' + s.name + '</span>' +
          (s.from ? '<span class="tag" style="margin-left:auto;color:' +
            (s.id === 'venue' ? 'var(--warn)' : 'var(--faint)') + '">' + s.from +
            '</span>' : '') + '</a>';
      }).join('') +
      '<p style="margin:14px 12px 0;font-size:11.5px;color:var(--faint)">Format decides this list. ' +
        'Hybrid and in-person add <b>Venue</b>.</p></div>';

    /* the rail, then one white sheet capped at a readable measure — a form field
       whose underline runs 1,400px has no shape and nothing to scan against */
    return '<div class="wrap wide mgwrap" style="display:grid;' +
      'grid-template-columns:212px minmax(0,1fr);gap:26px;align-items:start">' +
      rail + '<div class="mgsheet' + (step === 'preview' ? ' wide' : '') + '">' +
        MG.designStep(p, step) + '</div></div>';
  },

  designStep(p, step){
    const F = (label, hint, bind, val) =>
      '<div class="f"><label>' + label + '</label><div class="hint">' + hint + '</div>' +
      '<input class="in" data-bind="' + bind + '" value="' + esc(val) + '"></div>';

    if(step === 'format'){
      const modes = [['virtual','Virtual','Nothing to book, nowhere to be'],
                     ['hybrid','Hybrid','Online, with a finale in one place'],
                     ['inperson','In person','Everyone in the room']];
      const e = M.entry(p);
      return MG.head('Format','Answered first, because it changes what the rest of this rung asks for.') +
        '<div class="sec"><div class="lbl" style="margin-bottom:11px">Where it happens</div>' +
        '<div class="row">' + modes.map(m =>
          '<button class="chip' + (p.format.mode === m[0] ? ' on' : '') + '" data-act="fmt" ' +
          'data-v="' + m[0] + '">' + m[1] + '</button>').join('') + '</div>' +
        '<p class="note">' + (p.format.mode
          ? (p.format.mode === 'virtual'
             ? 'Venue has left the rail. Not disabled — gone.'
             : 'Venue is in the rail now, tagged FROM FORMAT.')
          : 'Nothing chosen yet.') + '</p></div>' +

        '<div class="sec"' + (e.paid ? '' : ' style="border-bottom:0"') + '>' +
          '<div class="lbl" style="margin-bottom:11px">Cost to enter</div>' +
          '<div class="row">' +
            '<button class="chip' + (e.paid ? '' : ' on') + '" data-act="paid" data-v="free">' +
              'Free to enter</button>' +
            '<button class="chip' + (e.paid ? ' on' : '') + '" data-act="paid" data-v="paid">' +
              'Paid entry</button>' +
          '</div>' +
        '</div>' +

        (e.paid ?
          '<div class="sec" style="border-bottom:0">' +

            /* one labelled block per decision, stacked. A three-across grid wrapped
               its chips and left the labels out of line. */
            '<div style="display:grid;grid-template-columns:168px minmax(0,1fr);gap:22px 26px;' +
              'align-items:start">' +

              '<div><div style="font-size:13px;font-weight:600">Fee</div>' +
                '<div style="font-size:12px;color:var(--faint);margin-top:3px;line-height:1.45">' +
                'What a participant pays.</div></div>' +
              /* one money control: the currency is part of the amount, not five
                 buttons beside it. The list grows without the layout moving. */
              '<div><div style="display:inline-flex;align-items:baseline;gap:2px;' +
                'border-bottom:1px solid var(--line);padding-bottom:2px">' +
                '<select class="sel" data-bind="fee.currency" style="font-size:14px;' +
                  'font-family:\'IBM Plex Mono\',monospace;color:var(--muted);' +
                  'padding:4px 16px 4px 0">' +
                  CATALOGUE.currencies.map(c => '<option value="' + c[0] + '"' +
                    (e.currency === c[0] ? ' selected' : '') + '>' + c[0] + '</option>').join('') +
                '</select>' +
                '<input class="in num" data-bind="fee.amount" value="' + esc(e.fee) +
                  '" inputmode="numeric" style="width:104px;flex:none;border-bottom:0;' +
                  'font-size:15px;padding:4px 0">' +
              '</div>' +
              '<div style="font-size:11.5px;color:var(--faint);margin-top:6px">' +
                esc(M.currency(e.currency)[2]) + '</div></div>' +

              '<div><div style="font-size:13px;font-weight:600">Charged per</div>' +
                '<div style="font-size:12px;color:var(--faint);margin-top:3px;line-height:1.45">' +
                'An entry is a team, or a solo participant.</div></div>' +
              '<div class="row" style="gap:6px">' +
                [['entry','Entry'],['member','Team member']].map(v =>
                  '<button class="chip' + (e.per === v[0] ? ' on' : '') + '" data-act="per" ' +
                  'data-v="' + v[0] + '">' + v[1] + '</button>').join('') + '</div>' +

              '<div><div style="font-size:13px;font-weight:600">Works out as</div>' +
                '<div style="font-size:12px;color:var(--faint);margin-top:3px;line-height:1.45">' +
                'What the page will say.</div></div>' +
              '<div style="font-size:15px;font-weight:600">' + esc(M.feeLine(p)) + '</div>' +

            '</div>' +

            '<div class="card" style="margin-top:24px">' +
              '<div class="lbl">What a fee changes</div>' +
              '<div style="margin-top:10px;display:flex;flex-direction:column;gap:11px;' +
                'font-size:13px;line-height:1.6">' +
                '<div><strong>Registration gains a payment step.</strong> ' +
                  '<span style="color:var(--muted)">An entry is not counted, and does not appear ' +
                  'in Participants, until the payment clears.</span></div>' +
                '<div><strong>Every Register button quotes the price.</strong> ' +
                  '<span style="color:var(--muted)">Along with a Cost row in Key facts. A price ' +
                  'found late is the commonest reason a registration is abandoned.</span></div>' +
                '<div><strong>H2S collects and settles.</strong> ' +
                  '<span style="color:var(--muted)">There is no payment account to connect here; ' +
                  DB.org.manager.name + ' sets the settlement terms with your finance team.' +
                  '</span></div>' +
              '</div>' +
              '<p class="note">Changing the fee after registration opens does not re-charge or ' +
                'refund anyone. Whoever paid, paid what was shown on the day.</p>' +
            '</div>' +
          '</div>'
        : '');
    }

    if(step === 'details'){
      return MG.head('Initiative details','') +
        '<div class="sec">' +
          F('Initiative name','','name',p.name) +
          F('Tagline','','tagline',p.tagline) +
        '</div>' +
        '<div class="sec"><div class="f" style="margin-bottom:0"><label>Initiative URL</label>' +
          '<div class="hint">Reserved now, resolves once H2S publishes it.</div>' +
          '<div style="display:flex;align-items:center;gap:8px">' +
          '<span class="num" style="font-size:13px;color:var(--muted)">hack2skill.com/p/</span>' +
          '<input class="in" data-bind="slug" value="' + esc(p.slug) + '" style="flex-grow:1"></div>' +
          '<p style="margin:8px 0 0;font-size:12px;color:var(--ok)">Available.</p></div></div>' +
        '<div class="sec" style="border-bottom:0"><div class="lbl" style="margin-bottom:11px">Who ' +
          'can find it</div><div class="row">' +
          [['public','Public on the network'],['private','Private to your organisation']].map(v =>
            '<button class="chip' + (p.visibility === v[0] ? ' on' : '') + '" data-act="vis" ' +
            'data-v="' + v[0] + '">' + v[1] + '</button>').join('') + '</div>' +
          '<p class="note">' + (p.visibility === 'public'
            ? 'It appears in the Initiatives listing and anyone on the network can join.'
            : 'Only people you invite can see it.') + '</p></div>';
    }

    if(step === 'venue'){
      /* what a participant actually needs to get there: what the place is called,
         where it is, and anything about arriving. "City" alone was on the card
         and the public page while the address field had no country and no
         arrival note — enough to name a venue, not enough to reach one. */
      const fm = p.format;
      const req = '<span class="rq" aria-label="required">*</span>';
      return MG.head('Venue','Venue details.') +
        '<div class="sec">' +
          '<div class="f"><label>Venue name' + req + '</label>' +
            '<div class="hint">What it is called &#8212; the name on the sign.</div>' +
            '<input class="in" data-bind="venue.name" value="' + esc(fm.venueName || '') +
            '" placeholder="ICC Academy"></div>' +
          '<div class="f"><label>Street address</label>' +
            '<div class="hint">Building and street, as a map would take it.</div>' +
            '<input class="in" data-bind="venue" value="' + esc(fm.venue || '') + '"></div>' +
          '<div class="two">' +
            '<div class="f" style="margin-bottom:0"><label>City' + req + '</label>' +
              '<div class="hint">Shown on the card and the public page.</div>' +
              '<input class="in" data-bind="city" value="' + esc(fm.city || '') + '"></div>' +
            '<div class="f" style="margin-bottom:0"><label>Country' + req + '</label>' +
              '<div class="hint">Entrants use it to work out visas and travel.</div>' +
              '<input class="in" data-bind="venue.country" value="' + esc(fm.country || '') +
              '"></div>' +
          '</div>' +
          '<div class="f" style="margin-top:22px"><label>Getting there</label>' +
            '<div class="hint">Nearest metro, parking, which gate to use.</div>' +
            '<input class="in" data-bind="venue.directions" value="' +
            esc(fm.directions || '') + '"></div>' +
        '</div>' +
        /* the one thing the fields are for: what a participant ends up reading */
        '<div class="vpv"><div class="lbl">On the public page</div>' +
          '<div class="vpvb">' + ic('pin',15,1.8) +
            '<span><span class="vpvn">' +
            (esc(fm.venueName) || '<span class="fnt">Venue name</span>') + '</span>' +
            '<span class="vpva">' +
            ([fm.venue, fm.city, fm.country].filter(Boolean).map(esc).join(', ') ||
              '<span class="fnt">Address, city, country</span>') + '</span>' +
            '<span class="vpvd"' + (fm.directions ? '' : ' style="display:none"') + '>' +
              esc(fm.directions || '') + '</span>' +
            '</span></div></div>';
    }

    if(step === 'about') return MG.about(p);
    if(step === 'branding') return MG.branding(p);

    if(step === 'problems'){
      /* A problem statement is a paragraph, not a caption. The body was a
         single-line <input>: you could type into it forever and only ever see
         the last few words, and the card on the public page carries far more
         than one line. Each statement is now a card — a number, a one-line
         title, and a textarea that grows with what you write. */
      return MG.head('Problem statements','What you want solved. One card each, and the ' +
        'list a participant picks from when they submit.') +
        '<div class="sec">' +
        (p.focus.length
          ? '<div class="pslist">' + p.focus.map((f, i) =>
              '<div class="pscard">' +
                '<span class="psn num">' + (i + 1) + '</span>' +
                '<div style="min-width:0">' +
                  '<input class="in psti" data-bind="focus.' + i + '.title" value="' +
                    esc(f.title) + '" placeholder="Name the problem in a few words">' +
                  '<textarea class="in psbd" rows="3" data-bind="focus.' + i + '.body" ' +
                    'placeholder="Describe it properly &#8212; what is broken today, who it ' +
                    'affects, and what a good answer would look like.">' + esc(f.body) +
                    '</textarea>' +
                '</div>' +
                '<button class="ic psx" data-act="delfocus" data-i="' + i +
                  '" aria-label="Remove this statement">' + ic('x',12,2.2) + '</button>' +
              '</div>').join('') + '</div>'
          : '<div class="psempty">Nothing set yet. Each statement becomes a card a ' +
            'participant can pick when they submit.</div>') +
        '<button class="link" data-act="addfocus" style="display:inline-flex;align-items:center;' +
          'gap:7px;margin-top:15px">' + ic('plus',12,2.4) + 'Add a statement</button>' +
        '</div>';
    }

    if(step === 'focus') return MG.focus(p);

    if(step === 'prizes')   return MG.head('Prizes','What winners get.') + MG.prizes(p, true);
    if(step === 'partners') return MG.head('Partners','') + MG.partners(p);
    if(step === 'sections') return MG.sections(p);
    if(step === 'preview')  return MG.preview(p);
    return '';
  },

  head(t, b){
    return '<div><h2 style="font-size:19px;font-weight:700">' + t + '</h2>' +
      '<p style="margin:7px 0 0;font-size:13px;color:var(--muted);max-width:74ch">' + b + '</p></div>';
  },
  /* ---- Focus area: the tags, from the fixed H2S vocabulary ---- */
  focus(p){
    const picked = p.tags || [];
    const chip = t => {
      const on = picked.indexOf(t) > -1;
      return '<button class="tagchip' + (on ? ' on' : '') + '" data-act="tag" data-t="' +
        esc(t) + '">' + (on ? ic('tick',11,2.8) : '') + esc(t) + '</button>';
    };
    const use = (h, b) => '<div style="padding:11px 0;border-bottom:1px solid var(--line-soft)">' +
      '<div style="font-size:13.5px;font-weight:600">' + h + '</div>' +
      '<div style="font-size:12.5px;color:var(--muted);margin-top:3px;line-height:1.55">' + b +
      '</div></div>';

    return MG.head('Focus area','The subjects this initiative is about.') +

      '<div class="sec">' +
        '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px">' +
          '<div class="lbl">Tags</div>' +
          '<span style="font-size:12px;color:var(--faint)">' +
            (picked.length ? picked.length + ' picked' : '') + '</span></div>' +
        CATALOGUE.tags.map(g =>
          '<div style="margin-top:16px">' +
          '<div style="font-size:11px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;' +
            'color:var(--faint)">' + esc(g.g) + '</div>' +
          '<div style="display:flex;flex-wrap:wrap;gap:7px;margin-top:9px">' +
            g.t.map(chip).join('') + '</div></div>').join('') +
        '<button class="link" data-act="reqtag" style="display:inline-flex;align-items:center;' +
          'gap:7px;margin-top:18px">' + ic('plus',12,2.4) + 'Ask H2S to add a tag</button>' +
      '</div>' +

      '<div class="card" style="margin-top:20px">' +
        '<div class="lbl">What the tags do</div>' +
        '<div style="margin-top:6px">' +
        use('They show on the public page',
            'A row under the title, so someone scanning the page knows in two seconds whether ' +
            'it is for them.') +
        use('They match against innovator profiles',
            picked.length
              ? '<strong>' + M.n(M.tagMatch(p)) + '</strong> of your ' + M.n(DB.reach.total) +
                ' registered innovators have declared at least one of these interests.'
              : 'Pick a tag and this becomes a number — how many of your registered innovators ' +
                'have declared that interest.') +
        use('They suggest mentors and evaluators',
            'When you build the panel, people tagged the same way come to the top of the list ' +
            'instead of you searching by name.') +
        use('They filter and report',
            'Across initiatives: what the portfolio is actually about, and how each subject performs.') +
        '</div>' +
        '<p style="margin:14px 0 0;font-size:12px;color:var(--faint)">Tags describe the ' +
        'initiative, not the individual problem statements. A participant picks a statement when ' +
        'they submit; the tags are how the initiative is found in the first place.</p>' +
      '</div>';
  },

  /* ---- Branding ---- */
  branding(p){
    const b = M.brand(p);
    const css = M.coverCss(p);
    const isImg = !!(b.cover && b.cover.kind === 'image');

    const drop = '<div data-drop="cover" style="border:1px dashed var(--line);' +
      'border-radius:var(--r);background:' + (css || 'var(--bg-soft)') + ';height:190px;' +
      'display:grid;place-items:center;text-align:center;position:relative;overflow:hidden">' +
      (css
        ? '<div style="position:absolute;inset:0;background:rgba(16,18,35,.34)"></div>' +
          '<div style="position:relative;color:#fff">' +
            '<div style="font-size:13.5px;font-weight:600">' + esc(M.coverName(p)) + '</div>' +
            '<div style="font-size:12px;opacity:.8;margin-top:3px">Drop a new image to replace it' +
            '</div></div>'
        : '<div style="color:var(--muted);font-size:13.5px">Drop an image here, or ' +
          '<label style="color:var(--primary);font-weight:600;cursor:pointer">choose a file' +
          '<input type="file" accept="image/*" data-bind="branding.file" hidden></label>' +
          '<div style="font-size:12px;color:var(--faint);margin-top:4px">1600 &times; 600 or ' +
          'larger &#183; JPG or PNG &#183; up to 1.5 MB</div></div>') +
      '</div>';

    return MG.head('Branding','The cover a participant sees first, and the colour the page is ' +
      'built from.') +

      '<div class="sec">' +
        '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px">' +
          '<div class="lbl">Cover</div>' +
          (b.cover
            ? '<div style="display:flex;gap:14px">' +
              '<label class="link" style="cursor:pointer">Replace' +
                '<input type="file" accept="image/*" data-bind="branding.file" hidden></label>' +
              '<button class="link" data-act="clearcover" style="color:var(--faint)">Remove' +
              '</button></div>'
            : '') + '</div>' +
        '<div style="margin-top:12px">' + drop + '</div>' +

        '<div class="lbl" style="margin:20px 0 10px">Or pick a preset</div>' +
        '<div style="display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px">' +
          CATALOGUE.covers.map((c, ci) => {
            const on = !isImg && b.cover && b.cover.value === c[1];
            return '<button data-act="cover" data-i="' + ci + '" title="' + esc(c[0]) + '" ' +
              'style="height:52px;border-radius:var(--r);background:' + c[1] + ';border:2px solid ' +
              (on ? 'var(--ink)' : 'transparent') + ';box-shadow:0 0 0 1px var(--line);' +
              'cursor:pointer;padding:0"></button>';
          }).join('') + '</div>' +
        '<p class="note">Presets rather than stock photography: a gradient never looks like ' +
          'somebody else\'s hackathon.</p>' +
      '</div>' +

      '<div class="sec" style="border-bottom:0">' +
        '<div class="lbl" style="margin-bottom:10px">Accent colour</div>' +
        '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' +
          CATALOGUE.accents.map(a =>
            '<button data-act="accent" data-v="' + a + '" title="' + a + '" ' +
            'style="width:30px;height:30px;border-radius:50%;background:' + a + ';cursor:pointer;' +
            'border:2px solid ' + (b.accent === a ? 'var(--ink)' : 'transparent') + ';' +
            'box-shadow:0 0 0 1px var(--line);padding:0"></button>').join('') +
          '<span class="num" style="font-size:12px;color:var(--muted);margin-left:6px">' +
            esc(b.accent) + '</span>' +
        '</div>' +
        '<p class="note">Buttons, links and the register bar on the public page take this colour. ' +
          'Everything else stays neutral so the cover does the talking.</p>' +
      '</div>';
  },

  /* ---- About ---- */
  about(p){
    const empty = !p.about.body.length && !p.about.html;
    if(empty) return MG.head('About','') +
      '<div class="mgrid" style="margin-top:22px">' +
        MG.aboutCard('Write it','Headings, lists, images, links. What most initiatives use, and it is ' +
          'enough for most of them.','Start writing →','startabout',false,true) +
        MG.aboutCard('Paste HTML','For a page that needs a timeline, a comparison table or an ' +
          'embed. Scripts come out; your CSS stays, scoped to this section.','Open the HTML editor →',
          'starthtml',false,false) +
        MG.aboutCard('Ask the agent','Describe the page and it writes the HTML from your real dates, ' +
          'prizes and problem statements. You edit every line afterwards.',
          'Ask ' + DB.org.manager.name.split(' ')[0] + ' to switch it on →','agent',true,false) +
      '</div>' +
      '<div style="margin-top:22px;padding-top:20px;border-top:1px solid var(--line-soft);' +
        'display:flex;align-items:center;gap:16px;flex-wrap:wrap">' +
        '<span style="font-size:13px"><b>Or leave it empty.</b> The section simply does not appear.</span></div>';

    const isHtml = p.about.mode === 'html';
    return '<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;' +
      'flex-wrap:wrap">' + MG.head('About','Text, or HTML when the page needs to do more than read.') +
      '<div style="display:flex;gap:3px;background:var(--line-soft);padding:3px;border-radius:4px">' +
      '<button class="chip' + (!isHtml ? ' on' : '') + '" data-act="aboutmode" data-v="text" ' +
        'style="border-radius:2px">Rich text</button>' +
      '<button class="chip' + (isHtml ? ' on' : '') + '" data-act="aboutmode" data-v="html" ' +
        'style="border-radius:2px">HTML</button>' +
      '<span class="chip" style="border-radius:2px;color:var(--faint);display:inline-flex;gap:6px;' +
        'align-items:center">' + ic('lock',11,2) + 'With the agent</span></div></div>' +
      '<div class="sec">' +
        '<div class="f"><label>Section title</label>' +
        '<input class="in" data-bind="about.title" value="' + esc(p.about.title) + '"></div>' +
        (isHtml
          ? '<div class="f"><label>Your HTML</label><div class="hint">Scripts and forms come out on save. Your CSS stays, scoped.</div>' +
            '<textarea class="in" data-bind="about.html" rows="10" style="font-family:\'IBM Plex ' +
            'Mono\',monospace;font-size:12.5px;border:1px solid var(--line);border-radius:3px;' +
            'padding:12px">' + esc(p.about.html) + '</textarea></div>'
          : '<div class="f"><label>Body</label><div class="hint">One paragraph per line.</div>' +
            '<textarea class="in" data-bind="about.text" rows="8">' +
            esc(p.about.body.join('\n')) + '</textarea></div>') +
      '</div>' +
      '<div class="sec" style="border-bottom:0"><div class="lbl" style="margin-bottom:10px">' +
        'On the page</div>' +
        '<div class="card">' + PUB.about(p) + '</div></div>';
  },
  aboutCard(t, b, cta, act, locked, primary){
    return '<button class="tcard" data-act="' + act + '" style="' +
      (primary ? 'border-color:var(--primary)' : '') + '">' +
      '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
      '<span style="font-size:14.5px;font-weight:700;letter-spacing:-.015em">' + t + '</span>' +
      (locked ? '<span class="pill warn" style="font-size:10.5px;padding:3px 9px;display:inline-flex;' +
        'align-items:center;gap:5px">' + ic('lock',11,2) + 'Locked</span>' : '') + '</div>' +
      '<div style="font-size:12.5px;color:var(--muted);line-height:1.55;flex-grow:1">' + b + '</div>' +
      '<div style="font-size:12.5px;font-weight:600;color:' + (locked ? 'var(--warn)' : 'var(--primary)') +
      '">' + cta + '</div></button>';
  },

  /* ---- page sections ---- */
  sections(p){
    const c = M.sectionCounts(p);
    const rows = M.editableSections(p);
    /* the bullet is the same three-state marker the Live preview uses, so a row
       says whether it is ready before you read a word of it. Drag stays; Move
       up / Move down sit beside it because drag-only reordering has no keyboard
       or single-pointer path (WCAG 2.2 AA). */
    return MG.head('Page sections','What a participant sees, and in what order.') +
      '<div class="sec" style="padding-top:20px;border-bottom:0">' +
        '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:10px;' +
          'margin-bottom:10px"><div class="lbl">In this order</div>' +
          '<span class="num" style="font-size:11.5px;color:var(--faint)">' + c.ready +
          ' ready &#183; ' + c.waiting + ' waiting &#183; ' + c.off + ' off</span></div>' +
        rows.map((s, si) => {
          const st = M.sectionState(p, s.id);
          /* two states, because there are only two answers: it is filled, or it
             is not. Amber covers both "nothing in it yet" and "switched off". */
          const filled = st.state === 'ready';
          return '<div data-drag="sec" data-di="' + si + '" class="secrow">' +
            '<span class="ic"' + (s.locked ? '' : ' data-grip') + '>' +
              (s.locked ? ic('lock',11,2) : GRIPSVG) + '</span>' +
            '<span class="secdot ' + (filled ? 'ready' : 'waiting') + '" title="' +
              (filled ? 'Filled' : 'Not filled yet') + '"></span>' +
            '<span style="min-width:0">' +
              '<span class="secnm' + (st.state === 'off' ? ' off' : '') + '">' + s.name + '</span>' +
              '<span class="secsub">' + st.sub + '</span></span>' +

            (s.locked ? '<span class="sw lock"><i></i></span>'
                      : '<button class="sw' + (M.sectionOn(p, s.id) ? ' on' : '') +
                        '" data-act="sect" data-v="' + s.id + '" aria-pressed="' +
                        M.sectionOn(p, s.id) + '"><i></i></button>') + '</div>';
        }).join('') +
        '<p style="margin:14px 0 0 11px;font-size:11.5px;color:var(--faint)">Switching one off ' +
          'never deletes what is behind it.</p>' +
      '</div>';
  },

  /* ---- live preview ---- */
  preview(p){
    const c = M.sectionCounts(p);
    const blockers = M.publishBlockers(p);
    const meter = [];
    for(let i = 0; i < c.ready; i++)   meter.push('var(--ok)');
    for(let i = 0; i < c.waiting; i++) meter.push('#f0d9ac');
    for(let i = 0; i < c.off; i++)     meter.push('var(--line)');
    return '<div style="display:flex;justify-content:flex-end">' +
      '<a class="btn" href="#/public/' + p.id + '">' + ic('eye',14,2) + 'Open full size</a></div>' +
      '<div class="sec" style="padding-top:20px;border-bottom:0">' +
      '<div>' +
        '<div style="min-width:0">' +
          /* one honest mode: exactly what would render today, nothing marked,
             nothing implied — the section list to the left already says what's
             still waiting, so the frame itself doesn't need a second, softer mode */
          '<div class="ban' + (MG.verdict(p).ok ? '' : ' warn') + '" style="margin-bottom:14px' +
            (MG.verdict(p).ok ? ';background:var(--ok-soft)' : '') + '">' +
            '<span class="dot" style="background:var(--' +
              (MG.verdict(p).ok ? 'ok' : 'warn') + ')"></span>' +
            '<span style="font-size:13px">' + MG.verdict(p).text + '</span></div>' +

          '<div class="frame">' +
            '<div class="ubar"><span style="width:9px;height:9px;border-radius:50%;' +
              'background:var(--line)"></span><span style="width:9px;height:9px;border-radius:50%;' +
              'background:var(--line)"></span><span style="width:9px;height:9px;border-radius:50%;' +
              'background:var(--line)"></span>' +
              '<div class="url">hack2skill.com/p/' + esc(p.slug) +
              '<span style="margin-left:auto;color:var(--warn);font-size:9.5px;' +
              'letter-spacing:.1em">' + (p.state === 'live' ? 'LIVE' : 'DRAFT') +
              '</span></div></div>' +
            PUB.body(p, false) +
          '</div>' +
        '</div>' +
      '</div>';
  },




  verdict(p){ return M.previewVerdict(p); },

  /* =============== PROCESS SETUP =============== */
  process(p, sel){
    sel = (sel && p.modules.indexOf(sel) > -1) ? sel : p.modules[0];
    /* Literally the Initiative page sub-rail: same .sn/.sd classes, same 212px rail,
       same lbl header, same footnote typography. Reordering and removal still
       work — the grip is just faint until the row is hovered, so the list reads
       as cleanly as the one on the Initiative page while remaining draggable. */
    const rail = '<div><div class="lbl" style="padding:0 12px 8px">Participant journey</div>' +
      p.modules.map((k, i) => {
        const ready = M.moduleReady(p, k);
        const anchor = k === 'registration';
        const on = sel === k;
        return '<a class="sn' + (on ? ' on' : '') + '" href="#/p/' + p.id +
          '/manage/process/' + k + '" style="justify-content:flex-start;position:relative;gap:8px" ' +
          'data-drag="mod" data-di="' + i + '">' +
          (anchor
            ? '<span class="mgrip" style="color:var(--line);cursor:default" ' +
              'title="Registration is always first">' + GRIPSVG + '</span>'
            : '<span class="mgrip" data-grip title="Drag to reorder">' + GRIPSVG + '</span>') +
          '<span class="sd ' + (ready || anchor ? 'done' : 'todo') + '" style="margin-left:1px">' +
            (ready || anchor ? ic('tick',9,3.2) : '') + '</span>' +
          '<span style="flex-grow:1;min-width:0;overflow:hidden;text-overflow:ellipsis;' +
            'white-space:nowrap" title="' + esc(M.mod(k).name) + '">' + M.mod(k).name + '</span>' +
          (anchor ? '<span class="tag" style="color:var(--primary)" title="Always first">first</span>'
            : (!ready ? '<span class="tag" style="color:var(--warn)" title="Needs setting up">todo' +
              '</span>' : '')) +
          (anchor ? '<span class="xx" style="color:var(--faint);margin-left:6px" ' +
            'title="cannot be removed">' + ic('lock',12,2) + '</span>'
            : '<button class="xx" data-act="delmod" data-k="' + k + '" style="margin-left:6px">' +
              ic('x',13,2.2) + '</button>') + '</a>';
      }).join('') +
      '<p style="margin:14px 12px 0;font-size:11.5px;color:var(--faint)">Started from the <b>' +
        M.type(p).name + '</b> default. Registration stays first.</p>' +

      /* "Add a module" belongs to the rail it extends, not a third column floating
         beside the content — it sits directly under the list it adds to, with its
         own divider and label so it reads as one rail: the flow, then how to grow it. */
      '<div style="margin:18px 12px 0;padding-top:16px;border-top:1px solid var(--line-soft)">' +
        '<div class="lbl">Add a module</div>' +
        '<p style="margin:7px 0 0;font-size:12px;color:var(--faint)">Drops in at the end. Move it, ' +
          'then configure it.</p>' +
        '<div style="display:flex;flex-direction:column;gap:7px;margin-top:11px">' +
          M.bucket(p).map(k =>
          '<button class="bk" data-act="addmod" data-k="' + k + '" style="width:100%;' +
          'box-sizing:border-box;justify-content:flex-start">' + ic('plus',12,2.4) +
          M.mod(k).name + '</button>').join('') + '</div>' +
      '</div></div>';

    return '<div class="wrap wide mgwrap" style="display:grid;' +
      'grid-template-columns:212px minmax(0,1fr);gap:26px;align-items:start">' +
      rail +
      '<div class="mgsheet">' + MG.modPanel(p, sel) + '</div></div>' +
      '<div class="wrap wide" style="padding-top:0"><div class="card" style="display:flex;' +
        'align-items:center;gap:16px;flex-wrap:wrap;background:var(--bg-soft)">' +
        '<div style="min-width:300px;flex-grow:1;max-width:74ch">' +
        '<strong style="font-size:14px">The Timeline is built from this list</strong>' +
        '<p style="margin:6px 0 0;font-size:13px;color:var(--muted)">' + p.modules.length +
          ' modules here, ' + p.modules.length + ' dates there. Remove one and its date goes with ' +
          'it.</p></div>' +
        '<a class="btn p" href="#/p/' + p.id + '/manage/timeline">Go to the Timeline ' +
          '&#8594;</a></div></div>';
  },

  modPanel(p, k){
    const c = p.config[k] = p.config[k] || {};
    const head = '<div class="lbl" style="margin-bottom:7px">Configuring</div>' +
      '<h2 style="font-size:19px;font-weight:700;margin-bottom:2px">' + M.mod(k).name + '</h2>';
    /* Registration drops the "Configuring" eyebrow — the h2 becomes the sheet's
       true first child, so .mgsheet > h2:first-child zeroes its top margin and
       "Registration" sits flush with the card edge instead of floating a
       half-line above "Registration form". */
    const headReg = '<h2 style="font-size:19px;font-weight:700;margin-bottom:2px">' +
      M.mod(k).name + '</h2>';

    if(k === 'registration'){
      const aud = [['anyone','Anyone on the network'],['students','Students'],
                   ['professionals','Professionals'],['freelancers','Freelancers']];
      c.audience = c.audience || ['anyone'];
      c.fields = c.fields || [];
      const editing = !!(APP.ui.fieldEdit && APP.ui.fieldEdit.registration);
      return headReg +
        '<div class="sec" style="padding-top:16px">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px">' +
          '<div class="lbl">Registration form</div>' + MG.editToggle('registration', editing) +
          '</div>' +
          '<div style="margin-top:14px">' +
            (editing ? '<div class="fr h"><span></span><span>Field</span><span>Type</span>' +
              '<span>Rule</span><span></span></div>' : '') +
            CATALOGUE.platformFields.map(f => MG.fieldRow(f, null, 'registration', editing)).join('') +
            c.fields.map((f, i) => MG.fieldRow(f, i, 'registration', editing)).join('') + '</div>' +
            (editing ? '<button class="link" data-act="addfield" style="display:inline-flex;' +
              'align-items:center;gap:7px;margin:13px 0 0 27px">' + ic('plus',12,2.4) +
              'Add field</button>' : '') +
        '</div>' +
        '<div class="sec"><div class="lbl" style="margin-bottom:11px">Who can register</div>' +
          '<div class="row">' + aud.map(a =>
            '<button class="chip' + (c.audience.indexOf(a[0]) > -1 ? ' on' : '') + '" ' +
            'data-act="aud" data-v="' + a[0] + '">' + a[1] + '</button>').join('') + '</div>' +
          '<p class="note">The last three combine, and they read <b>Occupation</b>.</p></div>' +
        '<div class="sec"><div class="two">' +
          '<div class="f" style="margin-bottom:0"><label>Cap on entries</label>' +
            '<div class="hint">Registration closes itself when it is hit.</div>' +
            '<input class="in num" data-bind="cfg.registration.cap" value="' + (c.cap || '') + '"></div>' +
          '<div class="f" style="margin-bottom:0"><label>Entries per person</label>' +
            '<div class="hint">Counted against the platform account, not the email.</div>' +
            '<input class="in num" data-bind="cfg.registration.perPerson" value="' +
            (c.perPerson || 1) + '"></div></div></div>' +
        (M.entry(p).paid ?
          '<div class="sec"><div class="lbl" style="margin-bottom:8px">Payment</div>' +
          '<p style="margin:0;font-size:13px">This initiative charges <strong>' + M.feeLine(p) +
          '</strong>, so the form ends on a payment step. An entry is not counted until the ' +
          'payment clears — an abandoned payment leaves no half-registration behind.</p>' +
          '<p class="note">Set on Initiative page &#183; Format, because the price is on the public ' +
          'page before anyone reaches this form.</p></div>' : '');
    }

    if(k === 'team'){
      return head +
        '<div class="sec" style="padding-top:20px"><div class="three">' +
          MG.num('Smallest team','Members required to submit.','cfg.team.min',c.min || 2) +
          MG.num('Largest team','Invites stop at this number.','cfg.team.max',c.max || 5) +
          '<div class="f" style="margin-bottom:0"><label>Solo entries</label>' +
            '<button class="chip' + (c.solo !== false ? ' on' : '') + '" data-act="solo">' +
            (c.solo !== false ? 'Allowed' : 'Not allowed') + '</button></div>' +
        '</div><p class="note">A solo participant is an <b>entry of one</b>. Everything counts ' +
          'entries.</p></div>' +
        '<div class="sec"><div class="lbl" style="margin-bottom:11px">How a team comes together</div>' +
          '<div class="row"><span class="chip on">Invite by email</span>' +
          '<span class="chip">Open team-finder board</span>' +
          '<span class="chip">Organiser assigns</span></div></div>';
    }

    if(k === 'quiz'){
      c.categories = c.categories || [];
      const qs = c.categories.reduce((a, x) => a + x.questions, 0);
      return head + '<p style="margin:7px 0 0;font-size:13px;color:var(--muted);max-width:62ch">A ' +
        'screening round between registration and submission.</p>' +
        '<div class="sec" style="padding-top:20px">' +
          '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px">' +
          '<div class="lbl">Question set</div>' +
          '<span class="num" style="font-size:12.5px;color:var(--muted)">' + qs + ' questions · ' +
            qs + ' marks</span></div>' +
          '<div style="margin-top:14px"><div class="fr h"><span></span><span>Category</span>' +
            '<span>Questions</span><span>Marks</span><span></span></div>' +
          (c.categories.length ? c.categories.map((x, i) =>
            '<div class="fr" data-drag="qcat" data-di="' + i + '">' +
            '<span class="ic" data-grip title="Drag to reorder">' + GRIPSVG + '</span>' +
            '<input class="fin" data-bind="qcat.' + i + '.name" value="' + esc(x.name) + '">' +
            '<span><input class="fin num" data-bind="qcat.' + i + '.questions" value="' +
              x.questions + '" inputmode="numeric" style="width:56px;font-weight:400;' +
              'font-size:12.5px"></span>' +
            '<span class="fq">' + x.questions + '</span>' +
            '<button class="ic" data-act="delcat" data-i="' + i + '">' + ic('x',11,2.2) +
            '</button></div>').join('')
            : '<p style="font-size:13px;color:var(--muted);padding:12px 0">No categories yet. A quiz ' +
              'with no questions still takes a date on the timeline — worth removing the module ' +
              'instead if you do not want one.</p>') + '</div>' +
          '<button class="link" data-act="addcat" style="display:inline-flex;align-items:center;' +
            'gap:7px;margin:13px 0 0 27px">' + ic('plus',12,2.4) + 'Add category</button></div>' +
        '<div class="sec"><div class="three">' +
          MG.num('Time limit (min)','From the first question.','cfg.quiz.minutes',c.minutes || 30) +
          MG.num('Attempts','Per person.','cfg.quiz.attempts',c.attempts || 1) +
          MG.num('Pass mark (%)','Score needed to go through.','cfg.quiz.pass',c.pass || 60) +
        '</div></div>' +
        '<div class="sec"><div class="lbl" style="margin-bottom:11px">An entry advances when</div>' +
          '<div class="row">' + [['every','Every member passes'],['any','Any member passes'],
            ['avg','The team average passes']].map(a =>
            '<button class="chip' + ((c.advance || 'every') === a[0] ? ' on' : '') +
            '" data-act="adv" data-v="' + a[0] + '">' + a[1] + '</button>').join('') + '</div>' +
          '<p class="note"><b>Every member</b> punishes a strong team with one weak member; ' +
            '<b>any member</b> makes the quiz a formality.</p></div>';
    }

    if(k === 'submission'){
      if(!c.fields) c.fields = M.subFields();
      const editing = !!(APP.ui.fieldEdit && APP.ui.fieldEdit.submission);
      return head +
        '<div class="sec" style="padding-top:20px">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:12px">' +
          '<div class="lbl">What an entry hands in</div>' + MG.editToggle('submission', editing) +
          '</div>' +
          '<p class="note" style="margin:9px 0 4px">Every initiative starts with these. The two ' +
          'locked rows are read by Evaluation and the public page; change or remove any of the ' +
          'rest.</p>' +
          '<div style="margin-top:14px">' +
            (editing ? '<div class="fr h"><span></span><span>Field</span>' +
              '<span>Type</span><span>Rule</span><span></span></div>' : '') +
          c.fields.map((f, i) => MG.fieldRow(f, f.locked ? null : i, 'submission', editing)).join('') +
            '</div>' +
          (editing ? '<button class="link" data-act="addsubfield" style="display:inline-flex;' +
            'align-items:center;gap:7px;margin:13px 0 0 27px">' + ic('plus',12,2.4) +
            'Add field</button>' : '') + '</div>' +
        '<div class="sec"><div class="row">' +
          '<span class="chip on">Originality check on the repository</span>' +
          '<span class="chip">Sponsor can see submissions before scoring closes</span></div>' +
          '<p class="note">The second is off on purpose.</p></div>';
    }

    if(k === 'evaluation'){
      c.categories = c.categories || [];
      const share = c.categories.reduce((a, x) => a + x.share, 0);
      const wpill = n => {
        const ok = n === 100;
        return '<span style="display:inline-flex;align-items:center;gap:8px">' +
          '<span style="width:52px;height:4px;border-radius:999px;background:var(--line-soft);' +
            'overflow:hidden;display:block"><i style="display:block;height:100%;width:' +
            Math.min(100, n) + '%;background:' + (ok ? 'var(--ok)' : 'var(--warn)') +
            '"></i></span>' +
          '<span class="num" style="font-size:12px;color:' + (ok ? 'var(--muted)' : 'var(--warn)') +
            '">' + n + ' / 100</span></span>';
      };
      return head + '<p style="margin:7px 0 0;font-size:13px;color:var(--muted);max-width:62ch">An ' +
        'evaluator scores one category. Every entry is scored once per category.</p>' +
        '<div class="sec" style="padding-top:20px"><div class="lbl" style="margin-bottom:11px">' +
          'Categories</div><div class="row">' + c.categories.map((x, ci) =>
            '<span class="chip on" style="display:inline-flex;align-items:center;gap:8px;' +
              'padding-right:8px">' + esc(x.name) +
            '<button data-act="delevalcat" data-c="' + ci + '" title="Remove this category" ' +
              'style="display:grid;place-items:center;color:inherit;opacity:.7">' +
              ic('x',11,2.4) + '</button></span>').join('') +
          '<button class="chip dash" data-act="addevalcat">+ Add category</button></div>' +
          (c.categories.length ? '' :
            '<p class="note">No categories, no scoring. Add at least one.</p>') + '</div>' +
        c.categories.map((cat, ci) =>
          '<div class="sec"><div style="display:flex;justify-content:space-between;' +
            'align-items:center;gap:12px"><div class="lbl">' + esc(cat.name) + '</div>' +
            wpill(cat.params.reduce((a, x) => a + x[3], 0)) + '</div>' +
          '<div style="margin-top:12px">' +
          (ci === 0 ? '<div class="fr h"><span></span><span>Parameter</span>' +
            '<span>Out of</span><span>Weightage</span><span></span></div>' : '') +
          cat.params.map((pr, pi) =>
            '<div class="fr" data-drag="param:' + ci + '" data-di="' + pi + '">' +
            '<span class="ic" data-grip title="Drag to reorder">' + GRIPSVG + '</span>' +
            '<span><span class="fn">' + esc(pr[0]) + '</span>' +
            (pr[1] ? '<div class="fo">' + esc(pr[1]) + '</div>' : '') + '</span>' +
            '<span class="ft num">' + pr[2] + '</span><span class="ft num">' + pr[3] + '%</span>' +
            '<button class="ic" data-act="delparam" data-c="' + ci + '" data-i="' + pi + '">' +
            ic('x',11,2.2) + '</button></div>').join('') + '</div></div>').join('') +
        '<div class="sec"><div class="lbl" style="margin-bottom:12px">Share of the final score</div>' +
          '<div class="three">' + c.categories.map((cat, i2) =>
            MG.num(cat.name,'Share of the final.','cfg.evaluation.share.' + i2, cat.share)).join('') +
          '</div><p class="note" style="color:' + (share === 100 ? 'var(--ok)' : 'var(--warn)') + '">' +
          'These total ' + share + '%.</p>' +
          '<p class="note">The table above splits marks <i>inside</i> a category; this splits them ' +
            '<i>across</i> categories.</p></div>' +
        '<div class="sec"><div class="lbl" style="margin-bottom:11px">AI evaluation</div>' +
          '<div class="row">' + [['off','Off'],['assist','As an assist to evaluators'],
            ['round','As a round of its own']].map(a =>
            '<button class="chip' + ((c.ai || 'off') === a[0] ? ' on' : '') + '" data-act="ai" ' +
            'data-v="' + a[0] + '">' + a[1] + '</button>').join('') + '</div>' +
          (c.ai === 'round' ? MG.aiRound(p) :
            '<p class="note">Drafts a score and a reason for every entry.</p>') + '</div>';
    }

    if(k === 'mentor'){
      c.slots = c.slots || [
        ['Product and problem framing','Is this worth building, and for whom?', 6, 45],
        ['Technical review','Architecture, stack and what to cut', 8, 30],
        ['Pitch and demo','How to show it in three minutes', 4, 30]
      ];
      c.perEntry = c.perEntry == null ? 2 : c.perEntry;
      c.window = c.window || 'While submission is open';
      const shown = (p.mentors || []).length;
      return head + '<p style="margin:7px 0 0;font-size:13px;color:var(--muted);max-width:62ch">' +
        'Bookable time with your mentors. An entry books a slot; the mentor sees the entry, not ' +
        'the person.</p>' +

        '<div class="sec" style="padding-top:20px">' +
          '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px">' +
            '<div class="lbl">What a session is for</div>' +
            '<span class="num" style="font-size:12.5px;color:var(--muted)">' +
              c.slots.reduce((a, s) => a + s[2], 0) + ' sessions offered</span></div>' +
          '<p class="note" style="margin:9px 0 4px">An entry picks a topic, not a person. That is ' +
          'what keeps one popular mentor from taking every booking.</p>' +
          '<div style="margin-top:14px"><div class="fr h"><span></span><span>Topic</span>' +
            '<span>Sessions</span><span>Minutes</span><span></span></div>' +
          c.slots.map((s, si) =>
            '<div class="fr" data-drag="slot" data-di="' + si + '">' +
            '<span class="ic" data-grip title="Drag to reorder">' + GRIPSVG + '</span>' +
            '<span><input class="fin" data-bind="slot.' + si + '.0" value="' + esc(s[0]) + '">' +
              '<input class="fhint" data-bind="slot.' + si + '.1" value="' + esc(s[1]) +
              '" placeholder="Helper text, shown under the topic"></span>' +
            '<span><input class="fin num" data-bind="slot.' + si + '.2" value="' + s[2] +
              '" inputmode="numeric" style="width:52px;font-weight:400;font-size:12.5px"></span>' +
            '<span><input class="fin num" data-bind="slot.' + si + '.3" value="' + s[3] +
              '" inputmode="numeric" style="width:52px;font-weight:400;font-size:12.5px"></span>' +
            '<button class="ic" data-act="delslot" data-i="' + si + '" title="Remove this topic">' +
              ic('x',11,2.2) + '</button></div>').join('') + '</div>' +
          '<button class="link" data-act="addslot" style="display:inline-flex;align-items:center;' +
            'gap:7px;margin:13px 0 0 27px">' + ic('plus',12,2.4) + 'Add a topic</button></div>' +

        '<div class="sec"><div class="two">' +
          MG.num('Bookings per entry','Across every topic.','cfg.mentor.perEntry', c.perEntry) +
          '<div class="f" style="margin-bottom:0"><label>Who can book</label>' +
            '<div class="hint">A team books once, not once per member.</div>' +
            '<div class="row">' + [['all','Every entry'],['through','Entries still in the running']]
              .map(v => '<button class="chip' + ((c.who || 'all') === v[0] ? ' on' : '') + '" ' +
              'data-act="mentwho" data-v="' + v[0] + '">' + v[1] + '</button>').join('') +
            '</div></div>' +
        '</div></div>' +

        '<div class="sec"><div class="lbl" style="margin-bottom:11px">How a session happens</div>' +
          '<div class="row">' + [['video','Video call, link generated'],
            ['inperson','In person, at the venue'],['either','Mentor chooses']].map(v =>
            '<button class="chip' + ((c.how || 'video') === v[0] ? ' on' : '') + '" ' +
            'data-act="menthow" data-v="' + v[0] + '">' + v[1] + '</button>').join('') + '</div>' +
          '<p class="note">A no-show frees the slot back to the pool after 10 minutes, so one ' +
          'missed booking does not cost a mentor their afternoon.</p></div>' +

        '<div class="sec"><div class="lbl" style="margin-bottom:8px">The roster</div>' +
          '<p style="margin:0;font-size:13px">' + (shown
            ? '<strong>' + shown + ' mentors</strong> on this initiative. Each one sets their own ' +
              'availability; you set the topics above, they pick which they cover.'
            : 'No mentors on this initiative yet. Add them on the roster and they set their own ' +
              'availability.') + '</p>' +
          '<a class="link" href="#/p/' + p.id + '" style="display:inline-block;margin-top:10px">' +
            'Open the roster &#8594;</a></div>';
    }

    if(k === 'feedback'){
      c.questions = c.questions || [];
      return head + '<p style="margin:7px 0 0;font-size:13px;color:var(--muted);max-width:62ch">Sent ' +
        'after the initiative closes. Short, anonymous, and it never asks about a module this initiative ' +
        'did not run.</p>' +
        '<div class="sec" style="padding-top:20px"><div class="lbl" style="margin-bottom:11px">Who ' +
          'gets it</div><div class="row"><span class="chip">Everyone who registered</span>' +
          '<span class="chip on">Everyone who submitted</span>' +
          '<span class="chip">Shortlisted entries only</span></div></div>' +
        '<div class="sec"><div class="lbl">Questions</div><div style="margin-top:14px">' +
          '<div class="fr h"><span></span><span>Question</span><span>Type</span><span></span>' +
            '<span></span></div>' +
          c.questions.map((q, qi) => ({ q:q, qi:qi })).filter(o =>
            !(o.q[1].indexOf('Mentor connect') > -1 && p.modules.indexOf('mentor') === -1))
            .map(o => { const q = o.q, qi = o.qi; return
            '<div class="fr" data-drag="fq" data-di="' + qi + '">' +
            '<span class="ic" data-grip title="Drag to reorder">' + GRIPSVG + '</span>' +
            '<span><span class="fn">' + esc(q[0]) +
              (q[3] === 'Required' ? '<span class="rq" aria-label="required">*</span>' : '') +
              '</span>' +
            (q[1] ? '<div class="fo">' + esc(q[1]) + '</div>' : '') + '</span>' +
            '<span class="ft">' + q[2] + '</span><span></span>' +
            '<span></span></div>'; }).join('') + '</div>' +
          '<p class="note">A question about a module you do not run is not asked at all.</p></div>';
    }

    return head + '<p style="margin:7px 0 0;font-size:13px;color:var(--muted);max-width:62ch">' +
      M.mod(k).sub + '. Configuration for this module is not wired in this pass — it takes a date on ' +
      'the timeline and a step on the public page like any other.</p>';
  },
  num(label, hint, bind, val){
    return '<div class="f" style="margin-bottom:0"><label>' + label + '</label>' +
      '<div class="hint">' + hint + '</div>' +
      '<input class="in num" data-bind="' + bind + '" value="' + val + '"></div>';
  },
  /* One row of a field table. Locked rows are read-only text; everything else is
     editable in place — name, helper text, type and rule — because a form you can
     look at but not change is not a form builder. Type and Rule stay out of the
     way until Edit is on: what a participant sees is the field list alone. */
  fieldRow(f, i, scope, editing){
    const lock = f.locked || i === null;

    const star = f.rule === 'Required' ? '<span class="rq" aria-label="required">*</span>' : '';

    if(!editing){
      return '<div class="fr compact">' +
        '<span class="ic">' + (lock ? ic('lock',11,2) : '') + '</span>' +
        '<span><span class="fn">' + esc(f.name) + star + '</span>' +
        (f.opts ? '<div class="fo">' + esc(f.opts) + '</div>' : '') + '</span></div>';
    }

    const sel = (prop, list) =>
      '<select class="sel" data-bind="fld.' + scope + '.' + i + '.' + prop + '">' +
      list.map(o => '<option' + (f[prop] === o ? ' selected' : '') + '>' + esc(o) +
        '</option>').join('') + '</select>';

    if(lock){
      return '<div class="fr"><span class="ic">' + ic('lock',11,2) + '</span>' +
        '<span><span class="fn">' + esc(f.name) + star + '</span>' +
        (f.opts ? '<div class="fo">' + esc(f.opts) + '</div>' : '') + '</span>' +
        '<span class="ft">' + esc(f.type) + '</span>' +
        '<span></span><span></span></div>';
    }

    return '<div class="fr" data-drag="fld:' + scope + '" data-di="' + i + '">' +
      '<span class="ic" data-grip title="Drag to reorder">' + GRIPSVG + '</span>' +
      '<span>' +
        '<input class="fin" data-bind="fld.' + scope + '.' + i + '.name" value="' +
          esc(f.name) + '">' +
        '<input class="fhint" data-bind="fld.' + scope + '.' + i + '.opts" value="' +
          esc(f.opts || '') + '" placeholder="Helper text, shown under the field">' +
      '</span>' +
      '<span>' + sel('type', CATALOGUE.fieldTypes) + '</span>' +
      '<span>' + sel('rule', CATALOGUE.rules) + '</span>' +
      '<button class="ic" data-act="' + (scope === 'submission' ? 'delsubfield' : 'delfield') +
        '" data-i="' + i + '" title="Remove this field">' + ic('x',11,2.2) + '</button></div>';
  },
  /* The Edit / Done toggle each field table sits under — Type and Rule (and the
     ability to add or remove a row) are an editing concern; the resting state is
     just the list a participant would recognise. */
  editToggle(scope, editing){
    return '<button class="editbtn' + (editing ? ' on' : '') + '" data-act="toggleedit" ' +
      'data-scope="' + scope + '">' +
      (editing ? ic('tick',11,2.6) : ic('edit',11,2.2)) +
      (editing ? 'Done' : 'Edit') + '</button>';
  },
  aiRound(p){
    return '<div style="margin-top:14px;border:1px solid var(--line);border-radius:var(--r);' +
      'padding:15px 17px">' +
      '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px">' +
      '<div class="lbl">Rubric · AI round</div><span class="tag" style="color:var(--warn)">set by ' +
        'H2S</span></div>' +
      '<p class="note" style="margin:8px 0 0">Read only, and identical on every initiative that runs the round. The human parameters do not apply to it.</p>' +
      '<div style="margin-top:12px">' +
      [['Working prototype','Does the repository build and run?','10','35%'],
       ['Code quality','Structure, tests, commit history','10','25%'],
       ['Completeness','Summary measured against the problem statement','10','25%'],
       ['Documentation','README, setup steps, licence','10','15%']].map(r =>
        '<div class="fr"><span class="ic">' + ic('lock',11,2) + '</span>' +
        '<span><span class="fn">' + r[0] + '</span><div class="fo">' + r[1] + '</div></span>' +
        '<span class="ft num">' + r[2] + '</span><span class="ft num">' + r[3] + '</span>' +
        '<span></span></div>').join('') + '</div>' +
      '<div style="display:flex;align-items:stretch;margin-top:14px;border:1px solid var(--line);' +
        'border-radius:var(--r);overflow:hidden">' +
        '<div style="flex:1;padding:10px 12px"><div class="lbl" style="color:var(--faint);' +
          'margin-bottom:4px">Entry submits</div><div style="font-size:12px;color:var(--muted)">Or ' +
          'edits, before close</div></div>' +
        '<span style="width:1px;background:var(--line)"></span>' +
        '<div style="flex:1;padding:10px 12px;background:var(--primary-soft)">' +
          '<div class="lbl" style="color:var(--primary-dark);margin-bottom:4px">AI scores it</div>' +
          '<div style="font-size:12px;color:var(--primary)">Under 5 min</div></div>' +
        '<span style="width:1px;background:var(--line)"></span>' +
        '<div style="flex:1;padding:10px 12px"><div class="lbl" style="color:var(--faint);' +
          'margin-bottom:4px">Recorded</div><div style="font-size:12px;color:var(--muted)">With ' +
          'per-parameter reasons</div></div></div>' +
      '<p class="note">On submit, or on demand.</p></div>';
  },

  /* =============== APPROVAL =============== */
  /* Deliberately the plainest page in the product: one sentence saying where it
     stands, and at most one thing to do about it. */
  approval(p){
    const st = M.approvalState(p);
    const a  = p.approval || {};
    const mgr = DB.org.manager.name;
    const blockers = M.approvalBlockers(p);
    const gaps = M.approvalGaps(p);
    const opens = p.dates.registration ? p.dates.registration[0] : null;

    const shell = (dot, title, line, body) =>
      '<div class="wrap" style="max-width:720px">' +
        '<div class="card lift" style="padding:34px 36px">' +
          '<div style="display:flex;align-items:center;gap:10px">' +
            '<span class="rd ' + dot + '" style="width:9px;height:9px;border-radius:50%"></span>' +
            '<span class="lbl">Approval</span></div>' +
          '<h1 style="font-size:27px;font-weight:900;margin-top:14px">' + title + '</h1>' +
          '<p style="margin:11px 0 0;font-size:15px;color:var(--muted);max-width:56ch;' +
            'line-height:1.6">' + line + '</p>' +
          body +
        '</div>' +
      '</div>';

    const gapline = gaps.length
      ? '<p style="margin:20px 0 0;font-size:12.5px;color:var(--faint)">Empty, but not required: ' +
        gaps.join(', ') + '.</p>' : '';

    /* 1 — something is genuinely missing */
    if(st === 'none' && blockers.length){
      return shell('todo', 'Not ready to send yet',
        (blockers.length === 1 ? 'One thing is missing. Fix it and the button turns on.'
                               : blockers.length + ' things are missing. Fix them and the ' +
                                 'button turns on.'),
        '<div style="margin-top:22px">' + blockers.map(b =>
          '<a href="' + b.go + '" style="display:flex;align-items:center;gap:14px;padding:15px 0;' +
            'border-top:1px solid var(--line-soft);color:inherit">' +
          '<span style="font-size:14.5px;font-weight:600;flex-grow:1">' + esc(b.t) + '</span>' +
          '<span style="color:var(--primary)">' + ic('arrow',15,2.2) + '</span></a>').join('') +
        '</div>' +
        '<button class="btn" disabled style="margin-top:24px;opacity:.45;cursor:not-allowed">' +
          'Send to H2S for approval</button>' + gapline);
    }

    /* 2 — ready */
    if(st === 'none' || st === 'changes'){
      const changed = st === 'changes';
      return shell(changed ? 'todo' : 'todo',
        changed ? 'H2S asked for one change' : 'Ready to send',
        changed
          ? 'Make the change, then send it back. Nothing else has to be redone.'
          : 'H2S reads the page and checks the dates work. They do not change your content.',
        (changed && a.note
          ? '<div style="margin-top:22px;padding:16px 18px;background:var(--warn-soft);' +
            'border-radius:var(--r);font-size:14px;line-height:1.6">' +
            '<div class="lbl" style="color:var(--warn);margin-bottom:6px">From ' + esc(mgr) +
            '</div>' + esc(a.note) + '</div>'
          : '') +
        '<button class="btn p" data-act="sendapproval" style="margin-top:24px;padding:12px 22px;' +
          'font-size:14.5px">' + (changed ? 'Send it back' : 'Send to H2S for approval') +
          '</button>' +
        '<p style="margin:14px 0 0;font-size:13px;color:var(--muted)">Usually approved within ' +
          '2 working days. You can keep editing while it is with them — they see the latest ' +
          'version.</p>' + gapline);
    }

    /* 3 — with H2S */
    if(st === 'sent'){
      return shell('on', 'With H2S',
        'Sent ' + M.date(a.sentOn) + '. ' + esc(mgr) + ' has it.',
        '<p style="margin:18px 0 0;font-size:14px">You will get an email when it is approved — ' +
          'usually within 2 working days. Nothing is public until then.</p>' +
        '<button class="link" data-act="withdrawapproval" style="margin-top:22px">' +
          'Withdraw and keep editing</button>');
    }

    /* 4 — approved */
    return shell('done', 'Approved',
      'Approved by ' + esc(mgr) + ' on ' + M.date(a.decidedOn || p.signedOn) + '.',
      '<p style="margin:18px 0 0;font-size:14px">' +
        (p.state === 'live'
          ? 'The page has been live since ' + (opens ? M.date(opens) : 'it opened') + '.'
          : (opens ? 'It goes live when registration opens on ' + M.date(opens) + '.'
                   : 'It goes live when registration opens.')) + '</p>' +
      '<p style="margin:14px 0 0;font-size:13px;color:var(--muted)">Small edits go out straight ' +
        'away. Change a date, a prize or the fee and it comes back here for a second look.</p>');
  },

  /* =============== TIMELINE =============== */
  timeline(p){
    M.applySchedule(p);
    const s = p.schedule, conflicts = M.conflicts(p), today = M.today();
    const rest = p.modules.filter(k => k !== 'registration');
    const reg = p.dates.registration || [null, null];
    const totalDays = (s.anchor && s.end) ? M.days(s.anchor, s.end) : 0;
    const weeks = totalDays > 0 ? Math.round(totalDays / 7 * 10) / 10 : null;
    const open = APP.ui.schedOpen || (APP.ui.schedOpen = {});

    /* conflicts are stated once, in M.conflicts(), and read back here by the
       row they belong to — a gate conflict points at the module that should
       move (fixKind), an overrun points at the module trimmed ('trim:<k>'),
       and the results conflict has no module at all. No row goes unclaimed:
       a conflict this map can't place would simply not show, which is why
       every fixKind above is either a real module key or one of these two. */
    const conflictFor = {};
    conflicts.forEach(c => {
      const k = c.fixKind.indexOf('trim:') === 0 ? c.fixKind.slice(5) : c.fixKind;
      conflictFor[k] = c;
    });

    /* Status is read from shape and weight, not a label — see stage() below.
       M.stageOf already answers this exact question for the Live page, so
       reusing it here means "today" means the same day everywhere in the
       product. */
    const stage = (k) => M.stageOf(p, k, today);
    const relLine = (k, d) => {
      if(!d || !d[0]) return 'Waiting on the initiative span above';
      const st = stage(k);
      if(st === 'closed') return 'Closed ' + M.date(d[1], false);
      if(st === 'open') return 'Open — closes in ' + Math.max(0, M.days(today, d[1])) + ' days';
      return 'Opens in ' + M.days(today, d[0]) + ' days';
    };
    const marker = (k, d) => {
      const st = d && d[0] ? stage(k) : 'next';
      if(st === 'closed') return ic('tick', 13, 2.4).replace('<svg ', '<svg style="color:var(--ok);opacity:.8" ');
      if(st === 'open') return '<span style="width:9px;height:9px;border-radius:50%;' +
        'background:var(--primary);display:block;box-shadow:0 0 0 3px var(--primary-soft)"></span>';
      return '<span style="width:9px;height:9px;border-radius:50%;border:1.5px solid var(--faint);' +
        'display:block"></span>';
    };
    const statusColor = (k, d) => {
      if(!d || !d[0]) return 'var(--faint)';
      const st = stage(k);
      return st === 'open' ? 'var(--primary)' : st === 'closed' ? 'var(--faint)' : 'var(--muted)';
    };

    const conflictHTML = (c) => '<div class="sconflict"><span class="dot"></span>' +
      '<div><p>' + c.body + '</p><div class="acts">' +
      '<button class="link" data-act="fixdate" data-k="' + c.fixKind + '" data-v="' + c.fixTo +
        '">Move it to ' + M.date(c.fixTo, false) + '</button>' +
      '<span class="link" style="color:var(--muted)">Leave it</span></div></div></div>';

    /* one row, collapsed by default: marker · name · relative status · exact
       dates. Opening it reveals the fields a sponsor touches rarely — offset,
       duration, public visibility, and any conflict attached to this row. */
    const row = (key, name, meta, d, panelInner, showChev) => {
      const isOpen = !!open[key];
      const c = conflictFor[key];
      return '<div class="srow">' +
        '<button class="srow-btn" type="button" data-act="schedrow" data-k="' + key + '" ' +
          'aria-expanded="' + isOpen + '">' +
          '<span class="smark">' + marker(key, d) + '</span>' +
          '<span class="sinfo">' +
            '<span class="snm" style="font-weight:' + (d && stage(key) === 'open' ? '600' : '500') +
              ';opacity:' + (d && d[0] && stage(key) === 'closed' ? '.6' : '1') + '">' + esc(name) +
              '</span>' +
            '<span class="sst" style="color:' + statusColor(key, d) + '">' + relLine(key, d) +
              (c ? '<span class="cflag" title="Needs a look"></span>' : '') + '</span>' +
          '</span>' +
          '<span class="sdate">' + (d && d[0] ? M.date(d[0], false) + ' – ' + M.date(d[1], false)
            : '—') + '</span>' +
          (showChev === false ? '' : '<span class="schev">' + ic('arrow', 12, 2.2) + '</span>') +
        '</button>' +
        (isOpen ? '<div class="spanel">' + panelInner + (c ? conflictHTML(c) : '') + '</div>' : '') +
      '</div>';
    };

    /* the today line crosses the spine once, at today's position on the
       start→end track — replacing six repeated per-row progress bars */
    const todayPct = (s.anchor && s.end && totalDays > 0)
      ? M.days(s.anchor, today) / totalDays * 100 : null;
    const todayLine = (todayPct != null && todayPct >= 0 && todayPct <= 100)
      ? '<div class="today-line"><div class="today-mark" style="left:' + todayPct + '%">' +
        '<span class="tlbl">Today</span><span class="ttick"></span></div></div>'
      : '<div class="today-line"></div>';

    return '<div class="wrap wide mgwrap"><div class="mgsheet wide">' +

      /* A — the span. Two enormous native date inputs showing 05/10/2026 and a
         dd/mm/yyyy placeholder at the same size told you nothing about which
         number was the day. Each date is now a labelled field at field size,
         echoing itself in words underneath, where the ambiguity dies. */
      '<div class="spanbox">' +
        '<div class="lbl">Initiative span</div>' +
        '<div class="spanrow">' +
          V.dateField('Starts', 'schedanchor', s.anchor, 'Registration opens this day') +
          '<span class="span-arrow">&#8594;</span>' +
          V.dateField('Ends', 'schedend', s.end, 'Everything is due by this day') +
          (weeks ? '<span class="spanlen"><span class="num">' + Math.round(weeks) +
            '</span> weeks<span>end to end</span></span>' : '') +
        '</div>' +
        '<p class="span-cap">' + p.tz +
          (reg[1] ? ' &#183; registration opens with the span and closes ' +
            M.date(reg[1]) : '') + '</p>' +
      '</div>' +

      /* B — the spine */
      todayLine +
      '<div class="spine">' +
        row('registration', 'Registration', M.moduleLine(p, 'registration'), reg,
          MG.cfg([
            MG.cfgNum('Runs for', 's', '<input class="snum" type="number" min="1" ' +
              'data-act="regdur" value="' + s.regDur + '"> days from the start',
              reg[1] ? 'Closes ' + M.date(reg[1]) : '')
          ]), true) +
        rest.map(k => {
          const o = s.offsets[k] || (s.offsets[k] = { start:7, dur:14 });
          const d = p.dates[k] || [null, null];
          const shown = p.publicDates[k] !== false;
          return row(k, M.mod(k).name, M.moduleLine(p, k), d, MG.cfg([
            MG.cfgNum('Opens', k, '<input class="snum" type="number" min="0" ' +
              'data-act="schedoffset" data-k="' + k + '" data-f="start" value="' + o.start +
              '"> days in', d[0] ? M.date(d[0]) : 'no date yet'),
            MG.cfgNum('Runs for', k, '<input class="snum" type="number" min="1" ' +
              'data-act="schedoffset" data-k="' + k + '" data-f="dur" value="' + o.dur +
              '"> days', d[1] ? 'Closes ' + M.date(d[1]) : 'no date yet'),
            /* the toggle states its own consequence rather than naming a screen */
            '<div class="cfgf cfgt"><span class="cfgl">On the public page</span>' +
              '<span class="cfgv"><button class="sw' + (shown ? ' on' : '') + '" ' +
              'data-act="pubdate" data-k="' + k + '" aria-pressed="' + shown + '">' +
              '<i></i></button><span>' + (shown ? 'Dates shown' : 'Dates hidden') +
              '</span></span>' +
              '<span class="cfgr">' + (shown ? 'Participants see this window'
                : 'Participants see the stage, not the dates') + '</span></div>'
          ]));
        }).join('') +
      '</div>' +

      /* C — loose ends: single lines, visually continuous with the spine */
      '<div class="srow" style="display:flex;align-items:center;justify-content:space-between;' +
        'gap:20px;padding:18px 6px;flex-wrap:wrap">' +
        '<span><span class="snm" style="font-size:14px;color:var(--muted)">Results announced' +
          '</span><span class="sst" style="color:var(--faint)">The leaderboard opens to everyone' +
          '</span></span>' +
        /* the same date component the span uses, so no date on this page is a
           bare 02/04/2027 anybody has to decode */
        V.dateField('Announced on', 'results', p.resultsAt, '') +
      '</div>' +
      (conflictFor.results ? '<div style="padding:0 6px">' + conflictHTML(conflictFor.results) +
        '</div>' : '') +

      ((p.config.evaluation || {}).ai === 'round'
        ? '<div class="srow" style="display:flex;align-items:baseline;gap:16px;padding:16px 6px">' +
          '<span class="snm" style="font-size:14px;color:var(--muted);min-width:180px">Not on ' +
            'this schedule</span>' +
          '<span class="sst" style="color:var(--faint)">AI evaluation round — runs on submit, or ' +
            'on demand.</span></div>' : '') +
      '<p class="qn" style="padding:0 6px">' + p.modules.length + ' modules, ' + p.modules.length +
        ' rows. Remove one and its row leaves with it.</p>' +
    '</div></div>';
  },
  /* =============== LIVE =============== */
  live(p){
    /* Nothing is live before H2S has approved it. Say so here rather than
       showing an empty dashboard that looks broken. */
    const ap = M.approvalState(p);
    if(ap !== 'approved'){
      const line = { none:'It has not been sent for approval yet.',
                     sent:'It is with ' + DB.org.manager.name + ' now.',
                     changes:DB.org.manager.name + ' asked for one change first.' }[ap];
      return '<div class="wrap"><div class="card lift" style="max-width:640px;padding:30px 34px">' +
        '<div style="display:flex;align-items:center;gap:10px">' +
          '<span class="rd idle" style="width:9px;height:9px;border-radius:50%"></span>' +
          '<span class="lbl">Live</span></div>' +
        '<h1 style="font-size:24px;font-weight:900;margin-top:14px">Not live yet</h1>' +
        '<p style="margin:11px 0 0;font-size:14.5px;color:var(--muted);max-width:52ch;' +
          'line-height:1.6">A initiative goes live once H2S has approved it. ' + line + '</p>' +
        '<a class="btn p" href="#/p/' + p.id + '/manage/approval" style="margin-top:22px;' +
          'padding:11px 20px">Go to Approval</a></div></div>';
    }
    if(!p.live) return '<div class="wrap wide"><div class="card" style="max-width:70ch;' +
      'background:var(--bg-soft)"><strong style="font-size:15px">This rung is not true yet</strong>' +
      '<p style="margin:8px 0 0;font-size:13.5px;color:var(--muted)">Approved, and waiting for the ' +
      'first registration. It becomes true on its own — nobody clicks it.</p></div></div>';
    const L = p.live, cur = M.currentStage(p), needs = M.needsYou(p);
    return '<div class="wrap wide mgwrap">' +
      /* one ruled card, same shape as At a glance on the initiative page */
      '<div class="card lift ovstats" style="padding:0;display:grid;' +
        'grid-template-columns:1.5fr repeat(4,minmax(0,1fr));align-items:start">' +
        '<div><div class="lbl" style="margin-bottom:6px">Right now</div>' +
        '<div style="font-family:Archivo,sans-serif;font-size:23px;font-weight:800;' +
          'letter-spacing:-.025em">' + (cur ? M.mod(cur).name + ' is open' : 'Between stages') +
        '</div><div style="font-size:12.5px;color:var(--muted);margin-top:4px">' +
        (cur ? 'Closes ' + M.date(p.dates[cur][1]) + ', in ' +
          M.days(M.today(), p.dates[cur][1]) + ' days' : '—') + '</div></div>' +
        V.bignum(M.n(L.registrations),'Registrations','') +
        V.bignum(M.n(L.entries),'Entries','') +
        V.bignum(M.n(L.submitted),'Submitted','') +
        V.bignum((M.pct(L.scored, L.allocations) == null ? '—'
          : M.pct(L.scored, L.allocations) + '%'),'Scored','') +
      '</div>' +
      '<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.15fr);gap:34px;' +
        'margin-top:24px;align-items:start">' +
        '<div><h2 style="font-size:18px;font-weight:700">Where it has got to</h2>' +
          '<p style="margin:7px 0 0;font-size:13px;color:var(--muted)">Nothing here is a setting.</p>' +
          '<div class="card" style="margin-top:14px">' + p.modules.map(k => {
            const st = M.stageOf(p, k, M.today());
            const col = st === 'closed' ? 'var(--ok)' : st === 'open' ? 'var(--primary)' : 'var(--line)';
            const d = p.dates[k];
            return '<div style="display:flex;align-items:center;gap:11px;padding:11px 0;' +
              'border-bottom:1px solid var(--line-soft)">' +
              '<span style="width:14px;height:14px;border-radius:50%;flex:none;' +
              (st === 'closed' ? 'background:var(--ok)' : 'border:2px solid ' + col) + '"></span>' +
              '<span style="font-size:13.5px;flex-grow:1' + (st === 'next' ? ';color:var(--faint)' : '') +
              '">' + M.mod(k).name + '</span>' +
              '<span style="font-size:12.5px;color:' + (st === 'open' ? 'var(--primary);font-weight:600'
                : 'var(--muted)') + '">' + (st === 'closed' ? 'closed ' + M.date(d[1], false)
                : st === 'open' ? 'open' : 'opens ' + M.date(d[0], false)) + '</span></div>';
          }).join('') +
          '<div style="display:flex;align-items:center;gap:11px;padding:11px 0">' +
          '<span style="width:14px;height:14px;border-radius:50%;border:1px dashed var(--line);' +
            'flex:none"></span><span style="font-size:13.5px;flex-grow:1;color:var(--faint)">Results ' +
            'announced</span><span style="font-size:12.5px;color:var(--faint)">' +
            M.date(p.resultsAt, false) + '</span></div></div>' +
          ((p.config.evaluation || {}).ai === 'round' ? '<p class="qn">The AI round is not a stage — it has been scoring since the first submission.</p>' : '') +
        '</div>' +
        /* the same panel the Overview rail and the initiative page use — one
           "needs you" component across the product, not three that look alike */
        '<div><h2 style="font-size:18px;font-weight:700">Needs you</h2>' +
          '<p style="margin:7px 0 0;font-size:13px;color:var(--muted)">The only list on this page ' +
            'you can act on. Each names the page that fixes it &#8212; nothing is fixed here.</p>' +
          '<div class="sp attn" style="margin-top:14px"><div class="sph">' +
            '<span class="dot" style="background:var(--warn)"></span>' +
            '<strong style="font-size:13.5px">Needs your attention</strong>' +
            '<span style="flex-grow:1"></span>' +
            '<span class="num" style="font-size:11.5px;font-weight:600;color:var(--warn);' +
              'background:#fff;border-radius:var(--r-pill);padding:2px 9px">' + needs.length +
            '</span></div><div class="spb">' + needs.map(n =>
            '<a class="spr" href="' + n.route + '">' +
            '<span style="min-width:0;flex-grow:1">' +
            '<span style="display:block;font-size:13px;line-height:1.45">' + n.text + '</span>' +
            '<span class="link" style="display:inline-block;margin-top:7px;font-size:12px">' +
              n.act + ' &#8594;</span></span>' +
            '<span class="spc">' + ic('arrow',14,2.2) + '</span></a>').join('') +
          '</div></div></div>' +
      '</div></div>';
  },

  /* =============== RESULT & REWARD =============== */
  result(p){
    const gate = M.gate(p), open = M.gateOpen(p), jc = M.juryCounts(p);
    return '<div class="wrap wide">' +
      '<div style="display:grid;grid-template-columns:minmax(0,1.15fr) minmax(0,1fr);gap:34px;' +
        'align-items:start">' +
        '<div><div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px">' +
          '<h2 style="font-size:18px;font-weight:700">The leaderboard is ' +
            (open ? 'open' : 'shut') + '</h2>' +
          '<span class="num" style="font-size:12px;color:' + (open ? 'var(--ok)' : 'var(--warn)') +
            '">' + (open ? 'every category scored' :
            gate.filter(g => g.pct < 100).length + ' categories short') + '</span></div>' +
          '<p style="margin:7px 0 0;font-size:13px;color:var(--muted)">It opens when every category has ' +
            'scored every entry.</p>' +
          '<div class="card" style="margin-top:14px">' + (gate.length ? gate.map(g =>
            '<div style="display:flex;align-items:center;gap:11px;padding:11px 0;' +
              'border-bottom:1px solid var(--line-soft)">' +
            '<span style="width:15px;height:15px;border-radius:50%;flex:none;' +
            (g.pct === 100 ? 'background:var(--ok)' : 'border:2px solid var(--warn)') + '"></span>' +
            '<span style="font-size:13.5px;flex-grow:1">' + g.name + '</span>' +
            '<span class="num" style="font-size:13px;font-weight:600;color:' +
            (g.pct === 100 ? 'var(--ok)' : 'var(--warn)') + '">' + g.pct + '%</span></div>').join('')
            : '<p style="font-size:13px;color:var(--muted)">No evaluation categories yet — set them ' +
              'up on the Evaluation module and this gate appears.</p>') + '</div>' +
          '<div style="display:flex;gap:16px;margin-top:12px;flex-wrap:wrap">' +
          '<a class="link" href="#/p/' + p.id + '/panel">Fix it on the Panel &#8594;</a>' +
          '<span style="font-size:11.5px;color:var(--faint)">Nothing below is blocked — settle every ' +
            'rule now and open it later.</span></div></div>' +
        '<div class="card" style="background:var(--bg-soft)">' +
          '<div class="lbl" style="margin-bottom:10px">Announcing it</div>' +
          [['You sign off','not yet'],['H2S countersigns','after you'],
           ['Results go public', p.resultsAt ? M.date(p.resultsAt) + ', 17:00' : 'no date set']]
            .map(r => '<div style="display:flex;align-items:baseline;gap:10px;font-size:13px;' +
              'padding:5px 0"><span style="color:var(--muted);min-width:150px">' + r[0] + '</span>' +
              '<span style="font-weight:500;color:var(--faint)">' + r[1] + '</span></div>').join('') +
          '<p class="note">Two keys, same as publishing the initiative.</p>' +
          '<div style="margin-top:14px;padding-top:13px;border-top:1px solid var(--line)">' +
          '<span class="btn ' + (open ? 'p' : 'dis') + '">Sign off the result</span>' +
          '<div style="font-size:11.5px;color:var(--faint);margin-top:8px">' +
            (open ? 'Ready.' : 'Available once every category has scored.') + '</div></div></div>' +
      '</div>' +

      '<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:34px;' +
        'margin-top:28px;padding-top:24px;border-top:1px solid var(--line-soft);align-items:start">' +
        '<div><h2 style="font-size:18px;font-weight:700">How a winner is decided</h2>' +
          '<p style="margin:7px 0 0;font-size:13px;color:var(--muted)">Configurable, because it ' +
            'varies from initiative to initiative.</p>' +
          '<div class="row" style="margin-top:14px">' + [['top','The top score wins'],
            ['jury','A jury round on the shortlist'],['you','You decide, on the record']].map(r =>
            '<button class="chip' + (p.winnerRule === r[0] ? ' on' : '') + '" data-act="winner" ' +
            'data-v="' + r[0] + '">' + r[1] + '</button>').join('') + '</div>' +
          (p.winnerRule === 'jury' ? '<div class="card" style="margin-top:16px">' +
            [['Shortlist','Top ' + p.shortlist + ' by final score'],
             ['Jury', jc.scores + ' score · ' + jc.shown + ' named on the page'],
             ['Jury sees','Every category score, and the reasons'],
             ['Jury may','Reorder the shortlist, not add to it']].map(r =>
              '<div style="display:flex;align-items:baseline;gap:10px;font-size:13px;padding:6px 0">' +
              '<span style="color:var(--muted);min-width:110px">' + r[0] + '</span>' +
              '<span style="font-weight:500">' + r[1] + '</span></div>').join('') +
            '</div>' : '') +
          MG.jury(p) +
        '</div>' +
        '<div><h2 style="font-size:18px;font-weight:700">When two entries tie</h2>' +
          '<p style="margin:7px 0 0;font-size:13px;color:var(--muted)">Applied in order, first one ' +
            'that separates them wins.</p>' +
          '<div class="card" style="margin-top:14px">' + (p.tiebreaks.length ? p.tiebreaks.map((t, i) =>
            '<div data-drag="tb" data-di="' + i + '" ' +
              'style="display:grid;grid-template-columns:26px minmax(0,1fr) 90px;column-gap:13px;' +
              'align-items:baseline;padding:10px 0;border-bottom:1px solid var(--line-soft)">' +
            '<span class="ic" data-grip title="Drag to reorder">' + GRIPSVG +
            '</span><span><span style="font-size:13.5px;font-weight:500">' + esc(t[0]) + '</span>' +
            '<div class="fo">' + esc(t[1]) + '</div></span>' +
            '<span class="tag" style="text-align:right">rule ' + (i + 1) + '</span></div>').join('')
            : '<p style="font-size:13px;color:var(--muted)">None set. Two entries on the same score ' +
              'would have to be separated by hand.</p>') + '</div>' +
          '<div class="card" style="margin-top:16px">' +
            '<div class="lbl" style="margin-bottom:10px">Disqualifications</div>' +
            [['Disqualified', (p.live ? p.live.disqualified : 0) + ' entry · on the record, out of ' +
              'the ranking'],['Effect','Everyone below moves up one place'],
             ['Reversible','Yes — reinstating puts the ranking back']].map(r =>
              '<div style="display:flex;align-items:baseline;gap:10px;font-size:13px;padding:5px 0">' +
              '<span style="color:var(--muted);min-width:110px">' + r[0] + '</span>' +
              '<span style="font-weight:500">' + r[1] + '</span></div>').join('') +
            '<p class="note">Handled on the roster; shown here because it changes who wins.</p></div>' +
        '</div></div>' +
      '<div class="card" style="margin-top:26px;display:flex;align-items:center;gap:16px;' +
        'flex-wrap:wrap;background:var(--bg-soft)"><div style="min-width:300px;flex-grow:1;' +
        'max-width:74ch"><strong style="font-size:14px">Prizes are set on the Initiative page</strong>' +
        '<p style="margin:6px 0 0;font-size:13px;color:var(--muted)">' +
        (p.prizes.length ? M.money(M.prizeTotal(p)) + ' across ' + p.prizes.length + ' prizes, live ' +
          'on the public page since the day it opened.' : 'None set yet.') +
        ' What is on offer is a promise made at the start; this rung only decides who receives ' +
        'it.</p></div>' +
        '<a class="btn" href="#/p/' + p.id + '/manage/design/prizes">Open Prizes &#8594;</a></div>' +

      '</div>';
  },

  jury(p){
    const jc = M.juryCounts(p);
    return '<div style="margin-top:22px"><div style="display:flex;justify-content:space-between;' +
      'align-items:baseline;gap:12px"><h3 style="font-size:16px;font-weight:700">The jury</h3>' +
      '<span class="num" style="font-size:12px;color:var(--muted)">' + jc.scores + ' score · ' +
      jc.shown + ' shown</span></div>' +
      '<p style="margin:7px 0 0;font-size:12.5px;color:var(--muted)">Two switches, not always the same ' +
        'answer.</p>' +
      '<div class="tbl" style="margin-top:12px">' +
        '<div class="tr grid th" style="grid-template-columns:minmax(0,1fr) 74px 66px;height:32px">' +
          '<span>Person</span><span>On page</span><span>Scores</span></div>' +
        p.jury.map((j, i) =>
          '<div class="tr grid" style="grid-template-columns:minmax(0,1fr) 74px 66px;height:56px">' +
          '<span style="display:flex;align-items:center;gap:10px;min-width:0">' +
          '<span class="avatar" style="width:28px;height:28px;font-size:10px;' +
            'background:var(--primary-soft);color:var(--primary-dark)">' + j.ini + '</span>' +
          '<span style="min-width:0"><span style="font-size:13px;font-weight:600">' + esc(j.name) +
          '</span><div style="font-size:11.5px;color:var(--muted)">' + esc(j.role) +
          (j.note ? ' · <span style="color:var(--warn)">' + esc(j.note) + '</span>' : '') +
          '</div></span></span>' +
          '<button class="sw' + (j.shown ? ' on' : '') + '" data-act="jshown" data-i="' + i +
            '"><i></i></button>' +
          '<button class="sw' + (j.scores ? ' on' : '') + '" data-act="jscore" data-i="' + i +
            '"><i></i></button></div>').join('') + '</div>' +
      (jc.shown !== jc.scores ? '<div class="ban warn" style="margin-top:12px">' +
        '<span class="dot"></span><div><strong style="font-size:13px;color:var(--warn)">The page ' +
        'will show ' + jc.shown + ', the round has ' + jc.scores + ' seats</strong>' +
        '<p style="margin:5px 0 0;font-size:12.5px">Allowed &#8212; which is why the public section never ' +
          'prints a count.</p></div></div>' : '') + '</div>';
  },

  prizes(p, onRung){
    const total = M.prizeTotal(p);
    const covered = p.prizes.filter(z => z.level.kind === 'rank')
      .reduce((a, z) => Math.max(a, z.level.to), 0);
    const cash = p.prizes.filter(z => z.cash).length;
    /* The old table gave five columns equal weight and pushed the money — the
       thing anyone opens this page for — into a grey caption. The total is now
       the headline, the rank badge carries the place, and "paid to" is a chip on
       the row rather than a column of repeated sentences. */
    const rankBadge = z => {
      if(z.level.kind !== 'rank') return '';
      const n = z.level.from;
      return '<span class="pzr' + (n <= 3 ? ' top' : '') + '">' + n + '</span>';
    };
    return '<div style="margin-top:' + (onRung ? '4px' : '26px;padding-top:24px;border-top:1px ' +
      'solid var(--line-soft)') + '">' +
      (onRung ? '' : '<h2 style="font-size:18px;font-weight:700;margin-bottom:14px">Prizes</h2>') +

      '<div class="pzsum">' +
        '<div><div class="lbl">Committed</div>' +
          '<div class="pztot num">' + M.money(total) + '</div></div>' +
        '<div><div class="lbl">Prizes</div>' +
          '<div class="pzn num">' + p.prizes.length + '</div>' +
          '<div class="pzs">' + cash + ' with cash</div></div>' +
        (covered ? '<div><div class="lbl">Places covered</div>' +
          '<div class="pzn num">1&#8211;' + covered + '</div>' +
          '<div class="pzs">by rank</div></div>' : '') +
      '</div>' +

      (p.prizes.length
        ? '<div class="pzlist">' + p.prizes.map((z, i) =>
            '<div class="pzrow">' +
              '<span class="pzlvl">' + rankBadge(z) +
                (z.level.kind === 'rank'
                  ? '<span><span class="pzname pzrank-edit">' +
                    '<input class="in num pzrankin" data-bind="prize.' + i + '.level.from" ' +
                      'value="' + z.level.from + '" title="From place">' +
                    ' &#8211; <input class="in num pzrankin" data-bind="prize.' + i +
                      '.level.to" value="' + z.level.to + '" title="To place">' + '</span>' +
                    '<span class="pzkind">' + M.prizeKind(z.level) + '</span></span>'
                  : '<span><span class="pzname">' + M.prizeLevel(z.level) + '</span>' +
                    '<span class="pzkind">' + M.prizeKind(z.level) + '</span></span>') +
                '</span>' +
              '<span class="pzitems">' +
                '<input class="in pzitemin" data-bind="prize.' + i + '.items.0.0" ' +
                  'value="' + esc(z.items[0] ? z.items[0][0] : '') + '" placeholder="What they get">' +
                (z.items.length > 1 ? '<span class="pzmore"> +' + (z.items.length - 1) +
                  ' more</span>' : '') +
                '<select class="sel pzto" data-bind="prize.' + i + '.paidTo">' +
                  '<option value="entry"' + (z.paidTo === 'entry' ? ' selected' : '') +
                  '>Paid to the entry</option>' +
                  '<option value="member"' + (z.paidTo === 'member' ? ' selected' : '') +
                  '>Paid to each member</option>' +
                '</select>' +
              '</span>' +
              '<span class="pzval num">' +
                '<input class="in num pzcashin" data-bind="prize.' + i + '.cash" ' +
                  'value="' + (z.cash || 0) + '" placeholder="0">' +
              '</span>' +
              '<button class="ic pzx" data-act="delprize" data-i="' + i +
                '" aria-label="Remove this prize">' + ic('x',11,2.2) + '</button>' +
            '</div>').join('') + '</div>'
        : '<div class="pzempty">No prizes yet.</div>') +

      '<button class="link" data-act="addprize" style="display:inline-flex;align-items:center;' +
        'gap:7px;margin-top:15px">' + ic('plus',12,2.4) + 'Add a prize</button>' +
      '</div>';
  },

  partners(p){
    const shown = p.partners.filter(x => x.shown).length;
    return '<div>' +
      '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:12px">' +
      '<span class="lbl">Logos</span>' +
      '<span class="num" style="font-size:12.5px;color:var(--muted)">' + p.partners.length +
        ' added · ' + shown + ' shown</span></div>' +
      '<div style="margin-top:10px"><div class="fr h" ' +
        'style="grid-template-columns:minmax(0,1fr) minmax(0,160px) 60px 13px">' +
        '<span>Name</span><span>Tier</span><span>Shown</span><span></span></div>' +
      (p.partners.length ? p.partners.map((x, i) =>
        '<div class="fr" style="grid-template-columns:minmax(0,1fr) minmax(0,160px) 60px 13px;' +
          'align-items:center">' +
        '<input class="in" data-bind="partner.' + i + '.name" value="' + esc(x.name) +
          '" style="border:0;padding:0;font-size:13.5px;font-weight:600">' +
        '<input class="in" data-bind="partner.' + i + '.tier" value="' + esc(x.tier) +
          '" style="border:0;padding:0;font-size:13px;color:var(--muted)">' +
        '<button class="sw' + (x.shown ? ' on' : '') + '" data-act="pshown" data-i="' + i +
          '"><i></i></button>' +
        '<button class="ic" data-act="delpartner" data-i="' + i + '">' + ic('x',11,2.2) +
          '</button></div>').join('')
        : '') + '</div>' +
      '<button class="link" data-act="addpartner" style="display:inline-flex;align-items:center;' +
        'gap:7px;margin-top:13px">' + ic('plus',12,2.4) + 'Add a partner</button>' +
      '<div class="two" style="margin-top:22px;padding-top:20px;border-top:1px solid var(--line-soft)">' +
        V.note3('Grouped by tier','The public page clusters logos under the tier text you type here ' +
          '— there is no fixed list of tiers, so name them however this initiative sponsors it.') +
        V.note3('Off by default until you add one','Page sections shows Partners as waiting until ' +
          'there is at least one logo here to switch on.') +
      '</div></div>';
  }
};
