/* Talent Pool self-check — run with: node check-pool.js
   Guards the one rule that must never regress: a private profile's hidden H2S fields
   (email, mobile, WhatsApp, date of birth, gender, city, GitHub, LinkedIn) never render,
   search or export. Also: participant links only leave as http(s). */
global.localStorage = { getItem(){}, setItem(){} };
const fs = require('fs'), assert = require('assert'), vm = require('vm');
/* loaded as plain scripts, in index.html order, the way the browser does */
vm.runInThisContext(['data.js','model.js','views.js','manage.js','public.js','app.js']
  .map(f => fs.readFileSync(__dirname + '/' + f, 'utf8')).join('\n')
  .replace(/document.addEventListener\('DOMContentLoaded'[^\n]*/, ''));

APP.ui = {};
const f = APP.poolUI(), priv = DB.people.filter(M.isPrivate);
/* a hidden value that also sits in a visible field (city = state, say) isn't a secret */
const secret = u => { const open = [u.name, u.state, u.country, u.occupation].join(' ');
  return M.PFIELDS.filter(x => x[3] && u[x[0]] && u[x[0]].length > 4 && !open.includes(u[x[0]])).map(x => u[x[0]]); };
assert(priv.length, 'seed has private profiles');
priv.forEach(p => {
  secret(p).forEach(v => {
    if(v !== 'https://link.com') assert.equal(M.poolRows({ q:v }).filter(x => x.id === p.id).length, 0, 'searchable: ' + p.id + ' ' + v);
  });
  f.open = [p.id]; f.mode = 'profile';
  const h = V.pool();
  [p.email, p.mobile, p.whatsapp, p.city && p.city !== p.state && p.city + ', ', p.dob && M.date(p.dob)].filter(Boolean)
    .forEach(v => assert(!h.includes(v), 'profile leaks ' + v + ': ' + p.id));
  assert(h.includes('has a private profile') && h.includes('Hidden by'), 'private notice: ' + p.id);
});
f.open = null;
const list = V.pool();
priv.forEach(p => assert(!list.includes(p.email) && !list.includes(p.mobile), 'list leaks: ' + p.id));
priv.forEach(p => M.PFIELDS.filter(x => x[3]).forEach(x => assert.strictEqual(M.shown(p)[x[0]], null, 'export reads M.shown')));

assert.equal(M.safeUrl('javascript:alert(1)'), '');
assert.equal(M.safeUrl('https://github.com/x'), 'https://github.com/x');
assert.equal(M.age('2010-09-02'), 16);
assert.equal(M.stamp('2026-09-02T16:27'), '2 Sep 2026, 4:27 PM');

f.open = ['u01']; f.mode = 'profile';
assert(/Contact[\s\S]*Personal[\s\S]*Location[\s\S]*Links[\s\S]*Registration/.test(V.pool()), 'public profile sections');
f.open = null;
['loading','error','empty'].forEach(s => assert(V.pool(s).includes('pstate') || V.pool(s).includes('aria-busy'), s));
assert(V.pool('large').includes('2,300'), 'large preview');
f.q = 'zzzz'; assert(V.pool().includes('No participant matches “zzzz”')); f.q = '';

/* removed for good: Teams, status tabs, bulk selection, the checkbox column, team actions */
const page = V.pool();
assert(!/pool-view|data-k="status"|pool-sel|pchk|pbulk|Teams<\/button>/.test(page), 'teams, tabs, selection and checkboxes are gone');
f.open = ['u01']; f.mode = 'manage'; const mg = V.pool();
assert(!/Move to another team|Move to a new team|Remove from team/.test(mg) && mg.includes('Add to an initiative'), 'no team actions in Manage');
f.open = null;
const before = M.seat(M.person('u01'), 'icc-sc-27').team;
assert.equal(M.act(['u01'], { type:'add', pid:'icc-sc-27' }), null); assert.equal(M.seat(M.person('u01'), 'icc-sc-27').team, before, 'adding someone already in an initiative changes nothing');
console.log('talent pool: ok');
