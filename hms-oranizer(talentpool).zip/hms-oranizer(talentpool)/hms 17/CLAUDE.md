# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

A wired prototype of a sponsor-facing workspace for running hackathon-style initiatives (H2S / ICC branding in the sample data). It is **not a click-through** — there is one in-memory model (`DB`) and everything on screen is derived from it live. No build step, no package manager, no server, no dependencies beyond two Google Fonts.

## Running it

Open `index.html` directly in a browser. That's the entire dev loop — edit a `.js`/`.css` file, refresh.

The one check is `node check-pool.js` — it guards that a private profile (`vis:'private'`, gated by `M.PFIELDS` + `M.shown`) never renders, searches or exports its hidden H2S fields. There is no build, lint, or package command in this repo (no `package.json`). Do not introduce a build step, bundler, or test framework unless the user explicitly asks for one — that would break the "open the file, no dependencies" model the prototype is built on.

State persists to `localStorage` under the key `APP.KEY` (`'hms.prototype.v1'`) so a refresh doesn't lose changes made while clicking through. The "Reset the prototype" action in the header (`data-act="reset"`) clears it and reloads to the seeded state.

## Load order (index.html)

Scripts are plain globals loaded in this fixed order — each one depends on the previous:

```
data.js  → CATALOGUE, DB           (static catalogue + seed data)
model.js → M                        (derived values, all business logic)
views.js → V, RUNGS-adjacent chrome (portfolio + initiative-level pages)
manage.js→ MG, RUNGS                (the five-rung "Manage" canvas)
public.js→ PUB                      (the participant-facing public page)
app.js   → APP                      (routing, event delegation, persistence)
```

Get the ordering wrong (e.g. reference `M` from inside `data.js`) and it breaks — these are `<script>` tags, not modules.

## Core architectural rule: nothing is stored that can be derived

This is the single most important thing to internalize before editing anything. `model.js`'s own header states it: *"No stored completion flags anywhere. If a value can be worked out from something else, it is worked out here and never written back."*

Concretely:
- Whether a step/section is "done" (`M.stepDone`, `M.sectionState`) is computed from the initiative's actual data every render, never cached on the object.
- The initiative's date **window** (`5 Oct 2026 — 21 Feb 2027 · 20 weeks`) is computed from the first module's open date and the last module's close date (`M.window`) — never typed in directly.
- The public page's sections (`public.js`) are composed from `M.sectionState(p, id)`, which reads live off registration/team/schedule/etc. Eight of eleven sections are fully derived; only About, Partners and FAQ are sponsor-written.
- Conflicts (`M.conflicts`) are computed by walking module order + dates each render — nothing is flagged and stored.
- The five-rung ladder state (`M.rungState`) is computed, not stored.

**When adding a feature, first ask "can this be computed from what already exists in `DB`?" before adding a new field.** If you add a persisted flag for something derivable, that's against the grain of this codebase.

## Data model (`data.js`)

- `CATALOGUE` — the static rulebook: 6 initiative **types** (each with a default module `flow`), the 9 possible **modules** (registration, team, quiz, submission, evaluation, feedback, webinar, mentor, custom), the 12 public-page **sections** (with `from:` describing where each is derived from, and `locked:true` for hero/register which can't be reordered or turned off), field types, cover gradients, currencies, and the fixed H2S focus-area **tag** vocabulary.
- `DB` — the seed: `org`, portfolio-wide `reach` stats, and `initiatives[]`. Each initiative carries `modules` (its chosen flow), `config` (per-module settings, keyed by module id), `dates`, `prizes`, `jury`, `mentors`, `partners`, `entries`, `panel`, `live` (observed run-time figures), `messages`, etc.
- Everything in `data.js` is sample data only — comments there explicitly say nothing here is computed.

## The model layer (`model.js`, global `M`)

All business logic lives here, organized by section comment headers: lookups, formatting, the flow (add/remove/move modules), approval, branding, entry fee, tags, the design-page sub-rail, timeline/schedule, the "ladder" (5 rungs: design → process → timeline → approval → live/result), the public page's section readiness, prizes, jury, live/health, portfolio-wide needs, and the 4-step creation wizard.

Two things worth understanding before touching scheduling code:
- **Schedule model** (`M.ensureSchedule` / `M.applySchedule`): every initiative is anchored by exactly two dates — start (`schedule.anchor`) and end (`schedule.end`). Every other module's dates are stored as an **offset** (`{start, dur}`) from the anchor, recomputed into `p.dates[k]` whenever anything changes. Never write `p.dates[k]` directly outside of `applySchedule` — anything that does will be silently overwritten the next time the schedule recomputes.
- **Conflicts are consequences, not blocks** (`M.GATES`, `M.conflicts`): only a *gate* module (quiz, evaluation — something that decides who carries on) overlapping what follows is flagged. Two non-gate modules running concurrently (e.g. Registration + Team formation) is deliberate and intentionally never flagged. Fixes are always offered (`fixKind`/`fixTo`), never forced.

## View layer

- `views.js` (`V`) — chrome (header/sidebar/drawer), the portfolio overview, the initiatives list, the 4-step creation wizard, and initiative-level pages (initiative home, participants, panel/evaluator, comms).
- `manage.js` (`MG`, plus `RUNGS`) — the "five-rung canvas" reached at `#/p/:id/manage/:rung/:step`. Rungs are `design`, `process`, `timeline`, `approval`, `live`/`result` (see `RUNGS` array at the top of the file). `MG.render(p, rung, step)` dispatches to the rung's renderer.
- `public.js` (`PUB`) — the participant-facing public page. `PUB.screen(p)` renders the full page; the same section renderers are reused for the "Live preview" inside `manage.js`'s `preview` step, so preview and reality can never drift apart.

## Routing & event handling (`app.js`, global `APP`)

- Hash-based router: `location.hash` is parsed by `APP.parts()` and dispatched in `APP.render()`. No history API, no route table — just an `if/else` chain matching `q[0]`/`q[1]`/... segments. Routes: `#/overview`, `#/initiatives`, `#/pool` (Talent Pool — `DB.people`, every person across every initiative; `#/pool/loading|empty|error|large` preview those states), `#/initiatives/new`, `#/public/:id`, `#/p/:id`, `#/p/:id/participants|panel|score|comms`, `#/p/:id/manage/:rung/:step`.
- **Everything re-renders from scratch on every state change.** There is no virtual DOM/diffing — `APP.render()` sets `APP.root.innerHTML` wholesale. `APP.repaintSoft()` / `APP.repaintVenue()` are the two narrow exceptions that patch specific DOM nodes in place so a text input doesn't lose focus mid-keystroke.
- **Event delegation, not per-element listeners.** A single `click` handler (`APP.onClick`) reads `data-act` off the closest ancestor and switches on it; a single `input`/`change` handler (`APP.onInput`) reads `data-bind` and routes to the right nested field via regex matches (e.g. `bind.match(/^fld\.([a-z]+)\.(\d+)\.(name|opts|type|rule)$/)`). **When adding a new editable field, follow this pattern**: render with `data-bind="some.path"`, then add a branch/regex in `APP.onInput` (or `APP.onClick` for `data-act`) rather than wiring a one-off listener.
- Drag-to-reorder is generic: `data-drag="<group>"` + `data-di="<index>"` on rows, and `APP.list(p, group)` (a `switch` on the group prefix — `mod`, `qcat`, `fld:*`, `param`, `fq`, `tb`, `sec`, `slot`) returns the backing array to splice. New reorderable lists need a case added there.
- `APP.touch(p)` stamps `p.updatedAt` and calls `APP.save()` (writes `DB` to `localStorage`) — only called when a click/input handler detects the initiative object actually changed (`JSON.stringify(p) !== before`), so "last edited" reflects real edits, not re-renders.
- `M.today()` is hardcoded to `'2027-01-11'` — this is the prototype's fixed "now" for all stage/live calculations, not `Date.now()`.

## Styling (`app.css`)

Design tokens are CSS custom properties on `:root` (`--primary`, `--ink`, `--muted`, `--line`, `--ok`/`--warn` + their `-soft` backgrounds, `--r`/`--r-sm`/`--r-pill` for border radii, `--sidebar`/`--rail` widths). Reuse these tokens rather than hardcoding colors/radii when adding UI.

## Conventions to preserve when extending

- Keep derivable values in `model.js`; keep sample/catalogue data in `data.js`; don't let `views.js`/`manage.js`/`public.js` compute business logic inline — they call into `M`.
- New module types go in `CATALOGUE.modules` (data.js) + get a case in the relevant `M.moduleLine`/`M.moduleReady` switches (model.js) + a panel in `MG.modPanel` (manage.js).
- New public-page sections go in `CATALOGUE.sections` (data.js) + a case in `M.sectionState` (model.js) + a renderer in `public.js`'s `PUB.section` dispatch.
- Follow the existing terse, comment-sparse style; the few comments present explain *why* (a non-obvious rule or invariant), not *what*.
