/* ============================================================
   app.js — routing, actions, and the one render loop
   ============================================================ */

const APP = {
  root:null,
  ui:{},
  focusSel:null,
  dnd:{ group:null, from:-1, to:-1 },
  drawerOpen:false,

  KEY:'hms.prototype.v1',
  save(){
    try{ localStorage.setItem(APP.KEY, JSON.stringify(DB)); }catch(e){}
  },
  /* stamp the initiative only when something in it actually changed — the header
     reports a real last-edited time, not the fact that a screen was drawn */
  touch(p){ if(p) p.updatedAt = Date.now(); APP.save(); },
  load(){
    try{
      const raw = localStorage.getItem(APP.KEY);
      if(!raw) return;
      const saved = JSON.parse(raw);
      if(saved && saved.initiatives && saved.initiatives.length){
        DB.initiatives = saved.initiatives;
        if(saved.org) DB.org = saved.org;
        /* people saved before the H2S field set (no timestamp) belong to an older seed — keep the new one */
        if(saved.people && saved.people.every(u => u.timestamp)) DB.people = saved.people;
      }
    }catch(e){}
  },
  reset(){
    try{ localStorage.removeItem(APP.KEY); }catch(e){}
    location.reload();
  },

  boot(){
    APP.root = document.getElementById('app');
    APP.load();
    window.addEventListener('hashchange', APP.render);
    document.addEventListener('click', APP.onClick, true);
    document.addEventListener('input', APP.onInput, true);
    document.addEventListener('change', APP.onInput, true);
    document.addEventListener('mousedown', APP.onGrip, true);
    document.addEventListener('dragstart', APP.onDragStart, true);
    document.addEventListener('dragover',  APP.onDragOver, true);
    document.addEventListener('drop',      APP.onDrop, true);
    document.addEventListener('dragend',   APP.onDragEnd, true);
    window.addEventListener('scroll', () => { if(APP.drawerOpen) APP.closeDrawer(); }, true);
    /* talent pool keys: Esc closes the drawer, / jumps to search */
    document.addEventListener('keydown', e => {
      const f = APP.ui.pool, typing = /^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName);
      if(!f || APP.parts()[0] !== 'pool') return;
      if(e.key === 'Escape' && f.open) APP.poolAct('pool-close', document.body);
      else if(typing) return;
      else if(e.key === '/' && !f.open){
        const s = document.querySelector('[data-bind="pool.q"]');
        if(s){ e.preventDefault(); s.focus(); }
      }
    });
    if(!location.hash) location.hash = '#/overview';
    APP.render();
  },

  parts(){
    return (location.hash || '#/overview').replace(/^#\/?/, '').split('/').filter(Boolean);
  },

  render(){
    APP.drawerOpen = false;
    const q = APP.parts();
    let html = '';
    try{
      if(q[0] === 'overview' || !q.length)        html = V.overview();
      else if(q[0] === 'initiatives' && q[1] === 'new') html = V.create();
      else if(q[0] === 'initiatives')                html = V.initiatives();
      else if(q[0] === 'pool')                       html = V.pool(q[1]);
      else if(q[0] === 'public'){
        const p = M.initiative(q[1]);
        html = p ? PUB.screen(p) : APP.missing();
      }
      else if(q[0] === 'p'){
        const p = M.initiative(q[1]);
        if(!p) html = APP.missing();
        else if(!q[2])                            html = V.initiative(p);
        else if(q[2] === 'participants')          html = V.participants(p);
        else if(q[2] === 'panel' && q[3] === 'open') html = V.panel(p, q[4]);
        else if(q[2] === 'panel' && q[3])         html = V.evaluator(p, q[3]);
        else if(q[2] === 'panel')                 html = V.panel(p);
        else if(q[2] === 'score')                 html = V.score(p, decodeURIComponent(q[3] || ''));
        else if(q[2] === 'comms')                 html = V.comms(p);
        else if(q[2] === 'manage'){
          const rung = RUNGS.some(r => r[0] === q[3]) ? q[3] : 'design';
          html = MG.render(p, rung, q[4]);
        }
        else html = APP.missing();
      }
      else html = APP.missing();
    }catch(err){
      html = APP.crash(err);
      /* eslint-disable no-console */
      console.error('[HMS]', err);
    }
    APP.root.innerHTML = html;
    APP.save();
    if(APP.focusSel){
      const t = document.querySelector(APP.focusSel);
      APP.focusSel = null;
      if(t){ t.focus(); t.scrollIntoView({ block:'center' }); return; }
    }
    window.scrollTo(0, 0);
  },

  missing(){
    return V.chrome('<div class="wrap"><h1 style="font-size:26px;font-weight:900">Nothing here' +
      '</h1><p style="margin:10px 0 0;font-size:14px;color:var(--muted)">That initiative does not ' +
      'exist, or the link is old.</p><a class="btn p" href="#/initiatives" style="margin-top:18px">' +
      'Back to Initiatives</a></div>', 'initiatives');
  },
  crash(err){
    return V.chrome('<div class="wrap"><h1 style="font-size:24px;font-weight:900">Something broke' +
      '</h1><p style="margin:10px 0 0;font-size:14px;color:var(--muted)">The screen threw an error ' +
      'rather than rendering a wrong one.</p><pre style="margin-top:16px;padding:14px;' +
      'background:var(--bg-soft);border:1px solid var(--line);border-radius:4px;font-size:12px;' +
      'overflow:auto">' + esc(err && err.stack || err) + '</pre></div>', 'initiatives');
  },

  /* ---------------- helpers ---------------- */
  here(){ const q = APP.parts(); return q[0] === 'p' ? M.initiative(q[1]) : null; },
  toast(msg, undo){
    const t = document.getElementById('toast');
    t.innerHTML = esc(msg) + (undo ? '<button data-act="pool-undo">Undo</button>' : '');
    t.classList.toggle('act', !!undo);
    t.classList.add('show');
    clearTimeout(APP._t); APP._t = setTimeout(() => t.classList.remove('show'), undo ? 7000 : 2600);
  },
  closeDrawer(){
    APP.drawerOpen = false;
    const d = document.getElementById('drawer'); if(d) d.innerHTML = '';
  },

  /* ---------------- drag to reorder ----------------
     A row is only draggable while its grip is held, so text selection inside
     the row's own inputs still works. One handler serves every list; the group
     name on the row says which array it belongs to. */
  list(p, group){
    const g = group.split(':');
    switch(g[0]){
      case 'mod':   return p.modules;
      case 'qcat':  return (p.config.quiz || {}).categories;
      case 'fld':   return ((p.config || {})[g[1]] || {}).fields;
      case 'param': return (((p.config.evaluation || {}).categories || [])[+g[1]] || {}).params;
      case 'fq':    return (p.config.feedback || {}).questions;
      case 'tb':    return p.tiebreaks;
      case 'sec':   return M.sectionOrder(p);
      case 'slot':  return (p.config.mentor || {}).slots;
    }
    return null;
  },
  onGrip(ev){
    const grip = ev.target.closest('[data-grip]');
    if(!grip) return;
    const row = grip.closest('[data-drag]');
    if(row) row.setAttribute('draggable', 'true');
  },
  onDragStart(ev){
    const row = ev.target.closest('[data-drag]');
    if(!row){ return; }
    APP.dnd = { group:row.dataset.drag, from:+row.dataset.di, to:-1 };
    row.classList.add('dragging');
    if(ev.dataTransfer){
      ev.dataTransfer.effectAllowed = 'move';
      try{ ev.dataTransfer.setData('text/plain', row.dataset.di); }catch(e){}
    }
  },
  clearMarks(){
    document.querySelectorAll('.dropbefore,.dropafter')
      .forEach(n => n.classList.remove('dropbefore', 'dropafter'));
  },
  onDragOver(ev){
    if(!APP.dnd.group){
      if(ev.target.closest('[data-drop="cover"]')) ev.preventDefault();
      return;
    }
    const row = ev.target.closest('[data-drag="' + APP.dnd.group + '"]');
    if(!row) return;
    ev.preventDefault();
    if(ev.dataTransfer) ev.dataTransfer.dropEffect = 'move';
    const r = row.getBoundingClientRect();
    const after = (ev.clientY - r.top) > r.height / 2;
    APP.clearMarks();
    row.classList.add(after ? 'dropafter' : 'dropbefore');
    APP.dnd.to = +row.dataset.di + (after ? 1 : 0);
  },
  onDrop(ev){
    if(!APP.dnd.group){ APP.onCoverDrop(ev); return; }
    ev.preventDefault();
    APP.applyDrop();
  },
  onDragEnd(){
    APP.clearMarks();
    document.querySelectorAll('.dragging').forEach(n => {
      n.classList.remove('dragging'); n.removeAttribute('draggable');
    });
    if(APP.dnd.group) APP.applyDrop();
  },
  applyDrop(){
    const d = APP.dnd; APP.dnd = { group:null, from:-1, to:-1 };
    if(!d.group || d.to < 0) return;
    const p = APP.here(); if(!p) return;
    const arr = APP.list(p, d.group);
    if(!arr) return;
    let to = d.to;
    if(to > d.from) to--;
    /* Registration is the anchor: it never moves, and nothing lands above it */
    if(d.group === 'mod'){
      if(d.from === 0) return;
      if(to < 1) to = 1;
    }
    if(to === d.from || to < 0 || to > arr.length - 1) return;
    arr.splice(to, 0, arr.splice(d.from, 1)[0]);
    APP.touch(p);
    APP.render();
  },

  /* ---------------- clicks ---------------- */
  onClick(ev){
    const el = ev.target.closest('[data-act]');
    if(!el){
      if(APP.drawerOpen && !ev.target.closest('.drawer')) APP.closeDrawer();
      return;
    }
    const act = el.dataset.act, p = APP.here();
    const stop = () => { ev.preventDefault(); ev.stopPropagation(); };

    /* chrome ------------------------------------------------ */
    if(act === 'drawer'){
      stop();
      const d = document.getElementById('drawer');
      if(APP.drawerOpen){ APP.closeDrawer(); return; }
      d.innerHTML = '<div class="drawer">' +
        '<div class="lbl" style="padding:0 12px 8px">Manage</div>' +
        V.side('initiatives', false).replace(/^<div class="side">|<\/div>$/g, '')
          .replace('<div class="lbl" style="padding:0 12px 8px">Manage</div>', '') + '</div>';
      APP.drawerOpen = true;
      return;
    }
    if(act === 'toast'){ stop(); APP.toast(el.dataset.msg); return; }
    if(act === 'reset'){ stop(); APP.reset(); return; }
    if(act.indexOf('pool-') === 0){ stop(); APP.poolAct(act, el); return; }

    /* create — a 4-step wizard (Type, Who can register, Format, Dates) that
       hands the sponsor a fully staffed Participant journey and Timeline
       instead of a blank one; nothing here creates the initiative until the
       last step, so backing out costs nothing. ------------------------ */
    if(act === 'wiztype'){
      stop();
      APP.ui.wizard = { step:2, type:el.dataset.type, audience:['anyone'], mode:'', shape:'', start:'', end:'' };
      APP.render();
      return;
    }
    if(act === 'wizaud'){
      stop();
      const w = APP.ui.wizard, v = el.dataset.v;
      if(v === 'anyone') w.audience = ['anyone'];
      else{
        w.audience = w.audience.filter(x => x !== 'anyone');
        const i = w.audience.indexOf(v);
        if(i > -1) w.audience.splice(i, 1); else w.audience.push(v);
        if(!w.audience.length) w.audience = ['anyone'];
      }
      APP.render();
      return;
    }
    if(act === 'wizmode'){ stop(); APP.ui.wizard.mode = el.dataset.v; APP.render(); return; }
    if(act === 'wizshape'){ stop(); APP.ui.wizard.shape = el.dataset.v; APP.render(); return; }
    if(act === 'wiznext'){
      stop();
      if(el.disabled) return;
      APP.ui.wizard.step++;
      APP.render();
      return;
    }
    if(act === 'wizback'){
      stop();
      const w = APP.ui.wizard;
      if(w.step <= 1){ location.hash = '#/initiatives'; return; }
      w.step--;
      APP.render();
      return;
    }
    if(act === 'wizcreate'){
      stop();
      if(el.disabled) return;
      const np = M.newInitiativeFromWizard(APP.ui.wizard);
      APP.ui.wizard = null;
      /* the initiative is already made — these three seconds show what was made
         with it, rather than dropping the person onto a full canvas cold */
      APP.ui.creating = np.id;
      APP.render();
      setTimeout(function(){
        APP.ui.creating = null;
        location.hash = '#/p/' + np.id + '/manage/design';
      }, 3000);
      return;
    }

    if(!p) return;
    stop();
    let go = null;
    const before = JSON.stringify(p);

    switch(act){
      /* design ------------------------------------------- */
      case 'fmt':
        p.format.mode = el.dataset.v;
        if(p.format.mode === 'virtual'){ p.format.city = ''; p.format.venue = ''; }
        APP.toast(p.format.mode === 'virtual'
          ? 'Virtual — the Venue step has left the rail'
          : 'Venue added to the rail, tagged FROM FORMAT');
        break;
      case 'vis': p.visibility = el.dataset.v; break;
      case 'cover': {
        const c = CATALOGUE.covers[+el.dataset.i];
        M.brand(p).cover = { kind:'gradient', value:c[1], name:c[0] };
        break;
      }
      case 'clearcover': M.brand(p).cover = null; break;
      case 'accent': M.brand(p).accent = el.dataset.v; break;
      case 'sendapproval':
        p.approval = { state:'sent', sentOn:new Date().toISOString().slice(0, 10) };
        APP.toast('Sent to ' + DB.org.manager.name + '. You will get an email when it is approved.');
        break;
      case 'withdrawapproval':
        p.approval = { state:'none' };
        APP.toast('Withdrawn. Nothing was published, and nobody was told.');
        break;
      case 'paid': {
        const e = M.entry(p); p.format.entry = e;
        e.paid = el.dataset.v === 'paid';
        if(e.paid && !e.fee) e.fee = 25;
        APP.toast(e.paid
          ? 'Paid entry — Registration gains a payment step, and the price now shows on every ' +
            'Register button'
          : 'Free to enter — the payment step has left Registration');
        break;
      }
      case 'per': { const e = M.entry(p); p.format.entry = e; e.per = el.dataset.v; break; }
      case 'addfocus':
        p.focus.push({ title:'', body:'' });
        break;
      case 'delfocus': p.focus.splice(+el.dataset.i, 1); break;
      case 'addpartner':
        p.partners.push({ name:'New partner', tier:'Community', shown:true });
        APP.focusSel = '[data-bind="partner.' + (p.partners.length - 1) + '.name"]';
        break;
      case 'delpartner': p.partners.splice(+el.dataset.i, 1); break;
      case 'pshown': p.partners[+el.dataset.i].shown = !p.partners[+el.dataset.i].shown; break;
      case 'tag': M.toggleTag(p, el.dataset.t); break;
      case 'reqtag':
        APP.toast('Sent to ' + DB.org.manager.name + '. A tag added for you is added for every ' +
          'sponsor — that is what keeps matching honest.');
        break;
      case 'startabout':
        p.about.mode = 'text';
        p.about.title = p.about.title || 'About this initiative';
        p.about.body = ['Say what this initiative is for, who it is aimed at, and what a participant ' +
          'actually does.'];
        break;
      case 'starthtml':
        p.about.mode = 'html';
        p.about.title = p.about.title || 'About this initiative';
        p.about.html = '<h3>Three problems, one season</h3>\n<p>Pick the one you want to solve.</p>';
        break;
      case 'agent':
        APP.toast('Locked — ' + DB.org.manager.name + ' switches it on per organisation. Nothing ' +
          'on this rung waits on it.');
        return;
      case 'aboutmode':
        if(el.dataset.v === 'html' && !p.about.html)
          p.about.html = p.about.body.map(x => '<p>' + x + '</p>').join('\n');
        p.about.mode = el.dataset.v;
        break;
      case 'sect': M.toggleSection(p, el.dataset.v); break;
      /* the single-pointer / keyboard path for reordering, beside the drag handle */
      case 'secmove': M.moveSection(p, el.dataset.v, +el.dataset.d); break;

      /* process ------------------------------------------ */
      case 'addmod':
        M.addModule(p, el.dataset.k);
        go = '#/p/' + p.id + '/manage/process/' + el.dataset.k;
        APP.toast(M.mod(el.dataset.k).name + ' added — it now wants a date on the Timeline');
        break;
      case 'delmod':{
        const k = el.dataset.k;
        M.removeModule(p, k);
        APP.toast(M.mod(k).name + ' removed — its date and its messages went with it');
        go = '#/p/' + p.id + '/manage/process';
        break;
      }
      case 'up': M.moveModule(p, el.dataset.k, -1); break;
      case 'addfield': {
        const c = p.config.registration = p.config.registration || {};
        c.fields = c.fields || [];
        c.fields.push({ name:'', type:'Short text', rule:'Optional' });
        APP.focusSel = '[data-bind="fld.registration.' + (c.fields.length - 1) + '.name"]';
        break;
      }
      case 'delfield': p.config.registration.fields.splice(+el.dataset.i, 1); break;
      case 'addsubfield': {
        const c = p.config.submission = p.config.submission || {};
        if(!c.fields) c.fields = M.subFields();
        c.fields.push({ name:'', type:'Short text', rule:'Optional' });
        APP.focusSel = '[data-bind="fld.submission.' + (c.fields.length - 1) + '.name"]';
        break;
      }
      case 'delsubfield': p.config.submission.fields.splice(+el.dataset.i, 1); break;
      case 'toggleedit': {
        const s = el.dataset.scope;
        APP.ui.fieldEdit = APP.ui.fieldEdit || {};
        APP.ui.fieldEdit[s] = !APP.ui.fieldEdit[s];
        break;
      }
      case 'schedrow': {
        const k = el.dataset.k;
        APP.ui.schedOpen = APP.ui.schedOpen || {};
        APP.ui.schedOpen[k] = !APP.ui.schedOpen[k];
        break;
      }
      case 'aud':{
        const c = p.config.registration, v = el.dataset.v;
        c.audience = c.audience || ['anyone'];
        if(v === 'anyone') c.audience = ['anyone'];
        else{
          c.audience = c.audience.filter(x => x !== 'anyone');
          const i = c.audience.indexOf(v);
          if(i > -1) c.audience.splice(i, 1); else c.audience.push(v);
          if(!c.audience.length) c.audience = ['anyone'];
        }
        break;
      }
      case 'solo': p.config.team.solo = (p.config.team.solo === false); break;
      case 'addcat':
        (p.config.quiz.categories = p.config.quiz.categories || [])
          .push({ name:'New category', questions:5 });
        break;
      case 'delcat': p.config.quiz.categories.splice(+el.dataset.i, 1); break;
      case 'adv': p.config.quiz.advance = el.dataset.v; break;
      case 'addslot': {
        const c = p.config.mentor = p.config.mentor || {};
        c.slots = c.slots || [];
        c.slots.push(['', '', 4, 30]);
        APP.focusSel = '[data-bind="slot.' + (c.slots.length - 1) + '.0"]';
        break;
      }
      case 'delslot': p.config.mentor.slots.splice(+el.dataset.i, 1); break;
      case 'mentwho': p.config.mentor.who = el.dataset.v; break;
      case 'menthow': p.config.mentor.how = el.dataset.v; break;
      case 'ai':
        p.config.evaluation.ai = el.dataset.v;
        if(el.dataset.v === 'round')
          APP.toast('AI is a round now — its own read-only rubric, and no row on the timeline');
        break;
      case 'addevalcat':
        p.config.evaluation.categories.push({ name:'New category', share:0,
          params:[['A parameter','',10,100]] });
        break;
      case 'delevalcat': {
        const cats = p.config.evaluation.categories;
        const gone = cats.splice(+el.dataset.c, 1)[0];
        if(gone) APP.toast('“' + gone.name + '” removed. Its share of the final score is free ' +
          'again — the shares no longer total 100%.');
        break;
      }
      case 'delparam':
        p.config.evaluation.categories[+el.dataset.c].params.splice(+el.dataset.i, 1);
        break;

      /* timeline ----------------------------------------- */
      case 'pubdate':{
        const k = el.dataset.k;
        p.publicDates[k] = (p.publicDates[k] === false);
        break;
      }
      case 'fixdate':{
        const k = el.dataset.k, target = el.dataset.v;
        if(k === 'results'){
          p.resultsAt = target;
          APP.toast('Moved. Results now land after everything else closes.');
          break;
        }
        if(k.indexOf('trim:') === 0){
          const mod = k.slice(5);
          const s = M.ensureSchedule(p);
          s.offsets[mod] = s.offsets[mod] || { start:7, dur:14 };
          s.offsets[mod].dur = Math.max(1, M.days(p.dates[mod][0], target));
          M.applySchedule(p);
          APP.toast('Trimmed to fit inside the initiative’s end date.');
          break;
        }
        const s = M.ensureSchedule(p);
        if(s.anchor){
          s.offsets[k] = s.offsets[k] || { start:7, dur:14 };
          s.offsets[k].start = M.days(s.anchor, target);
          M.applySchedule(p);
        } else {
          p.dates[k][0] = target;
        }
        APP.toast('Moved. The conflict is gone and the schedule has redrawn.');
        break;
      }

      /* result ------------------------------------------- */
      case 'winner': p.winnerRule = el.dataset.v; break;
      case 'tieup':{
        const i = +el.dataset.i;
        if(i > 0) p.tiebreaks.splice(i - 1, 0, p.tiebreaks.splice(i, 1)[0]);
        break;
      }
      case 'jshown': p.jury[+el.dataset.i].shown = !p.jury[+el.dataset.i].shown; break;
      case 'jscore': p.jury[+el.dataset.i].scores = !p.jury[+el.dataset.i].scores; break;
      case 'delprize': p.prizes.splice(+el.dataset.i, 1); break;
      case 'addprize':{
        const next = p.prizes.filter(z => z.level.kind === 'rank')
          .reduce((a, z) => Math.max(a, z.level.to), 0) + 1;
        p.prizes.push({ level:{ kind:'rank', from:next, to:next },
          items:[['Cash','Paid within 30 days','']], paidTo:'entry', decidedBy:'ranking',
          cash:5000 });
        APP.toast('Added at ' + M.ord(next) + ' place — every prize declares its own level');
        break;
      }

      /* participants ------------------------------------- */
      case 'entry':{
        const e = p.entries[+el.dataset.i];
        if(e.state === 'removed' || e.state === 'disqualified'){
          e.state = 'ok'; e.reason = '';
          APP.toast('Restored — the counts go back up and the record says it happened');
        } else if(e.state === 'flagged'){
          APP.toast('Review opens the entry, its submission and who flagged it');
          return;
        } else {
          e.state = 'removed';
          e.reason = 'Removed by you just now · reversible';
          APP.toast('Removed — out of the counts, still on the record, and reversible');
        }
        break;
      }
      default: return;
    }
    if(JSON.stringify(p) !== before) APP.touch(p);
    if(go && go !== location.hash) location.hash = go; else APP.render();
  },

  /* ---------------- talent pool ----------------
     Filters, lens, selection and the open panel are view state (APP.ui.pool); only
     memberships on DB.people change, and render() saves them. Each change keeps one
     snapshot so the toast can undo it. */
  poolUI(){
    return APP.ui.pool || (APP.ui.pool = { q:'', ini:'', country:'', vis:'', sort:'recent', per:25, page:1,
      open:null, mode:'profile', act:null, err:'' });
  },
  /* re-render without losing the page's or the panel's scroll position */
  poolRender(){
    const y = window.scrollY, b = document.querySelector('.psheet-b'), by = b ? b.scrollTop : 0;
    APP.render();
    window.scrollTo(0, y);
    const nb = document.querySelector('.psheet-b'); if(nb) nb.scrollTop = by;
  },
  /* run a change: snapshot, apply, close the panel, offer undo. Returns the error, if any. */
  poolDo(ids, a){
    if(!ids.length) return 'Pick at least one person.';
    const said = M.impact(ids, a)[0], snap = JSON.stringify(DB.people), err = M.act(ids, a);
    if(err) return err;
    APP.undo = snap;
    const f = APP.poolUI();
    /* land back on their profile to see the result */
    Object.assign(f, { mode:'profile', act:null, err:'' });
    APP.poolRender();
    APP.toast(said, true);
    return null;
  },
  poolAct(act, el){
    const f = APP.poolUI(), d = el.dataset;
    switch(act){
      case 'pool-filter': f[d.k] = d.v; f.page = 1; break;
      case 'pool-clear': Object.assign(f, { country:'', vis:'', page:1 }); break;
      case 'pool-page': f.page = +d.v; break;
      case 'pool-open': Object.assign(f, { open:[d.id], mode:'profile', act:null, err:'' }); break;
      case 'pool-manage': Object.assign(f, { open:[d.id || f.open[0]], mode:'manage', act:null, err:'' }); break;
      case 'pool-profile': Object.assign(f, { mode:'profile', act:null, err:'' }); break;
      case 'pool-close': Object.assign(f, { open:null, act:null, err:'' }); break;
      case 'pool-back': f.act = null; f.err = ''; break;
      case 'pool-pick': {
        const inis = M.actInis(f.open, d.v);
        const pid = inis.includes(f.ini) ? f.ini : inis.length === 1 ? inis[0] : '';
        f.act = { type:d.v, pid };
        f.err = '';
        break;
      }
      case 'pool-go': { const err = APP.poolDo(f.open, f.act); if(!err) return; f.err = err; break; }
      case 'pool-restore': {
        const snap = JSON.stringify(DB.people), u = M.person(d.id), err = M.restore(u, d.pid);
        if(err){ APP.toast(err); return; }
        APP.undo = snap;
        APP.poolRender();
        APP.toast(u.name + ' is back in ' + M.initiative(d.pid).name, true);
        return;
      }
      case 'pool-undo':
        if(APP.undo){ DB.people = JSON.parse(APP.undo); APP.undo = null; }
        document.getElementById('toast').classList.remove('show');
        break;
      case 'pool-csv': APP.poolCsv(f); return;
      default: return;
    }
    APP.poolRender();
  },
  poolInput(k, el){
    const f = APP.poolUI(), v = el.value;
    if(k === 'a.pid') f.act.pid = v;
    else if(['q','ini','country','vis','sort','per'].includes(k)){ f[k] = v; f.page = 1; }
    else return;
    f.err = '';
    APP.poolRender();
    if(el.tagName === 'INPUT'){
      const t = document.querySelector('[data-bind="pool.' + k + '"]');
      if(t){ t.focus(); t.setSelectionRange(v.length, v.length); }
    }
  },
  poolCsv(f){
    /* a leading = + - @ would run as a formula in a spreadsheet */
    const cell = s => '"' + String(s == null ? '' : s).replace(/^[=+\-@]/, "'$&").replace(/"/g, '""') + '"';
    /* the Data Centre's columns, through M.shown — a private profile exports what it shows */
    const rows = [['Timestamp','Status','Full Name','Profile'].concat(M.PFIELDS.map(x => x[1]),
      M.UTM.map(x => 'UTM ' + x[1]))].concat(M.poolRows(f).map(u => { const s = M.shown(u);
      return [s.timestamp.replace('T', ' '), s.status, s.name, M.isPrivate(u) ? 'Private' : 'Public']
        .concat(M.PFIELDS.map(x => s[x[0]] === null ? 'Hidden' : s[x[0]]), M.UTM.map(x => s.utm[x[0]] || '')); }));
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + rows.map(r => r.map(cell).join(',')).join('\r\n')],
      { type:'text/csv' }));
    a.download = 'talent-pool.csv';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 0);
  },

  /* ---------------- the cover image ---------------- */
  readCover(p, file){
    if(!file) return;
    if(!/^image\//.test(file.type)){
      APP.toast('That is not an image. JPG or PNG.'); return;
    }
    if(file.size > 1.5 * 1024 * 1024){
      APP.toast('That image is ' + Math.round(file.size / 1024 / 1024 * 10) / 10 +
        ' MB. Keep it under 1.5 MB so the page loads fast on a phone.');
      return;
    }
    const r = new FileReader();
    r.onload = () => {
      M.brand(p).cover = { kind:'image', value:r.result, name:file.name };
      APP.touch(p);
      APP.render();
      APP.toast('Cover set. It shows on the public page and in As it looks.');
    };
    r.readAsDataURL(file);
  },
  onCoverDrop(ev){
    const zone = ev.target.closest('[data-drop="cover"]');
    if(!zone) return null;
    const p = APP.here(); if(!p) return null;
    const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
    if(!f) return null;
    ev.preventDefault();
    APP.readCover(p, f);
    return true;
  },

  /* ---------------- typing ---------------- */
  onInput(ev){
    const el = ev.target, p = APP.here();

    if(el.dataset.act === 'wizstart'){ APP.ui.wizard.start = el.value || ''; APP.render(); return; }
    if(el.dataset.act === 'wizend'){ APP.ui.wizard.end = el.value || ''; APP.render(); return; }
    if((el.dataset.bind || '').indexOf('pool.') === 0){
      /* text boxes already rendered on every keystroke; their blur 'change' would steal focus back */
      if(!(ev.type === 'change' && el.tagName === 'INPUT')) APP.poolInput(el.dataset.bind.slice(5), el);
      return;
    }

    if(!p) return;
    p.updatedAt = Date.now();

    /* the Timeline asks for one date — everything else is an offset from it,
       recomputed into p.dates by M.applySchedule so the rest of the app
       (Live, the public page, conflicts) never has to know the difference. */
    if(el.dataset.act === 'schedanchor'){
      const s = M.ensureSchedule(p);
      s.anchor = el.value || null;
      M.applySchedule(p);
      APP.focusSel = '[data-act="schedanchor"]';
      APP.render();
      return;
    }
    if(el.dataset.act === 'schedend'){
      const s = M.ensureSchedule(p);
      s.end = el.value || null;
      M.applySchedule(p);
      APP.focusSel = '[data-act="schedend"]';
      APP.render();
      return;
    }
    if(el.dataset.act === 'regdur'){
      const s = M.ensureSchedule(p);
      s.regDur = parseInt(el.value, 10) || 1;
      M.applySchedule(p);
      APP.focusSel = '[data-act="regdur"]';
      APP.render();
      return;
    }
    if(el.dataset.act === 'schedoffset'){
      const s = M.ensureSchedule(p), k = el.dataset.k, f = el.dataset.f;
      s.offsets[k] = s.offsets[k] || { start:7, dur:14 };
      s.offsets[k][f] = Math.max(f === 'start' ? 0 : 1, parseInt(el.value, 10) || 0);
      M.applySchedule(p);
      APP.focusSel = '[data-act="schedoffset"][data-k="' + k + '"][data-f="' + f + '"]';
      APP.render();
      return;
    }
    if(el.dataset.act === 'results'){ p.resultsAt = el.value; APP.render(); return; }

    const bind = el.dataset.bind;
    if(!bind) return;
    if(bind === 'branding.file'){ APP.readCover(p, el.files && el.files[0]); return; }
    const v = el.value;

    if(bind === 'name'){ p.name = v; APP.repaintSoft(); return; }
    if(bind === 'tagline'){ p.tagline = v; APP.repaintSoft(); return; }
    if(bind === 'slug'){ p.slug = v.trim().toLowerCase().replace(/[^a-z0-9-]+/g,'-'); return; }
    if(bind === 'city'){ p.format.city = v; APP.repaintSoft(); return; }
    /* the venue fields feed a preview of what a participant reads, so each one
       repaints that preview as you type — without re-rendering the field you
       are still inside */
    if(bind === 'venue'){ p.format.venue = v; APP.repaintVenue(); return; }
    if(bind === 'venue.name'){ p.format.venueName = v; APP.repaintVenue(); return; }
    if(bind === 'venue.country'){ p.format.country = v; APP.repaintVenue(); return; }
    if(bind === 'venue.directions'){ p.format.directions = v; APP.repaintVenue(); return; }
    if(bind === 'fee.currency'){
      const e = M.entry(p); p.format.entry = e; e.currency = v; APP.render(); return;
    }
    if(bind === 'fee.amount'){
      const e = M.entry(p); p.format.entry = e;
      e.fee = parseInt(String(v).replace(/[^0-9]/g, ''), 10) || 0;
      APP.touch(p); return;
    }
    if(bind === 'about.title'){ p.about.title = v; return; }
    if(bind === 'about.text'){ p.about.body = v.split('\n').filter(x => x.trim()); return; }
    if(bind === 'about.html'){ p.about.html = v; APP.save(); return; }

    let m = bind.match(/^fld\.([a-z]+)\.(\d+)\.(name|opts|type|rule)$/);
    if(m){
      const f = ((p.config[m[1]] || {}).fields || [])[+m[2]];
      if(f){
        f[m[3]] = v;
        /* a dropdown change is a committed choice — repaint. Typing is not. */
        if(m[3] === 'type' || m[3] === 'rule') APP.render();
      }
      return;
    }

    m = bind.match(/^slot\.(\d+)\.([0-3])$/);
    if(m){
      const s = ((p.config.mentor || {}).slots || [])[+m[1]];
      if(s) s[+m[2]] = (+m[2] >= 2)
        ? (parseInt(String(v).replace(/[^0-9]/g, ''), 10) || 0) : v;
      return;
    }

    m = bind.match(/^qcat\.(\d+)\.(name|questions)$/);
    if(m){
      const cat = ((p.config.quiz || {}).categories || [])[+m[1]];
      if(cat) cat[m[2]] = m[2] === 'questions'
        ? (parseInt(String(v).replace(/[^0-9]/g, ''), 10) || 0) : v;
      return;
    }

    m = bind.match(/^focus\.(\d+)\.(title|body)$/);
    if(m){ p.focus[+m[1]][m[2]] = v; return; }

    m = bind.match(/^partner\.(\d+)\.(name|tier)$/);
    if(m){ p.partners[+m[1]][m[2]] = v; return; }

    m = bind.match(/^prize\.(\d+)\.level\.(from|to)$/);
    if(m){
      const z = p.prizes[+m[1]];
      if(z){
        const n = Math.max(1, parseInt(v, 10) || 1);
        z.level[m[2]] = n;
        if(m[2] === 'from' && z.level.to < n) z.level.to = n;
        if(m[2] === 'to' && z.level.from > n) z.level.from = n;
      }
      APP.focusSel = '[data-bind="prize.' + m[1] + '.level.' + m[2] + '"]';
      APP.render();
      return;
    }
    m = bind.match(/^prize\.(\d+)\.cash$/);
    if(m){
      const z = p.prizes[+m[1]];
      if(z){
        z.cash = parseInt(String(v).replace(/[^0-9]/g, ''), 10) || 0;
        if(z.items[0]) z.items[0][2] = z.cash ? M.money(z.cash) : '';
      }
      APP.focusSel = '[data-bind="prize.' + m[1] + '.cash"]';
      APP.render();
      return;
    }
    m = bind.match(/^prize\.(\d+)\.paidTo$/);
    if(m){ const z = p.prizes[+m[1]]; if(z) z.paidTo = v; return; }
    m = bind.match(/^prize\.(\d+)\.items\.0\.0$/);
    if(m){ const z = p.prizes[+m[1]]; if(z && z.items[0]) z.items[0][0] = v; return; }

    m = bind.match(/^cfg\.evaluation\.share\.(\d+)$/);
    if(m){ p.config.evaluation.categories[+m[1]].share = +v || 0; APP.render(); return; }

    m = bind.match(/^cfg\.([a-z]+)\.([a-zA-Z]+)$/);
    if(m){
      const c = p.config[m[1]] = p.config[m[1]] || {};
      const num = ['cap','perPerson','min','max','minutes','attempts','pass'];
      c[m[2]] = num.indexOf(m[2]) > -1 ? (parseInt(String(v).replace(/[^0-9]/g,''), 10) || 0) : v;
      return;
    }
  },
  /* name/tagline change the mob card and the header without a full re-render
     that would steal focus from the field being typed in */
  repaintSoft(){
    const p = APP.here(); if(!p) return;
    document.querySelectorAll('[data-live="name"]').forEach(n => n.textContent = p.name);
  },

  repaintVenue(){
    const p = APP.here(); if(!p) return;
    const box = document.querySelector('.vpv'); if(!box) return;
    const f = p.format;
    const nm = box.querySelector('.vpvn'), ad = box.querySelector('.vpva'),
          dr = box.querySelector('.vpvd');
    if(nm) nm.innerHTML = f.venueName ? esc(f.venueName)
      : '<span class="fnt">Venue name</span>';
    const line = [f.venue, f.city, f.country].filter(Boolean).map(esc).join(', ');
    if(ad) ad.innerHTML = line || '<span class="fnt">Address, city, country</span>';
    if(dr) dr.textContent = f.directions || '';
    if(dr) dr.style.display = f.directions ? '' : 'none';
  }
};

document.addEventListener('DOMContentLoaded', APP.boot);
