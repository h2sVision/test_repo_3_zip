# HMS — sponsor workspace, wired prototype

Open **index.html** in any browser. No build, no server, no dependencies.

## What is real

This is not a click-through. There is one in-memory model and everything on screen is
derived from it:

* **Format** decides whether the Venue step exists in the Design-page rail. Switch to
  virtual and the step is gone — not disabled, gone.
* **Participant journey** decides the flow. Remove Quiz and its timeline row, its public-page
  step and its two messages all leave with it.
* **Schedule** lists exactly the modules in the flow, in flow order. The
  initiative window (`5 Oct 2026 — 21 Feb 2027 · 20 weeks`) is computed from the first open
  and the last close — it is never typed.
* **Conflicts are consequences, not blocks.** Only a gate (Quiz, Evaluation) overlapping
  what follows is flagged; Registration and Team formation running side by side is
  deliberate and never flagged. The fix is offered, never forced.
* **The public page is composed, not written.** Eight of eleven sections are derived.
  Live preview names the rung each unfinished section is waiting on.
* **AI as a round** swaps the human rubric for a read-only H2S one and takes no date.
* **Jury** carries two independent switches — appears on the page, and scores. The public
  section never prints a count.
* **Prizes** each declare their own level (rank, rank range, category, named, open to all).
  The committed total is summed from the cash items.

## Try this

1. `Initiatives → ICC Student Challenge 2027 → Manage`
2. **Schedule** — the amber banner. Click *Move it to 29 Nov* and watch it clear.
3. **Participant journey** — remove Quiz. Then look at Timeline, Communications and the public page.
4. **Initiative page → Format** — switch to Virtual. The Venue step leaves the rail.
5. **Initiative page → Live preview** — then remove modules and watch sections fall back to
   amber bands that name the rung.
6. **Initiatives → Create Initiative** — pick a type and build one from nothing.

## State

Changes persist in `localStorage`, so a refresh does not throw your click-through away.
**Reset the prototype** in the header puts the seeded data back.

## Files

| file | what it holds |
|---|---|
| `data.js` | the catalogue (types, modules, sections) and the seed. Sample data only. |
| `model.js` | every derived value. No stored completion flags anywhere. |
| `views.js` | chrome, portfolio, and the initiative-level pages |
| `manage.js` | the five-rung canvas |
| `public.js` | the participant-facing page, shared by the preview and the full view |
| `app.js` | routing, actions, persistence |
