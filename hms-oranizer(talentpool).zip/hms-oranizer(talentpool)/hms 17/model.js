/* ============================================================
   model.js — everything derived. No stored completion flags.
   If a value can be worked out from something else, it is
   worked out here and never written back.
   ============================================================ */

const M = {

  /* ---------- lookups ---------- */
  initiative(id){ return DB.initiatives.find(p => p.id === id) || null; },
  type(p){ return CATALOGUE.types.find(t => t.id === p.type) || CATALOGUE.types[0]; },
  mod(kind){ return CATALOGUE.modules[kind] || { name:kind, sub:'' }; },
  section(id){ return CATALOGUE.sections.find(s => s.id === id); },
  /* the page's section order, per initiative. Seeded from the catalogue the first
     time it is asked for, then owned by the initiative so it can be dragged. */
  sectionOrder(p){
    if(!p.sectionOrder || p.sectionOrder.length !== CATALOGUE.sections.length)
      p.sectionOrder = CATALOGUE.sections.map(s => s.id);
    return p.sectionOrder;
  },
  sectionsIn(p){ return M.sectionOrder(p).map(id => M.section(id)).filter(Boolean); },
  /* Register is always on and cannot be reordered or switched off, so it is not a
     decision — it does not belong in the list of decisions, or in their count. */
  editableSections(p){ return M.sectionsIn(p).filter(s => s.id !== 'register'); },
  moveSection(p, id, delta){
    const order = M.sectionOrder(p), i = order.indexOf(id), j = i + delta;
    if(i < 0 || j < 0 || j >= order.length) return;
    if(M.section(order[j]) && M.section(order[j]).locked) return;
    order.splice(j, 0, order.splice(i, 1)[0]);
  },

  /* ---------- formatting ---------- */
  n(v){ return (v == null) ? '—' : v.toLocaleString('en-GB'); },
  /* a percentage, or null when there is nothing to divide by. Never NaN on screen. */
  pct(a, b){ return (b && a != null) ? Math.round(a / b * 100) : null; },
  pctText(a, b, suffix){
    const v = M.pct(a, b);
    return v == null ? '' : v + '%' + (suffix ? ' ' + suffix : '');
  },
  money(v){ return '$' + Number(v).toLocaleString('en-GB'); },
  MONTH:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
  DAY:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
  date(s, withYear){
    if(!s) return '';
    const d = new Date(s + 'T00:00:00');
    return d.getDate() + ' ' + M.MONTH[d.getMonth()] + (withYear === false ? '' : ' ' + d.getFullYear());
  },
  dow(s){ if(!s) return ''; return M.DAY[new Date(s + 'T00:00:00').getDay()]; },
  days(a, b){ return Math.round((new Date(b) - new Date(a)) / 86400000); },
  plusDays(iso, n){
    const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  },
  /* Registration's standard window, when nothing has been typed yet — 5 days,
     the same default across every initiative. Anything already dated is left
     exactly as set; this only fills a genuinely empty close date. */
  DEFAULT_SPAN:{ registration:5, total:84 },
  span(a, b){
    const d = M.days(a, b);
    if(d < 14) return d + ' d';
    const w = d / 7;
    return (w % 1 ? w.toFixed(1) : w) + ' wks';
  },

  /* ---------- the flow ---------- */
  defaultFlow(typeId){
    const t = CATALOGUE.types.find(x => x.id === typeId);
    return t ? t.flow.slice() : ['registration'];
  },
  bucket(p){
    return Object.keys(CATALOGUE.modules)
      .filter(k => k !== 'registration' && p.modules.indexOf(k) === -1);
  },
  addModule(p, kind){ if(p.modules.indexOf(kind) === -1) p.modules.push(kind); },
  removeModule(p, kind){
    if(kind === 'registration') return false;
    p.modules = p.modules.filter(k => k !== kind);
    delete p.dates[kind];
    return true;
  },
  moveModule(p, kind, delta){
    const i = p.modules.indexOf(kind), j = i + delta;
    if(i < 1 || j < 1 || j >= p.modules.length) return false;   /* registration stays first */
    p.modules.splice(j, 0, p.modules.splice(i, 1)[0]);
    return true;
  },
  /* a module summary line, built from its own config */
  moduleLine(p, kind){
    const c = (p.config && p.config[kind]) || {};
    switch(kind){
      case 'registration':{
        const extra = (c.fields || []).length;
        return 'Form of 5 required fields' + (extra ? ' + ' + extra + ' you added' : '') +
               (c.cap ? ' · entries capped at ' + M.n(c.cap) : '');
      }
      case 'team': return c.min ? c.min + '–' + c.max + ' members · ' +
        (c.solo ? 'solo entries allowed' : 'no solo entries') : 'Not set up yet';
      case 'quiz':{
        const qs = (c.categories || []).reduce((a, x) => a + x.questions, 0);
        return qs ? qs + ' questions · ' + c.categories.length + ' categories · ' + c.minutes + ' min'
                  : 'Screening round · no questions added yet';
      }
      case 'submission': return (c.fields || []).length
        ? (c.fields.length + ' fields · one submission per entry') : 'Not set up yet';
      case 'evaluation': return (c.categories || []).length
        ? c.categories.length + ' categories · ' + c.perEntry + ' evaluators per entry'
        : 'Categories, parameters and weightage not set';
      case 'feedback': return (c.questions || []).length
        ? c.questions.length + ' questions · goes to everyone who submitted' : 'Not set up yet';
      default: return M.mod(kind).sub;
    }
  },
  moduleReady(p, kind){
    const c = (p.config && p.config[kind]) || {};
    if(kind === 'registration') return !!c.cap;
    if(kind === 'quiz')       return (c.categories || []).length > 0;
    if(kind === 'evaluation') return (c.categories || []).length > 0;
    if(kind === 'team')       return !!c.min;
    if(kind === 'submission') return (c.fields || []).length > 0;
    if(kind === 'feedback')   return (c.questions || []).length > 0;
    return false;
  },

  /* ---------- approval: the one handoff to H2S ---------- */
  approvalState(p){
    const a = p.approval || {};
    if(a.state) return a.state;
    return p.signedOn ? 'approved' : 'none';
  },
  /* what genuinely stops it going out, in the words a sponsor would use */
  approvalBlockers(p){
    const r = '#/p/' + p.id + '/manage/';
    const out = [];
    if(!p.name || !p.slug)
      out.push({ t:'Give the initiative a name and a web address', go:r + 'design/details' });
    if(p.modules.length < 2)
      out.push({ t:'Add at least one step after Registration', go:r + 'process' });
    const undated = p.modules.filter(k => !(p.dates[k] && p.dates[k][0] && p.dates[k][1]));
    if(undated.length)
      out.push({ t: undated.length === 1
        ? M.mod(undated[0]).name + ' has no dates'
        : undated.length + ' parts have no dates yet', go:r + 'timeline' });
    return out;
  },
  /* not blocking, but a sponsor would want to know they are empty */
  approvalGaps(p){
    const g = [];
    if(!(p.about.body || []).length && !p.about.html) g.push('About');
    if(!p.focus.length) g.push('Problem statements');
    if(!p.prizes.length) g.push('Prizes');
    if(!(p.tags || []).length) g.push('Focus area');
    return g;
  },

  /* ---------- branding ---------- */
  brand(p){
    if(!p.branding) p.branding = { cover:null, accent:CATALOGUE.accents[0] };
    if(!p.branding.accent) p.branding.accent = CATALOGUE.accents[0];
    return p.branding;
  },
  /* the CSS background for the cover, wherever a cover is drawn */
  coverCss(p){
    const c = M.brand(p).cover;
    if(!c) return null;
    if(c.kind === 'image') return 'url(' + c.value + ') center/cover no-repeat';
    return c.value;
  },
  coverName(p){
    const c = M.brand(p).cover;
    return c ? (c.name || (c.kind === 'image' ? 'your image' : 'a preset')) : null;
  },

  /* ---------- entry fee ---------- */
  entry(p){
    const e = (p.format && p.format.entry) || { paid:false, fee:0, currency:'USD', per:'entry' };
    return e;
  },
  currency(code){
    return CATALOGUE.currencies.find(c => c[0] === code) || CATALOGUE.currencies[0];
  },
  fee(p){
    const e = M.entry(p);
    if(!e.paid || !e.fee) return null;
    return M.currency(e.currency)[1] + Number(e.fee).toLocaleString('en-GB');
  },
  feeLine(p){
    const f = M.fee(p);
    if(!f) return 'Free to enter';
    return f + ' per ' + (M.entry(p).per === 'member' ? 'team member' : 'entry');
  },

  /* ---------- when this initiative was last edited ---------- */
  ago(t){
    if(!t) return '';
    const ms = (typeof t === 'number') ? t : Date.parse(t);
    if(isNaN(ms)) return '';
    const s = Math.floor((Date.now() - ms) / 1000);
    if(s < 45)    return 'just now';
    if(s < 90)    return 'a minute ago';
    if(s < 3600)  return Math.round(s / 60) + ' min ago';
    if(s < 86400){ const h = Math.round(s / 3600); return h + (h === 1 ? ' hour ago' : ' hours ago'); }
    if(s < 604800){ const d = Math.round(s / 86400); return d + (d === 1 ? ' day ago' : ' days ago'); }
    return 'on ' + M.date(new Date(ms).toISOString().slice(0, 10));
  },
  savedNote(p){
    return p.updatedAt ? 'Saved ' + M.ago(p.updatedAt) : 'No changes yet';
  },

  /* ---------- focus-area tags ---------- */
  allTags(){ return CATALOGUE.tags.reduce((a, g) => a.concat(g.t), []); },
  hasTag(p, t){ return (p.tags || []).indexOf(t) > -1; },
  toggleTag(p, t){
    p.tags = p.tags || [];
    const i = p.tags.indexOf(t);
    if(i > -1) p.tags.splice(i, 1); else p.tags.push(t);
  },
  /* how much of the sponsor's own reach has declared an interest in these tags.
     Sample arithmetic — the real figure comes from the innovator profiles. */
  tagMatch(p){
    const n = (p.tags || []).length;
    if(!n) return 0;
    const share = Math.min(0.82, 0.19 + n * 0.11);
    return Math.round(DB.reach.total * share / 10) * 10;
  },

  /* ---------- the design-page sub-rail: conditional, never disabled ---------- */
  designSteps(p){
    /* what the page is about first, then the detail, then the machinery */
    const s = [
      { id:'details', name:'Initiative details' },
      { id:'about',   name:'About the initiative' },
      { id:'branding',name:'Branding' },
      { id:'problems',name:'Problem statements' },
      { id:'focus',   name:'Focus area' },
      { id:'format',  name:'Format' },
      { id:'prizes',  name:'Prizes' },
      { id:'partners',name:'Partners' }
    ];
    if(p.format.mode === 'hybrid' || p.format.mode === 'inperson')
      s.push({ id:'venue', name:'Venue' });
    s.push({ id:'sections', name:'Page sections' });
    s.push({ id:'preview',  name:'Live preview' });
    return s;
  },
  stepDone(p, id){
    switch(id){
      case 'format':  return !!p.format.mode;
      case 'details': return !!(p.name && p.slug);
      case 'about':   return p.about.mode === 'html' ? !!p.about.html : (p.about.body || []).length > 0;
      case 'branding':return !!M.brand(p).cover;
      case 'problems':return p.focus.length > 0;
      case 'focus':   return (p.tags || []).length > 0;
      case 'prizes':  return p.prizes.length > 0;
      case 'partners':return p.partners.length > 0;
      case 'venue':   return !!p.format.venue;
      default:        return false;
    }
  },

  /* ---------- timeline ---------- */
  timelineRows(p){
    return p.modules.map(k => {
      const d = p.dates[k] || [null, null];
      return { kind:k, name:M.mod(k).name, open:d[0], close:d[1],
               span:(d[0] && d[1]) ? M.span(d[0], d[1]) : '—',
               isPublic:p.publicDates[k] !== false };
    });
  },
  /* The whole initiative is anchored from two dates: when it STARTS (Registration
     always opens that same day — it is never asked separately) and when it ENDS.
     Everything in between — Team formation, Quiz, whatever the flow holds — is an
     offset from the start, never its own picker, so the two anchors are the only
     dates a sponsor ever has to decide; the end date is what every module's own
     timing is checked against (see conflicts()). ensureSchedule builds that model
     the first time a initiative needs it (deriving it from whatever p.dates
     already holds, so nothing already dated visibly moves), and applySchedule is
     the only place p.dates gets written from then on. */
  ensureSchedule(p){
    if(p.schedule) return p.schedule;
    const reg = p.dates.registration || [null, null];
    const offsets = {};
    p.modules.forEach(k => {
      if(k === 'registration') return;
      const d = p.dates[k];
      offsets[k] = (reg[0] && d && d[0] && d[1])
        ? { start:M.days(reg[0], d[0]), dur:Math.max(1, M.days(d[0], d[1])) }
        : { start:7, dur:14 };
    });
    const anchor = reg[0] || null;
    const knownEnds = p.modules.map(k => p.dates[k] && p.dates[k][1]).filter(Boolean);
    let end = knownEnds.length ? knownEnds.reduce((a, b) => (b > a ? b : a))
      : (anchor ? M.plusDays(anchor, M.DEFAULT_SPAN.total) : null);
    if(p.resultsAt && (!end || p.resultsAt > end)) end = p.resultsAt;
    p.schedule = {
      anchor,
      end,
      regDur: (reg[0] && reg[1]) ? M.days(reg[0], reg[1]) : M.DEFAULT_SPAN.registration,
      offsets
    };
    return p.schedule;
  },
  applySchedule(p){
    const s = M.ensureSchedule(p);
    if(!s.anchor){
      p.modules.forEach(k => { p.dates[k] = [null, null]; });
      return;
    }
    /* Registration opens on the start date by default and is never offered its
       own open-date picker — the start date IS its open date. */
    p.dates.registration = [s.anchor, M.plusDays(s.anchor, Math.max(1, s.regDur))];
    p.modules.forEach(k => {
      if(k === 'registration') return;
      const o = s.offsets[k] || (s.offsets[k] = { start:7, dur:14 });
      const open = M.plusDays(s.anchor, o.start);
      p.dates[k] = [open, M.plusDays(open, Math.max(1, o.dur))];
    });
    if(!p.resultsAt && s.end) p.resultsAt = s.end;
  },
  dated(p){ return p.modules.filter(k => p.dates[k] && p.dates[k][0] && p.dates[k][1]); },
  window(p){
    const ds = M.dated(p);
    if(!ds.length) return null;
    let a = null, b = null;
    ds.forEach(k => {
      const [o, c] = p.dates[k];
      if(!a || o < a) a = o;
      if(!b || c > b) b = c;
    });
    if(p.resultsAt && p.resultsAt > b) b = p.resultsAt;
    return { start:a, end:b, weeks:Math.round(M.days(a, b) / 7) };
  },
  /* Conflicts are stated as consequences, never as blocks.
     Only a GATE — a module that decides who carries on — matters here. Registration and
     Team formation running side by side is deliberate, not a mistake, so it is never flagged. */
  GATES:{ quiz:'has decided who is through', evaluation:'has finished scoring' },
  conflicts(p){
    const out = [], idx = {};
    p.modules.forEach((k, i) => idx[k] = i);
    p.modules.forEach(k => {
      if(!M.GATES[k]) return;
      const d = p.dates[k]; if(!d || !d[1]) return;
      p.modules.forEach(j => {
        if(j === k || idx[j] <= idx[k]) return;
        const e = p.dates[j]; if(!e || !e[0]) return;
        if(e[0] < d[1]){
          out.push({
            title: M.mod(j).name + ' opens before ' + M.mod(k).name + ' closes',
            body: M.mod(j).name + ' opens on ' + M.date(e[0]) + ', ' + M.days(e[0], d[1]) +
                  ' days before ' + M.mod(k).name + ' closes. Entries can start it before ' +
                  M.mod(k).name + ' ' + M.GATES[k] + '.',
            fixKind:j, fixTo:d[1]
          });
        }
      });
    });
    /* every module is checked against the end date the sponsor set — a schedule
       that quietly runs past the initiative's own end is worse than one that
       says so and offers to trim itself back to fit. */
    const s = p.schedule;
    if(s && s.anchor && s.end){
      p.modules.forEach(k => {
        const d = p.dates[k]; if(!d || !d[1] || d[1] <= s.end) return;
        out.push({
          title: M.mod(k).name + ' closes after the initiative ends',
          body: M.mod(k).name + ' closes ' + M.date(d[1]) + ', ' + M.days(s.end, d[1]) +
                ' days past the ' + M.date(s.end) + ' end date you set.',
          fixKind:'trim:' + k, fixTo:s.end
        });
      });
      if(p.resultsAt && p.resultsAt < s.end){
        out.push({
          title:'Results are announced before the initiative ends',
          body:'Results are set for ' + M.date(p.resultsAt) + ', before things actually close on ' +
               M.date(s.end) + '.',
          fixKind:'results', fixTo:s.end
        });
      }
    }
    return out.slice(0, 3);
  },

  /* ---------- the ladder ---------- */
  rungState(p, rung){
    switch(rung){
      case 'design':
        return M.designSteps(p).filter(s => ['format','details','problems','venue','prizes'].indexOf(s.id) > -1)
                 .every(s => M.stepDone(p, s.id)) ? 'done' : 'todo';
      case 'process':
        return p.modules.length > 1 ? 'done' : 'todo';
      case 'timeline':
        return p.modules.length && M.dated(p).length === p.modules.length ? 'done' : 'todo';
      case 'approval': {
        if(p.state === 'unscoped') return 'idle';
        const a = M.approvalState(p);
        if(a === 'approved') return 'done';
        if(a === 'sent') return 'on';
        return 'todo';
      }
      case 'live':
        return p.state === 'live' ? 'on' : (p.state === 'closed' ? 'done' : 'idle');
      case 'result':
        return p.state === 'closed' ? 'done' : 'idle';
    }
    return 'idle';
  },

  /* ---------- the public page ---------- */
  sectionOn(p, id){ return p.sectionsOff.indexOf(id) === -1; },
  toggleSection(p, id){
    const s = M.section(id); if(s.locked) return;
    const i = p.sectionsOff.indexOf(id);
    if(i > -1) p.sectionsOff.splice(i, 1); else p.sectionsOff.push(id);
  },
  /* ready | waiting | off — and if waiting, which rung finishes it */
  sectionState(p, id){
    if(!M.sectionOn(p, id)) return { state:'off', sub:'Switched off in Sections' };
    const r = (ok, sub) => ok ? { state:'ready', sub:sub }
                              : { state:'waiting', sub:sub, wait:true };
    switch(id){
      case 'hero':     return r(!!p.name, 'Name, tagline, banner');
      case 'facts':    return M.moduleReady(p, 'registration') && M.moduleReady(p, 'team')
        ? { state:'ready', sub:'Format, team size, cap' }
        : { state:'waiting', sub:'Team size and cap come from the modules',
            what:'Format and who can enter are set. Team size and the entry cap arrive from ' +
                 'Registration and Team formation.', link:'Set the modules up',
            route:'#/p/' + p.id + '/manage/process' };
      case 'about':    return p.about.body.length || p.about.html
        ? { state:'ready', sub:M.aboutWords(p) + ' words' }
        : { state:'waiting', sub:'Nothing written yet',
            what:'Your own words, or your HTML. The one section not derived from anything.',
            link:'Write it', route:'#/p/' + p.id + '/manage/design/about' };
      case 'problems': return p.focus.length
        ? { state:'ready', sub:p.focus.length + ' set' }
        : { state:'waiting', sub:'None set',
            what:'The statements you set on Focus area, one card each.',
            link:'Set them', route:'#/p/' + p.id + '/manage/design/problems' };
      case 'steps':    return p.modules.length > 1
        ? { state:'ready', sub:p.modules.length + ' steps' }
        : { state:'waiting', sub:'No modules yet',
            what:'One step per module in your flow, in the order you put them. Nothing to type — ' +
                 'it appears the moment Participant journey has something in it.',
            link:'Set the journey up', route:'#/p/' + p.id + '/manage/process' };
      case 'timeline': return M.dated(p).length
        ? { state:'ready', sub:M.dated(p).length + ' dates' }
        : { state:'waiting', sub:'No dates yet',
            what:'The public dates, straight from Schedule. Judging and feedback stay ' +
                 'internal by default.',
            link:'Set the dates', route:'#/p/' + p.id + '/manage/timeline' };
      case 'prizes':   return p.prizes.length
        ? { state:'ready', sub:p.prizes.length + ' prizes, ' + M.money(M.prizeTotal(p)) }
        : { state:'waiting', sub:'None set',
            what:'Every prize you have written, ranges included.',
            link:'Add a prize', route:'#/p/' + p.id + '/manage/design/prizes' };
      case 'mentors':  return p.mentors.filter(m => m.shown).length
        ? { state:'ready', sub:p.mentors.filter(m => m.shown).length + ' shown' }
        : { state:'waiting', sub:'Roster empty',
            what:'Nobody is named yet, and this blocks nothing — a initiative can open without a ' +
                 'single mentor.', link:'Add mentors',
            route:'#/p/' + p.id + '/manage/process' };
      case 'jury':     return p.jury.filter(j => j.shown).length
        ? { state:'ready', sub:p.jury.filter(j => j.shown).length + ' shown' }
        : { state:'waiting', sub:'Nobody named',
            what:'Named on Results & prizes. Shown and scoring are two different switches.',
            link:'Name the jury', route:'#/p/' + p.id + '/manage/result' };
      case 'partners': return p.partners.length
        ? { state:'ready', sub:p.partners.length + ' logos' }
        : { state:'waiting', sub:'None added',
            what:'Logo, name and tier. One of the three sections that is yours to write.',
            link:'Add partners', route:'#/p/' + p.id + '/manage/design/partners' };
      case 'faq':      return p.faq.length
        ? { state:'ready', sub:p.faq.length + ' questions' }
        : { state:'waiting', sub:'None written' };
      case 'register': return { state:'ready', sub:'Always on' };
    }
    return { state:'ready', sub:'' };
  },
  aboutWords(p){
    if(p.about.mode === 'html') return (p.about.html.split(/\s+/).filter(Boolean).length);
    return p.about.body.join(' ').split(/\s+/).filter(Boolean).length;
  },
  sectionCounts(p){
    let ready = 0, waiting = 0, off = 0;
    CATALOGUE.sections.filter(s => s.id !== 'register').forEach(s => {
      const st = M.sectionState(p, s.id).state;
      if(st === 'ready') ready++; else if(st === 'waiting') waiting++; else off++;
    });
    return { ready, waiting, off,
             total:CATALOGUE.sections.filter(s => s.id !== 'register').length };
  },
  /* only two sections stop a page going live */
  publishBlockers(p){
    const out = [];
    ['steps', 'timeline'].forEach(id => {
      if(M.sectionState(p, id).state === 'waiting') out.push(M.section(id).name);
    });
    return out;
  },

  /* ---------- result & reward ---------- */
  prizeTotal(p){ return p.prizes.reduce((a, z) => a + (z.cash || 0), 0); },
  prizeLevel(l){
    if(l.kind === 'rank')     return l.from === l.to ? M.ord(l.from) : M.ord(l.from) + ' – ' + M.ord(l.to);
    if(l.kind === 'category') return 'Best in ' + l.category;
    if(l.kind === 'named')    return l.name;
    return 'Everyone who ' + (l.stage === 'submission' ? 'submits' : 'reaches ' + l.stage);
  },
  prizeKind(l){
    return { rank:(l.from === l.to ? 'by rank' : 'rank range'), category:'by category',
             named:'named award', stage:'open to all' }[l.kind];
  },
  ord(n){
    const s = ['th', 'st', 'nd', 'rd'], v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  },
  juryCounts(p){
    return { total:p.jury.length,
             scores:p.jury.filter(j => j.scores).length,
             shown:p.jury.filter(j => j.shown).length,
             pending:p.jury.filter(j => !j.shown && j.scores && j.note &&
                                        j.note.indexOf('announced') === 0).length };
  },
  /* the leaderboard gate, per evaluation category */
  gate(p){
    const cats = ((p.config.evaluation || {}).categories || []).map(c => c.name);
    const seed = { Ideation:100, Technical:84, Business:96 };
    const rows = cats.map(c => ({ name:c, pct:(seed[c] == null ? 0 : seed[c]) }));
    if((p.config.evaluation || {}).ai === 'round') rows.push({ name:'AI round', pct:100 });
    return rows;
  },
  gateOpen(p){ return M.gate(p).every(r => r.pct === 100); },

  /* ---------- live ---------- */
  stageOf(p, kind, today){
    const d = p.dates[kind]; if(!d) return 'next';
    if(today > d[1]) return 'closed';
    if(today >= d[0]) return 'open';
    return 'next';
  },
  today(){ return '2027-01-11'; },       /* the prototype's "now" */
  currentStage(p){
    const t = M.today();
    for(const k of p.modules) if(M.stageOf(p, k, t) === 'open') return k;
    return null;
  },
  needsYou(p){
    if(!p.live) return [];
    const L = p.live, out = [];
    if(L.shortBusiness) out.push({ warn:true,
      text:M.n(L.shortBusiness) + ' entries hold one Business score where the rule says two, so ' +
           'they cannot be ranked', act:'Panel', route:'#/p/' + p.id + '/panel' });
    const behind = p.panel.filter(e => !e.removed && e.allocated && e.scored / e.allocated < .4);
    behind.forEach(e => out.push({ warn:true,
      text:e.name + ' has scored ' + M.n(e.scored) + ' of ' + M.n(e.allocated) + ' with 20 days left',
      act:'Panel', route:'#/p/' + p.id + '/panel' }));
    if(L.flagged) out.push({ warn:true,
      text:L.flagged + ' participants are flagged and nobody has looked at them',
      act:'Participants', route:'#/p/' + p.id + '/participants' });
    if(L.bouncedMails) out.push({ warn:false,
      text:M.n(L.bouncedMails) + ' registration mails bounced — those people never got their entry ' +
           'details', act:'Communications', route:'#/p/' + p.id + '/comms' });
    return out;
  },

  /* ---------- portfolio ---------- */
  counts(){
    const by = s => DB.initiatives.filter(p => p.state === s).length;
    return { total:DB.initiatives.length, live:by('live'), draft:by('draft'),
             unscoped:by('unscoped'), closed:by('closed') };
  },
  /* five named checks, each carrying the number that justifies its verdict */
  health(p){
    const L = p.live, out = [];
    if(!L) return out;
    const pct = M.pct(L.registrations, L.target);
    if(pct != null) out.push({ ok:pct >= 70, title:'Registration pace',
      body:(M.stageOf(p, 'registration', M.today()) === 'closed'
        ? 'Closed ' + M.date(p.dates.registration[1], false) + ' having passed ' : 'At ') +
        pct + '% of the target you scoped.',
      right:M.n(L.registrations) + ' of ' + M.n(L.target) });
    if(p.modules.indexOf('team') > -1)
      out.push({ ok:true, title:'Team formation',
        body:'Entries formed and locked' + (L.entries
          ? ', averaging ' + (L.registrations / L.entries).toFixed(1) + ' people each.' : '.'),
        right:M.n(L.entries) + ' entries' });
    const behind = M.gate(p).filter(g => g.pct < 100);
    if(behind.length)
      out.push({ ok:false, title:behind[0].name + ' scoring is behind',
        body:M.n(Math.round(L.submitted * behind[0].pct / 100)) + ' of ' + M.n(L.submitted) +
          ' scored. At this pace the round misses <b>' +
          M.date(p.dates.evaluation ? p.dates.evaluation[1] : p.resultsAt) +
          ' by four days</b>, which moves the results date.',
        right:behind[0].pct + '% covered', link:'Open the Panel', route:'#/p/' + p.id + '/panel' });
    else
      out.push({ ok:true, title:'Scoring', body:'Every category has scored every entry.',
        right:'Clear' });
    if(L.shortBusiness)
      out.push({ ok:false, title:M.n(L.shortBusiness) + ' entries hold one score',
        body:'The rule says two, so they cannot be ranked until the panel covers them.',
        right:'Business short 2', link:'Fix it on the Panel', route:'#/p/' + p.id + '/panel' });
    if(L.flagged)
      out.push({ ok:false, title:L.flagged + ' participants are flagged',
        body:'Nobody has looked at them yet. A flag left alone becomes a dispute after the result.',
        right:L.flagged + ' waiting', link:'Open Participants',
        route:'#/p/' + p.id + '/participants' });
    out.push({ ok:true, title:'Approvals',
      body:'Signed off by you on ' + M.date(p.signedOn || '', false) +
        ', countersigned by Hack2skill. Nothing pending.', right:'Clear' });
    return out.slice(0, 5);
  },

  /* three states, not two — a live initiative is signed off by definition */
  signOff(p){
    if(p.signedOn) return { pill:'ok', text:'As signed, ' + M.date(p.signedOn, false),
      note:'Change any of these and the ones that alter what participants were promised need ' +
           'your signature again.' };
    if(p.state === 'unscoped') return { pill:'warn', text:'Not scoped yet',
      note:'Your initiatives team is still shaping this. Nothing below is settled.' };
    return { pill:'warn', text:'Draft — nothing agreed yet',
      note:'None of this is binding until you sign it off and H2S countersigns. Nobody has been ' +
           'told any of it.' };
  },

  /* how an entry gets judged — the one thing "what was agreed" should say about scoring */
  judging(p){
    const ev = p.config.evaluation || {}, steps = [];
    if(p.modules.indexOf('quiz') > -1) steps.push('Quiz');
    if(ev.ai === 'round') steps.push('AI round');
    const cats = (ev.categories || []).length;
    if(cats) steps.push(cats + (cats === 1 ? ' panel' : ' panels'));
    if(p.winnerRule === 'jury') steps.push('jury on the top ' + p.shortlist);
    if(p.winnerRule === 'you') steps.push('your decision');
    return steps.length ? steps.join(' &#8594; ') : 'not set';
  },

  /* what a participant would actually take away from the page as it stands */
  previewVerdict(p){
    const ready = id => M.sectionState(p, id).state === 'ready';
    const has = [];
    if(ready('hero'))     has.push('the title');
    if(ready('about'))    has.push('what it is about');
    if(ready('problems')) has.push('the problems to solve');
    if(ready('steps'))    has.push('what to do');
    if(ready('timeline')) has.push('when');
    if(ready('prizes'))   has.push('the prizes');
    if(ready('mentors') || ready('jury')) has.push('who is behind it');
    const missing = [];
    if(!ready('steps'))    missing.push('what to do');
    if(!ready('timeline')) missing.push('when');
    if(!ready('about'))    missing.push('what it is about');
    if(!ready('prizes'))   missing.push('what they win');
    const list = a => a.length > 1 ? a.slice(0, -1).join(', ') + ' and ' + a[a.length - 1] : a[0];
    if(!missing.length)
      return { ok:true, text:'A participant sees ' + list(has) + '. Nothing is missing.' };
    return { ok:false, text:'As it stands a participant would see ' +
      (has.length ? list(has) : 'a title and a register button') + ' — but nothing telling them ' +
      list(missing) + '.' };
  },

  word(n){ return ['no','one','two','three','four','five','six','seven','eight','nine','ten'][n] || n; },
  /* what the whole portfolio needs from you — derived, never a stored list */
  portfolioNeeds(){
    const out = [];
    DB.initiatives.forEach(p => {
      if(p.state === 'draft' && M.publishBlockers(p).length === 0)
        out.push({ text:esc(p.name) + ' · brief awaiting your sign-off',
                   route:'#/p/' + p.id + '/manage/design/preview' });
      if(p.state === 'draft' && M.publishBlockers(p).length)
        out.push({ text:esc(p.name) + ' · ' + M.publishBlockers(p).join(' and ').toLowerCase() +
                     ' still to set', route:'#/p/' + p.id + '/manage/design/preview' });
      if(p.state === 'unscoped')
        out.push({ text:esc(p.name) + ' · with your initiatives team, no date yet',
                   route:'#/p/' + p.id });
      (p.panel || []).forEach(e => {
        if(!e.removed && e.allocated && e.scored / e.allocated < .4)
          out.push({ text:esc(p.name) + ' · ' + e.cat.toLowerCase() + ' scoring is behind',
                     route:'#/p/' + p.id + '/panel' });
      });
    });
    return out.slice(0, 4);
  },

  /* a new initiative is not born empty: the modules its type brings arrive with the
     defaults a sponsor would otherwise retype. All of it is editable or removable. */
  defaultConfig(typeId){
    const flow = M.defaultFlow(typeId);
    const cfg = {};
    if(flow.indexOf('submission') > -1) cfg.submission = { fields:M.subFields() };
    if(flow.indexOf('team') > -1)
      cfg.team = { min:2, max:5, solo:true, join:['invite'], perPerson:1, crossInstitution:false };
    if(flow.indexOf('quiz') > -1)
      cfg.quiz = { purpose:'screening', minutes:20, attempts:1, negative:false, pass:60,
        advance:'every', takenBy:'every',
        categories:[ { name:'Screening round', questions:10 } ] };
    if(flow.indexOf('evaluation') > -1)
      cfg.evaluation = { perEntry:2, reach:'assigned', ai:'assist', categories:[
        { name:'Quality', share:60, params:[
          ['Working prototype','Does it run, and does it do what the summary claims?',10,50],
          ['Documentation','README, setup steps, licence',10,50] ] },
        { name:'Impact', share:40, params:[
          ['Relevance to the problem statement','',10,50],
          ['Potential impact','Reach if it shipped',10,50] ] } ] };
    if(flow.indexOf('feedback') > -1)
      cfg.feedback = { audience:'submitted', anonymous:true, gated:false, questions:[
        ['How would you rate the initiative overall?','1 to 5','Rating','Required'],
        ['What should we do differently?','','Long text','Optional'],
        ['Would you take part again?','Yes · No · Maybe','Single choice','Required'] ] };
    return cfg;
  },
  subFields(){ return CATALOGUE.submissionFields.map(f => Object.assign({}, f)); },

  /* ---------- creation wizard: Type, Who can register, Format, Dates ----------
     Four answers are enough to hand a sponsor a fully dated, fully staffed
     Participant journey rather than a blank canvas — the mapping is a plain
     lookup, not a model, so it stays auditable and easy to extend. */

  /* extra registration fields a declared audience segment implies. Combinable
     audiences union their fields; nothing is asked twice. */
  AUDIENCE_FIELDS:{
    students:[
      { name:'Institution', type:'Short text', rule:'Required' },
      { name:'Year of study', type:'Single choice', rule:'Required',
        opts:'First · Second · Third · Final · Postgraduate' } ],
    professionals:[
      { name:'Company / organisation', type:'Short text', rule:'Required' },
      { name:'Job title', type:'Short text', rule:'Optional' } ],
    freelancers:[
      { name:'Portfolio link', type:'Link', rule:'Required',
        opts:'GitHub, Behance or a personal site' },
      { name:'Primary skill area', type:'Single choice', rule:'Required',
        opts:'Design · Engineering · Data · Product · Other' } ]
  },
  audienceFields(audience){
    const seen = {}, out = [];
    (audience || []).forEach(a => (M.AUDIENCE_FIELDS[a] || []).forEach(f => {
      if(!seen[f.name]){ seen[f.name] = true; out.push(Object.assign({}, f)); }
    }));
    return out;
  },

  /* one proportional slice per non-registration module across the sponsor's
     own start/end span — a real starting Schedule, not an empty one, that
     the existing conflict banners will flag if a slice runs too tight. */
  autoOffsets(modules, anchor, end){
    const others = modules.filter(k => k !== 'registration');
    const span = Math.max(others.length * 4, M.days(anchor, end));
    const n = others.length, offsets = {};
    others.forEach((k, i) => {
      const seg = Math.floor(span / (n + 1));
      offsets[k] = { start:Math.max(3, seg * (i + 1)), dur:Math.max(3, seg) };
    });
    return offsets;
  },

  newInitiativeFromWizard(w){
    const p = M.newInitiative(w.type);
    p.config.registration = p.config.registration || {};
    p.config.registration.audience = (w.audience && w.audience.length) ? w.audience.slice() : ['anyone'];
    p.config.registration.fields = M.audienceFields(p.config.registration.audience);

    p.format.mode = w.mode || '';

    /* Format's entry shape overrides the type's own default flow for Team
       formation — the type says what is USUAL, the sponsor's answer here says
       what THIS initiative actually is. */
    if(w.shape === 'individual'){
      M.removeModule(p, 'team');
    }else if(w.shape === 'team' || w.shape === 'either'){
      if(p.modules.indexOf('team') === -1) p.modules.splice(1, 0, 'team');
      p.config.team = p.config.team || { min:2, max:5, join:['invite'], perPerson:1,
        crossInstitution:false };
      p.config.team.solo = (w.shape === 'either');
    }

    if(w.start && w.end){
      p.schedule = { anchor:w.start, end:w.end, regDur:M.DEFAULT_SPAN.registration,
        offsets:M.autoOffsets(p.modules, w.start, w.end) };
      M.applySchedule(p);
    }
    return p;
  },

  newInitiative(typeId){
    const t = CATALOGUE.types.find(x => x.id === typeId);
    const id = 'p' + Date.now().toString(36);
    const p = {
      id, type:typeId, state:'draft', name:'Untitled ' + t.name, tagline:'',
      slug:'untitled-' + id, visibility:'public',
      format:{ mode:'', city:'', venue:'',
               entry:{ paid:false, fee:0, currency:'USD', per:'entry' } },
      about:{ mode:'text', title:'', body:[], html:'' }, focus:[], tags:[],
      modules:M.defaultFlow(typeId), config:M.defaultConfig(typeId), dates:{}, publicDates:{},
      resultsAt:'',
      tz:'Gulf Standard Time', winnerRule:'top', shortlist:10, tiebreaks:[],
      prizes:[], jury:[], mentors:[], partners:[], faq:[], sectionsOff:['faq'],
      live:null, panel:[], entries:[], messages:[]
    };
    DB.initiatives.unshift(p);
    return p;
  },

  /* ---------------- talent pool ----------------
     Nothing here is hard-deleted: leaving an initiative flips that membership to
     'removed', so the record — and the undo — survive. A person's status and every
     team (and its size) are worked out from memberships, never stored. */
  /* '~n' marks a row cloned for the #/pool/large preview; it resolves to its source person */
  person(id){ id = String(id).split('~')[0]; return (DB.people || []).find(u => u.id === id) || null; },
  seat(u, pid){ return u.in.find(m => m.p === pid) || null; },
  live(u){ return u.in.filter(m => m.state === 'ok'); },
  /* closed and unscoped initiatives take nobody new */
  placeable(){ return DB.initiatives.filter(p => p.state !== 'closed' && p.state !== 'unscoped'); },
  teams(pid){
    const t = {};
    (DB.people || []).forEach(u => { const m = M.seat(u, pid);
      if(m && m.state === 'ok' && m.team) t[m.team] = (t[m.team] || 0) + 1; });
    return Object.keys(t).sort().map(name => ({ name, size:t[name] }));
  },
  teamMax(pid){ const p = M.initiative(pid); return ((p && p.config && p.config.team) || {}).max || null; },
  /* returns an error string, or null once every person is placed */
  place(ids, pid, mode, team){
    const p = M.initiative(pid);
    if(!p) return 'Pick an initiative.';
    team = mode === 'solo' ? '' : String(team || '').trim();
    if(mode !== 'solo' && !team) return mode === 'new' ? 'Give the new team a name.' : 'Pick a team.';
    const taken = M.teams(pid).find(t => t.name.toLowerCase() === team.toLowerCase());
    if(mode === 'new' && taken) return '“' + team + '” already exists in ' + p.name + '. Pick it under Existing team.';
    if(mode === 'team' && taken) team = taken.name;
    const max = M.teamMax(pid);
    if(team && max){
      const stay = (DB.people || []).filter(u => !ids.includes(u.id) &&
        (m => m && m.state === 'ok' && m.team === team)(M.seat(u, pid))).length;
      if(stay + ids.length > max) return team + ' would have ' + (stay + ids.length) +
        ' members — ' + p.name + ' allows ' + max + '.';
    }
    ids.forEach(id => {
      const u = M.person(id), m = M.seat(u, pid);
      if(m){ m.team = team; m.state = 'ok'; }
      else u.in.push({ p:pid, team, state:'ok', at:M.today() });
    });
    return null;
  },
  drop(u, pid){ const m = M.seat(u, pid); if(m) m.state = 'removed'; },
  dropAll(u){ u.in.forEach(m => m.state = 'removed'); },
  /* back into the same team, through place() so a team that filled up meanwhile is caught */
  restore(u, pid){ const m = M.seat(u, pid); return M.place([u.id], pid, m.team ? 'team' : 'solo', m.team); },
  members(pid){ return (DB.people || []).filter(u => (m => m && m.state === 'ok')(M.seat(u, pid))); },
  openSeats(u){ return M.live(u).filter(m => { const p = M.initiative(m.p); return p && p.state !== 'closed'; }); },
  /* every action, with the reason it can't be used right now (null = available) —
     shown disabled with its reason rather than hidden, so nothing seems to vanish */
  poolActs(ids){
    const us = ids.map(M.person), live = us.some(u => M.openSeats(u).length), one = ids.length === 1;
    const out = live ? null : 'Not in any open initiative';
    return { add:M.placeable().length ? null : 'No initiative is taking people', drop:out, dropall:out };
  },
  /* the initiatives an action can apply to, for these people */
  actInis(ids, type){
    if(type === 'add') return M.placeable().map(p => p.id);
    const s = [];
    ids.forEach(id => M.openSeats(M.person(id)).forEach(m => {
      if(!s.includes(m.p)) s.push(m.p); }));
    return s;
  },
  act(ids, a){
    if(!ids.length) return 'Pick at least one person.';
    if(a.type === 'dropall'){ ids.forEach(id => M.dropAll(M.person(id))); return null; }
    if(!M.initiative(a.pid)) return 'Pick an initiative.';
    if(a.type === 'drop'){ ids.forEach(id => M.drop(M.person(id), a.pid)); return null; }
    /* adding someone already in it changes nothing — the impact says so, and so must this */
    const add = ids.filter(id => !(m => m && m.state === 'ok')(M.seat(M.person(id), a.pid)));
    return add.length ? M.place(add, a.pid, 'solo') : null;
  },
  /* plain sentences of what an action will do — shown before it is confirmed */
  impact(ids, a){
    const us = ids.map(M.person), who = us.length > 1 ? us.length + ' people' : us[0].name;
    if(a.type === 'dropall') return us.map(u => { const s = M.openSeats(u);
      return u.name + (s.length ? ' leaves ' + s.map(m => M.initiative(m.p).name).join(', ')
        : ' is already out of every open initiative') + '.'; })
      .concat('Their record stays, so this can be undone.');
    const p = M.initiative(a.pid);
    if(!p) return [];
    const out = [who + (a.type === 'drop' ? ' leave' : ' join') + (us.length > 1 ? '' : 's') + ' ' + p.name + '.'];
    if(a.type === 'add' && us.some(u => (m => m && m.state === 'ok')(M.seat(u, a.pid))))
      out.push('Already in ' + p.name + ' — nothing changes.');
    if(a.type === 'drop') out.push('They stay in their other initiatives, and this can be undone.');
    return out;
  },
  /* every H2S registration field: [key, label, profile group, hidden when private].
     A private profile keeps its basics — name, status, occupation, state, country,
     when they registered and how they found you — and hides contact, personal and
     link fields. Table, profile, search and export all read through M.shown, so a
     hidden field can't leak by being searched for or exported. */
  PFIELDS:[
    ['email','Email','Contact',1], ['mobile','Mobile number','Contact',1], ['whatsapp','WhatsApp','Contact',1],
    ['occupation','Occupation','Personal',0], ['gender','Gender','Personal',1], ['dob','Date of birth','Personal',1],
    ['city','City','Location',1], ['state','State','Location',0], ['country','Country','Location',0],
    ['github','GitHub','Links',1], ['linkedin','LinkedIn','Links',1]
  ],
  UTM:[['source','Source'], ['medium','Medium'], ['campaign','Campaign'], ['term','Term'], ['content','Content']],
  isPrivate(u){ return u.vis === 'private'; },
  /* null = hidden by the participant, '' = they didn't provide it */
  shown(u){
    const priv = M.isPrivate(u), s = { name:u.name, status:u.status, timestamp:u.timestamp, utm:u.utm || {} };
    M.PFIELDS.forEach(f => { s[f[0]] = priv && f[3] ? null : u[f[0]] || ''; });
    return s;
  },
  place3(s){ return [s.city, s.state, s.country].filter(Boolean).join(', '); },
  /* participant-entered links only ever leave as http(s) — never javascript: or data: */
  safeUrl(v){ return /^https?:\/\/[^\s"'<>]+$/i.test(v || '') ? v : ''; },
  age(dob){
    if(!dob) return null;
    const t = M.today().split('-').map(Number), d = dob.split('-').map(Number);
    return t[0] - d[0] - (t[1] < d[1] || (t[1] === d[1] && t[2] < d[2]) ? 1 : 0);
  },
  /* '2026-09-02T16:27' → '2 Sep 2026, 4:27 PM' — the H2S timestamp, read the way the Data Centre shows it */
  stamp(ts){
    if(!ts) return '';
    const [d, t = '00:00'] = ts.split('T'), [h, mi] = t.split(':').map(Number);
    return M.date(d) + ', ' + ((h % 12) || 12) + ':' + String(mi).padStart(2, '0') + (h < 12 ? ' AM' : ' PM');
  },
  /* their record in the sponsor's initiatives, with the entry's result where there is one —
     an entry is named after its team, or after the person when they entered solo */
  history(u){
    return u.in.map(m => {
      const p = M.initiative(m.p), e = p && (p.entries || []).find(x => x.name === (m.team || u.name));
      return { m, p, result:e && m.state === 'ok' ? (e.score != null ? 'Scored ' + e.score
        : e.submitted ? 'Submitted' : '') : '' };
    });
  },
  POOLSORT:{ recent:'Newest registered', oldest:'Oldest registered', name:'Name, A–Z' },
  poolRows(f){
    const q = (f.q || '').trim().toLowerCase();
    const hay = u => { const s = M.shown(u);
      return [s.name, s.email, s.mobile, s.whatsapp, s.city, s.state, s.country, s.occupation]
        .filter(Boolean).join(' ').toLowerCase(); };
    const sort = { name:(a, b) => a.name.localeCompare(b.name),
      oldest:(a, b) => a.timestamp.localeCompare(b.timestamp) }[f.sort] ||
      ((a, b) => b.timestamp.localeCompare(a.timestamp));
    return (f.people || DB.people || []).filter(u =>
      (!q || hay(u).includes(q)) &&
      (!f.ini || u.in.some(m => m.p === f.ini && m.state === 'ok')) &&
      (!f.country || u.country === f.country) &&
      (!f.vis || (f.vis === 'private') === M.isPrivate(u)))
      .sort(sort);
  }
};
