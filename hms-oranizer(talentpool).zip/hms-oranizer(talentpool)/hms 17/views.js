/* ============================================================
   views.js — chrome, the portfolio, and the initiative-level pages
   ============================================================ */

const ICON = {
  home:'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  people:'<path d="M16 20v-1.5a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V20"/><circle cx="9.5" cy="7.5" r="3.2"/><path d="M21 20v-1.5a4 4 0 0 0-3-3.87"/><path d="M16 4.13a4 4 0 0 1 0 7.75"/>',
  card:'<rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="M2.5 10h19"/>',
  chat:'<path d="M21 11.5a8 8 0 0 1-11.6 7.1L3 20.5l1.9-6.3A8 8 0 1 1 21 11.5z"/>',
  burger:'<path d="M4 6h16M4 12h16M4 18h16"/>',
  arrow:'<path d="M9 18l6-6-6-6"/>',
  back:'<path d="M15 18l-6-6 6-6"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  x:'<path d="M6 6l12 12M18 6 6 18"/>',
  eye:'<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7z"/><circle cx="12" cy="12" r="3"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  tick:'<path d="M20 6 9 17l-5-5"/>',
  lock:'<rect x="4" y="10.5" width="16" height="10.5" rx="2"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>',
  edit:'<path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/><path d="M14.5 5.5l3 3"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/>' +
        '<path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z"/>',
  cal:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18"/>' +
      '<path d="M8 3v4M16 3v4"/>',
  up:'<path d="M12 19V5"/><path d="M5 12l7-7 7 7"/>',
  pin:'<path d="M12 21s7-5.4 7-11a7 7 0 1 0-14 0c0 5.6 7 11 7 11z"/><circle cx="12" cy="10" r="2.6"/>',
  down:'<path d="M12 5v14"/><path d="M19 12l-7 7-7-7"/>'
};
function ic(k, s, w){
  return '<svg width="' + (s || 16) + '" height="' + (s || 16) + '" viewBox="0 0 24 24" fill="none" ' +
    'stroke="currentColor" stroke-width="' + (w || 1.9) + '" stroke-linecap="round" ' +
    'stroke-linejoin="round">' + ICON[k] + '</svg>';
}
const GRIPSVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">' +
  '<circle cx="9" cy="5" r="1.7"/><circle cx="15" cy="5" r="1.7"/><circle cx="9" cy="12" r="1.7"/>' +
  '<circle cx="15" cy="12" r="1.7"/><circle cx="9" cy="19" r="1.7"/><circle cx="15" cy="19" r="1.7"/></svg>';

function esc(s){ return String(s == null ? '' : s)
  .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }

const V = {

  /* ---------------- chrome ---------------- */
  chrome(body, nav, narrow){
    return '' +
    '<div class="top">' +
      '<a href="#/overview" style="display:flex;align-items:center;gap:8px;color:inherit">' +
        '<span class="logo">H2S</span><span class="wordmark">Hack2skill</span></a>' +
      '<span class="pill">Sponsor workspace</span>' +
      '<div style="flex-grow:1"></div>' +
      '<div style="display:flex;align-items:center;gap:10px">' +
        '<div style="text-align:right;line-height:1.25">' +
          '<div style="font-size:13px;font-weight:700">' + esc(DB.org.name) + '</div>' +
          '<div style="font-size:12px;color:var(--muted)">' + DB.org.role + '</div></div>' +
        '<span class="avatar">' + DB.org.initials + '</span>' +
      '</div>' +
    '</div>' +
    '<div class="shell' + (narrow ? ' narrow' : '') + '">' +
      V.side(nav, narrow) +
      '<div style="min-width:0">' + body + '</div>' +
    '</div>' +
    '<div id="drawer"></div>';
  },

  side(nav, narrow){
    const empty = DB.initiatives.length === 0;
    const item = (k, icon, label, href, off) =>
      '<a class="snav' + (nav === k ? ' on' : '') + (off ? ' off' : '') + '" ' +
      (off ? '' : 'href="' + href + '" ') + (narrow ? 'title="' + label + '"' : '') + '>' +
      ic(icon, 17) + '<span>' + label + '</span></a>';
    const links =
      item('overview','home','Overview','#/overview') +
      item('initiatives','grid','Initiatives','#/initiatives') +
      item('pool','people','Talent Pool','#/pool', empty) +
      (narrow ? '<span class="railsep"></span>' : '<div class="lbl" style="padding:22px 12px 8px">Account</div>') +
      item('account','card','Account & team','#/overview') +
      item('h2s','chat','Your H2S team','#/overview');
    return '<div class="side">' +
      (narrow
        ? '<button class="burger" data-act="drawer" title="Show labels">' + ic('burger',15) + '</button>' +
          '<span class="railsep"></span>' + links
        : '<div class="lbl" style="padding:0 12px 8px">Manage</div>' + links) +
      '</div>';
  },

  /* ---------------- 1 · sponsor overview ---------------- */
  overview(){
    if(!DB.initiatives.length) return V.chrome(V.overviewEmpty(), 'overview');
    const c = M.counts(), R = DB.reach;
    const liveNames = DB.initiatives.filter(p => p.state === 'live')
      .map(p => p.name.replace(/^ICC /, '')).join(', ');
    const needs = M.portfolioNeeds();
    R.delta = (R.curve && R.curve.length > 1)
      ? R.curve[R.curve.length - 1] - R.curve[R.curve.length - 2] : 0;

    const sec = (label, body, aside) =>
      '<div class="sec"><div style="display:flex;justify-content:space-between;' +
        'align-items:baseline;gap:16px"><div class="lbl">' + label + '</div>' +
        (aside || '') + '</div>' + body + '</div>';

    return V.chrome(
      '<div class="ovbg"><div class="wrap wide" style="padding-top:26px">' +

        /* the sponsor IS the organisation — one entity, one name */
        '<div style="margin-bottom:24px">' +
        '<h1 style="font-size:29px;font-weight:900">' + esc(DB.org.name) + '</h1>' +
        '<p style="margin:8px 0 0;font-size:13.5px;color:var(--muted)">' + esc(DB.org.meta) +
        '</p></div>' +

        '<div class="ovgrid">' +

          /* ---- left: the numbers ---- */
          '<div class="ovmain">' +
            sec('At a glance', V.glanceRow(c, R, liveNames)) +
            sec('Registrations', V.regCard(c, R)) +
            sec('Who is entering', V.audienceCard(R),
              '<a class="link" href="#/overview">Talent Pool &#8594;</a>') +
          '</div>' +

          /* ---- right: the state of things ---- */
          '<div class="ovrail">' +
            V.needsPanel(needs) +
            V.rightNow() +
          '</div>' +

        '</div></div></div>', 'overview');
  },

  /* ---- status rail: what is waiting on the sponsor ---- */
  needsPanel(needs){
    if(!needs.length)
      return '<div class="sp"><div class="sph">' +
        '<span class="dot" style="background:var(--ok)"></span>' +
        '<strong style="font-size:13.5px">Nothing needs you</strong></div>' +
        '<div class="spb"><p style="margin:12px 0 4px;font-size:12.5px;color:var(--muted)">' +
        'Every initiative is moving without a decision from you.</p></div></div>';
    return '<div class="sp attn"><div class="sph">' +
      '<span class="dot" style="background:var(--warn)"></span>' +
      '<strong style="font-size:13.5px">Needs you</strong>' +
      '<span style="flex-grow:1"></span>' +
      '<span class="num" style="font-size:12px;font-weight:600;color:var(--warn);' +
        'background:#fff;border-radius:var(--r-pill);padding:2px 9px">' + needs.length +
      '</span></div><div class="spb">' +
      needs.map(n => {
        const bits = n.text.split(' · ');
        return '<a class="spr" href="' + n.route + '">' +
          '<span style="min-width:0;flex-grow:1">' +
          '<span style="display:block;font-size:13px;font-weight:600;line-height:1.35">' +
            bits[0] + '</span>' +
          (bits[1] ? '<span style="display:block;font-size:12px;color:var(--muted);' +
            'margin-top:3px;line-height:1.4">' + bits.slice(1).join(' · ') + '</span>' : '') +
          '</span><span class="spc">' + ic('arrow',14,2.2) + '</span></a>';
      }).join('') + '</div></div>';
  },

  /* ---- the registrations card ---- */
  regCard(c, R){
    return '<div class="card lift">' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-start;' +
        'gap:20px;flex-wrap:wrap">' +
        '<div>' +
        '<span style="font-family:Archivo,sans-serif;font-size:40px;font-weight:800;' +
          'letter-spacing:-.035em;line-height:1">' + M.n(R.total) + '</span>' +
        (R.delta ? '<span class="num" style="display:inline-flex;align-items:center;gap:5px;' +
          'font-size:11.5px;font-weight:600;color:var(--ok);margin-left:12px;' +
          'background:var(--ok-soft);padding:4px 9px;border-radius:var(--r-pill);' +
          'vertical-align:middle">&#9650; ' + M.n(R.delta) +
          '<span style="font-family:\'IBM Plex Sans\',sans-serif;font-weight:500;opacity:.85">' +
          'since the last count</span></span>' : '') +
        '<div style="font-size:12.5px;color:var(--muted);margin-top:7px">Total across ' +
          M.word(c.total) + ' initiatives &#183; ' + R.from + ' &#8211; ' + R.to + '</div></div>' +
        '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
        '<span style="display:inline-flex;align-items:center;gap:7px;font-size:12.5px;' +
          'font-weight:500;padding:6px 10px;border:1px solid var(--line);border-radius:5px;' +
          'background:#fff">All initiatives' +
          '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#777986" ' +
          'stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round">' +
          '<path d="M6 9l6 6 6-6"/></svg></span>' +
        '<div class="seg"><button class="on">Over time</button>' +
          '<button>By initiative</button></div></div>' +
      '</div>' +
      V.regChart(R) +
      '</div>';
  },
  /* A date the person can both set and read. The native control keeps the
     picker; the line under it says the date in words, so dd/mm/yyyy never has
     to be decoded — and an empty field says so in English rather than showing
     a placeholder at the same weight as a real value. */
  dateField(label, act, value, hint){
    const set = !!value;
    return '<label class="dfield' + (set ? '' : ' empty') + '">' +
      '<span class="dfl">' + label + '</span>' +
      '<span class="dfin">' + ic('cal',15,1.8) +
        '<input type="date" data-act="' + act + '" value="' + (value || '') + '"></span>' +
      '<span class="dfr">' + (set ? M.dow(value) + ' ' + M.date(value) : 'Not set yet') +
        '</span>' +
      (hint ? '<span class="dfh">' + hint + '</span>' : '') + '</label>';
  },

  glance(v, label, extra, colour){
    return '<div><div class="num" style="font-size:30px;font-weight:600;letter-spacing:-.03em;' +
      'line-height:1' + (colour ? ';color:' + colour : '') + '">' + v + '</div>' +
      '<div style="font-size:12.5px;color:var(--muted);margin-top:6px">' + label + '</div>' +
      (extra || '') + '</div>';
  },

  /* three cells in one ruled card — grouped, so the numbers stop floating */
  glanceRow(c, R, liveNames){
    const segs = [[c.unscoped,'var(--warn)','Not scoped'], [c.draft,'#8fb0ea','In draft'],
                  [c.live,'var(--ok)','Live'], [c.closed,'var(--line)','Closed']]
                 .filter(x => x[0]);
    const bar =
      '<div style="display:flex;gap:2px;height:6px;border-radius:999px;overflow:hidden;' +
        'margin-top:14px">' +
      segs.map(x => '<span style="flex-grow:' + x[0] + ';background:' + x[1] + '"></span>')
        .join('') + '</div>' +
      /* the bar is never colour alone — every slice says its own name and count */
      '<div style="display:flex;flex-wrap:wrap;gap:5px 12px;margin-top:11px">' +
      segs.map(x => '<span style="display:inline-flex;align-items:center;gap:5px;' +
        'font-size:11px;color:var(--muted);white-space:nowrap">' +
        '<span style="width:7px;height:7px;border-radius:2px;background:' + x[1] +
        ';flex:none"></span>' + x[2] +
        '<span class="num" style="color:var(--ink);font-weight:600">' + x[0] + '</span></span>')
        .join('') + '</div>' +
      (c.unscoped ? '<div style="font-size:11.5px;color:var(--warn);margin-top:10px">' +
        'Waiting on H2S to scope ' + (c.unscoped > 1 ? 'these' : 'this') + '</div>' : '');
    const cell = (inner, first) =>
      '<div style="padding:18px 22px' +
        (first ? '' : ';border-left:1px solid var(--line-soft)') + '">' + inner + '</div>';
    return '<div class="card lift" style="padding:0;display:grid;' +
        'grid-template-columns:1.5fr 1fr 1fr;align-items:start">' +
        cell(V.glance(c.total, 'Initiatives', bar), true) +
        cell(V.glance(c.live, 'Live now',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:14px;line-height:1.5">' +
            (liveNames || 'nothing open') + '</div>', 'var(--ok)')) +
        cell(V.glance(M.n(R.teams), 'Teams participated',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:14px;line-height:1.5">' +
            'across all ' + M.word(c.total) + ' initiatives</div>')) +
      '</div>';
  },

  /* Registrations — monthly intake as bars, running total as a line.
     The old chart was a single cumulative curve: it can only ever go up and to the
     right, so it hid the one thing a sponsor wants off this card — which months
     actually brought people in. Bars carry that; the line keeps the total. */
  regChart(R){
    const MON = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const parse = s => { const b = String(s).split(' '); return [MON.indexOf(b[0]), +b[1]]; };
    const a = parse(R.from), z = parse(R.to);
    const span = (z[1] - a[1]) * 12 + (z[0] - a[0]) + 1;
    const labels = [];
    for (let k = 0; k < span; k++) labels.push(MON[(a[0] + k) % 12]);

    /* the seed carries cumulative readings; fold their deltas into months */
    const pts = R.curve, n = pts.length;
    const monthly = labels.map(() => 0);
    for (let i = 1; i < n; i++)
      monthly[Math.min(span - 1, Math.floor((i - 1) * span / (n - 1)))] += pts[i] - pts[i - 1];
    const running = []; let acc = pts[0] || 0;
    monthly.forEach(v => { acc += v; running.push(acc); });

    const nice = v => { const L = [1,1.5,2,2.5,3,4,5,6,8,10];
      const e = Math.pow(10, Math.floor(Math.log10(v || 1)));
      for (const l of L) if (v <= l * e) return l * e; return 10 * e; };
    /* pick the step first, then the top — otherwise an axis reads "5.3k" */
    const axis = v => nice((v || 1) / 3) * 3;
    const maxBar = axis(Math.max.apply(null, monthly));
    const maxCum = axis(Math.max.apply(null, running));

    const W = 860, H = 252, L = 54, Rr = 800, T = 18, B = 188;
    const band = (Rr - L) / span, bw = Math.min(48, band * 0.58);
    const cx = i => L + band * (i + 0.5);
    const yb = v => B - (B - T) * (v / maxBar);
    const yc = v => B - (B - T) * (v / maxCum);
    const fmt = v => v >= 1000 ? M.n(Math.round(v / 100) / 10).replace('.0','') + 'k' : M.n(v);
    const ticks = [0, 1/3, 2/3, 1];

    const line = running.map((v, i) => (i ? 'L' : 'M') + cx(i).toFixed(1) + ' ' +
      yc(v).toFixed(1)).join(' ');

    /* one hover group per month: bar highlight, crosshair and its own readout */
    const hover = monthly.map((v, i) => {
      const x = cx(i), flip = i > span - 3, tw = 118, tx = flip ? x - tw - 10 : x + 10;
      return '<g class="hg">' +
        '<line class="hline" x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + T +
          '" y2="' + B + '" stroke="#c9cbd4" stroke-width="1" stroke-dasharray="3 3"/>' +
        '<g class="ht"><rect x="' + tx.toFixed(1) + '" y="' + (T + 4) + '" width="' + tw +
          '" height="56" rx="4" fill="#101223"/>' +
        '<text x="' + (tx + 11) + '" y="' + (T + 23) + '" font-family="IBM Plex Sans, sans-serif" ' +
          'font-size="11.5" font-weight="600" fill="#fff">' + labels[i] + ' ' +
          (a[1] + Math.floor((a[0] + i) / 12)) + '</text>' +
        '<text x="' + (tx + 11) + '" y="' + (T + 39) + '" font-family="IBM Plex Mono, monospace" ' +
          'font-size="10.5" fill="#9ea0ab">+' + M.n(v) + ' new</text>' +
        '<text x="' + (tx + 11) + '" y="' + (T + 53) + '" font-family="IBM Plex Mono, monospace" ' +
          'font-size="10.5" fill="#9ea0ab">' + M.n(running[i]) + ' total</text></g>' +
        '<rect class="hbar" x="' + (x - bw / 2).toFixed(1) + '" y="' + yb(v).toFixed(1) +
          '" width="' + bw.toFixed(1) + '" height="' + Math.max(1, B - yb(v)).toFixed(1) +
          '" rx="2" fill="#c3d4f2"/>' +
        '<rect x="' + (L + band * i).toFixed(1) + '" y="' + T + '" width="' + band.toFixed(1) +
          '" height="' + (B - T) + '" fill="transparent"/></g>';
    }).join('');

    return '' +
      /* legend sits in HTML, above the plot — two marks, two shapes, two axes */
      '<div style="display:flex;align-items:center;gap:18px;flex-wrap:wrap;margin-top:20px">' +
        '<span style="display:inline-flex;align-items:center;gap:7px;font-size:12px;' +
          'color:var(--muted)"><span style="width:11px;height:11px;border-radius:2px;' +
          'background:#c3d4f2"></span>New that month<span class="fnt">left axis</span></span>' +
        '<span style="display:inline-flex;align-items:center;gap:7px;font-size:12px;' +
          'color:var(--muted)"><svg width="16" height="11" viewBox="0 0 16 11">' +
          '<path d="M0 8 L5 4 L11 6 L16 2" fill="none" stroke="#0f3583" stroke-width="2"/></svg>' +
          'Running total<span class="fnt">right axis</span></span>' +
      '</div>' +
      '<svg class="rc" viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;height:auto;' +
        'margin-top:8px;overflow:visible" role="img" aria-label="Registrations by month, ' +
        R.from + ' to ' + R.to + ', running total ' + M.n(R.total) + '">' +
      ticks.map(t => '<line x1="' + L + '" x2="' + Rr + '" y1="' + (B - (B - T) * t).toFixed(1) +
        '" y2="' + (B - (B - T) * t).toFixed(1) + '" stroke="' + (t ? '#f0f1f5' : '#e4e6ec') +
        '" stroke-width="1"/>').join('') +
      /* left axis — the bars */
      ticks.map(t => '<text x="' + (L - 10) + '" y="' + (B - (B - T) * t + 3.5).toFixed(1) +
        '" text-anchor="end" font-family="IBM Plex Mono, monospace" font-size="10" ' +
        'fill="#9ea0ab">' + fmt(maxBar * t) + '</text>').join('') +
      /* right axis — the line */
      ticks.map(t => '<text x="' + (Rr + 10) + '" y="' + (B - (B - T) * t + 3.5).toFixed(1) +
        '" font-family="IBM Plex Mono, monospace" font-size="10" fill="#9ea0ab">' +
        fmt(maxCum * t) + '</text>').join('') +
      hover +
      '<path d="' + line + '" fill="none" stroke="#0f3583" stroke-width="2.25" ' +
        'stroke-linejoin="round" stroke-linecap="round" pointer-events="none"/>' +
      running.map((v, i) => '<circle cx="' + cx(i).toFixed(1) + '" cy="' + yc(v).toFixed(1) +
        '" r="' + (i === span - 1 ? 4 : 2.6) + '" fill="' + (i === span - 1 ? '#0f3583' : '#fff') +
        '" stroke="#0f3583" stroke-width="' + (i === span - 1 ? 2 : 1.6) +
        '" pointer-events="none"/>').join('') +
      labels.map((m, i) => '<text x="' + cx(i).toFixed(1) + '" y="' + (B + 20) +
        '" text-anchor="middle" font-family="IBM Plex Mono, monospace" font-size="10" ' +
        'fill="#9ea0ab">' + m + '</text>').join('') +
      '</svg>' +
      '<p style="margin:14px 0 0;font-size:12px;color:var(--faint)">Bars are new ' +
        'registrations in that month; the line is the running total, carried forward past ' +
        'each initiative&#8217;s own close.</p>';
  },

  /* one card, two panels — three occupation rows next to eight country rows will
     never be the same height, and two separate cards turn that into a visible hole */
  audienceCard(R){
    return '<div class="card lift" style="padding:0;display:grid;' +
      'grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr)">' +
      '<div style="padding:20px 22px">' + V.occCard(R) + '</div>' +
      '<div style="padding:20px 22px;border-left:1px solid var(--line-soft)">' +
        V.ctryCard(R) + '</div></div>';
  },

  occCard(R){
    const rows = [['Students',R.students,'#0f3583'],['Professionals',R.professionals,'#2f6ad0'],
                  ['Freelancers',R.freelancers,'#8fb0ea']];
    return '<div style="display:flex;flex-direction:column;min-height:100%">' +
      '<div class="lbl">Occupation</div>' +
      '<p style="margin:9px 0 0;font-size:12.5px;color:var(--muted)">Across every ' +
        'initiative.</p>' +
      /* three rows against Country's eight — centre the group in the shared height
         rather than leaving a hole under it */
      '<div style="display:flex;flex-direction:column;justify-content:center;flex-grow:1;' +
        'padding:22px 0">' +
        '<div style="display:flex;gap:2px;height:10px;border-radius:999px;overflow:hidden">' +
          rows.map(r => '<span style="flex-grow:' + r[1] + ';background:' + r[2] +
          '"></span>').join('') + '</div>' +
        '<div style="display:flex;flex-direction:column;gap:15px;margin-top:20px">' +
          rows.map(r => '<div style="display:flex;align-items:center;gap:10px">' +
            '<span style="width:9px;height:9px;border-radius:50%;background:' + r[2] +
            ';flex:none"></span><strong style="font-size:13.5px">' + r[0] + '</strong>' +
            '<span style="flex-grow:1"></span>' +
            '<span class="num" style="font-size:13.5px">' + M.n(r[1]) + '</span>' +
            '<span class="num" style="font-size:12px;color:var(--faint);width:34px;' +
            'text-align:right">' + Math.round(r[1] / R.total * 100) + '%</span></div>').join('') +
        '</div>' +
      '</div>' +
      '<p style="margin:0;font-size:12px;color:var(--faint)">Occupation comes off each ' +
        'innovator&#8217;s own profile, so it means the same thing inside one ' +
        'initiative.</p></div>';
  },

  ctryCard(R){
    const top = R.countries, max = top[0][1];
    const row = (name, v, mute) =>
      '<div style="display:grid;grid-template-columns:112px minmax(0,1fr) 54px;gap:12px;' +
        'align-items:center"><span style="font-size:13px' + (mute ? ';color:var(--muted)' : '') +
        '">' + esc(name) + '</span>' +
      '<span style="height:7px;border-radius:999px;background:var(--line-soft);overflow:hidden">' +
        '<span style="display:block;height:100%;width:' + (v / max * 100).toFixed(1) +
        '%;background:' + (mute ? 'var(--faint)' : 'var(--primary)') +
        ';border-radius:999px"></span></span>' +
      '<span class="num" style="font-size:12.5px;text-align:right' +
        (mute ? ';color:var(--muted)' : '') + '">' + M.n(v) + '</span></div>';
    return '<div style="display:flex;flex-direction:column;min-height:100%">' +
      '<div class="lbl">Country</div>' +
      '<p style="margin:9px 0 0;font-size:12.5px;color:var(--muted)">Top ' + top.length +
        ', then the rest.</p>' +
      '<div style="display:flex;flex-direction:column;gap:11px;margin-top:18px">' +
        top.map(x => row(x[0], x[1])).join('') +
        (R.otherCountries ? row(R.otherCountries[0] + ' others', R.otherCountries[1], true) : '') +
      '</div>' +
      '<p style="margin:auto 0 0;padding-top:20px;font-size:12px;color:var(--faint)">Sorted by ' +
        'size, not alphabetically &#8212; the ranking is the information.</p></div>';
  },

  /* three rows, maximum — your words. Lives in the status rail now, so it is
     built narrow: name, state, and the single fact that matters right now. */
  rightNow(){
    const order = { live:0, draft:1, unscoped:2, closed:3 };
    const all = DB.initiatives.slice().sort((a, b) => order[a.state] - order[b.state]);
    const rows = all.slice(0, 3), rest = all.length - rows.length;
    const state = { live:'Live', draft:'In draft', unscoped:'Not scoped yet', closed:'Closed' };
    const dotC = { live:'var(--ok)', draft:'#8fb0ea', unscoped:'var(--warn)',
                   closed:'var(--line)' };
    return '<div class="sp"><div class="sph">' +
      '<strong style="font-size:13.5px">Right now</strong><span style="flex-grow:1"></span>' +
      '<a class="link" href="#/initiatives" style="font-size:12px">All ' + all.length +
      ' &#8594;</a></div><div class="spb">' +
      rows.map(p => {
        const cur = M.currentStage(p), L = p.live;
        let lead, sub = '', colour = 'var(--ok)';
        if(p.state === 'live' && cur){
          lead = M.mod(cur).name + ' closes in ' + M.days(M.today(), p.dates[cur][1]) + 'd';
          const bits = [];
          if(L) bits.push(M.n(L.registrations) + ' in');
          if(L && L.submitted) bits.push(M.n(L.submitted) + ' submitted');
          sub = bits.join(' · ');
        } else if(p.state === 'live'){
          lead = 'Between stages'; sub = L ? M.n(L.registrations) + ' in' : '';
        } else if(p.state === 'draft'){
          lead = 'Awaiting your sign-off'; colour = 'var(--warn)';
        } else if(p.state === 'unscoped'){
          lead = 'With your initiatives team'; colour = 'var(--warn)';
        } else { lead = 'Closed'; colour = 'var(--muted)'; }
        return '<a class="spr" href="#/p/' + p.id + '">' +
          '<span style="min-width:0;flex-grow:1">' +
          '<span style="display:block;font-size:13px;font-weight:600;line-height:1.35">' +
            esc(p.name) + '</span>' +
          '<span style="display:flex;align-items:center;gap:6px;font-size:11.5px;' +
            'color:var(--muted);margin-top:4px"><span class="dot" style="background:' +
            dotC[p.state] + '"></span>' + state[p.state] + '</span>' +
          '<span class="num" style="display:block;font-size:11.5px;font-weight:600;color:' +
            colour + ';margin-top:6px">' + lead + '</span>' +
          (sub ? '<span class="num" style="display:block;font-size:11.5px;' +
            'color:var(--faint);margin-top:2px">' + sub + '</span>' : '') +
          '</span><span class="spc">' + ic('arrow',14,2.2) + '</span></a>';
      }).join('') +
      (rest > 0 ? '<p style="margin:0;padding:11px 0 2px;border-top:1px solid var(--line-soft);' +
        'font-size:11.5px;color:var(--faint)">' + rest + ' more not shown here.</p>' : '') +
      '</div></div>';
  },

  /* ---------------- 1a · day one ---------------- */
  overviewEmpty(){
    return '<div class="wrap" style="padding-top:30px;display:flex;flex-direction:column;gap:26px">' +
      '<div><h1 style="font-size:30px;font-weight:900">' + esc(DB.org.name) + '</h1>' +
      '<p style="margin:9px 0 0;font-size:14px;color:var(--muted)">Sponsor &#183; Dubai, UAE ' +
        '&#183; workspace created today</p></div>' +

      '<div style="border:1px solid var(--primary);background:var(--primary-soft);' +
        'border-radius:var(--r);padding:16px 20px;display:flex;justify-content:space-between;' +
        'align-items:flex-start;gap:20px;flex-wrap:wrap">' +
        '<div style="min-width:0;max-width:86ch">' +
        '<strong style="font-size:14.5px">Workspace ready &#183; enquiry ' + DB.org.enquiry +
          ' raised</strong>' +
        '<p style="margin:7px 0 0;font-size:13.5px">Your initiatives team has it. Expect a call ' +
          'within one working day to scope your first initiative &#8212; you do not have to wait for ' +
          'that to start setting one up.</p></div>' +
        '<span class="pill ok" style="flex:none">Same-day pickup</span></div>' +

      '<div class="card lift" style="padding:30px 34px">' +
        '<h2 style="font-size:23px;font-weight:800">Set up your first initiative</h2>' +
        '<p style="margin:12px 0 0;font-size:14.5px;color:var(--muted);max-width:58ch">Pick what ' +
          'it is for &#8212; an innovation challenge, an internal hackathon, a recruitment drive ' +
          '&#8212; and the rest opens as one canvas you can fill in any order. Nothing reaches the ' +
          'network until you sign it off.</p>' +
        '<div style="display:flex;align-items:center;gap:16px;margin-top:22px;flex-wrap:wrap">' +
        '<a class="btn p" href="#/initiatives/new" style="padding:12px 20px;font-size:14.5px">' +
          ic('plus',14,2.4) + 'Create your first initiative</a>' +
        '<span style="font-size:13.5px;color:var(--muted)">or <a class="link" data-act="toast" ' +
          'data-msg="Rhea will call within one working day">talk it through with ' +
          DB.org.manager.name.split(' ')[0] + ' first</a></span></div></div>' +

      '<div style="border:1px dashed var(--line);border-radius:var(--r);padding:22px 24px;' +
        'background:var(--bg-soft)">' +
        '<div class="lbl">What lands here</div>' +
        '<p style="margin:12px 0 0;font-size:14px;max-width:82ch">Once a initiative opens for ' +
          'registration, this page becomes your reading of the whole portfolio: <b>initiatives ' +
          'running</b>, <b>how many are live</b>, <b>registrations to date</b> and <b>teams ' +
          'participated</b> across every initiative you run &#8212; then the <b>country</b> and ' +
          '<b>occupation</b> breakdown of everyone you have reached.</p>' +
        '<p style="margin:14px 0 0;font-size:12.5px;color:var(--faint)">Nothing is shown here ' +
          'until it is true. You will not find this page filled with zeros while you wait.</p></div>' +

      '<div><div class="lbl">The network you will be drawing on</div>' +
        '<div style="display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:28px;' +
          'margin-top:16px">' +
        [['7M+','Innovators on Hack2skill'],['10,000+','Partner institutes'],
         ['10,000+','Partner startups']].map(x =>
          '<div><div class="num" style="font-size:34px;font-weight:600;letter-spacing:-.035em;' +
          'line-height:1">' + x[0] + '</div>' +
          '<div style="font-size:13px;color:var(--muted);margin-top:7px">' + x[1] +
          '</div></div>').join('') + '</div>' +
        '<p style="margin:16px 0 0;font-size:12px;color:var(--faint)">Platform totals, not your ' +
          'reach. Your own numbers replace this block the day your first initiative opens.</p></div>' +
      '</div>';
  },

  bignum(v, label, extra){
    return '<div><div class="n">' + v + '</div><div class="lbl" style="margin-top:4px">' + label +
      '</div>' + (extra || '') + '</div>';
  },
  stackbar(rows, total){
    return '<div style="display:flex;height:34px;border-radius:var(--r-sm);overflow:hidden">' +
      rows.map(r => '<div style="width:' + (r[1] / total * 100).toFixed(1) + '%;background:' + r[2] +
        '"></div>').join('') + '</div>' +
      '<div style="display:flex;gap:20px;margin-top:12px;flex-wrap:wrap">' +
      rows.map(r => '<div><div style="display:flex;align-items:center;gap:7px">' +
        '<span style="width:9px;height:9px;border-radius:2px;background:' + r[2] + '"></span>' +
        '<span style="font-size:12.5px;color:var(--muted)">' + r[0] + '</span></div>' +
        '<div class="num" style="font-size:16px;font-weight:600;margin-top:3px">' + M.n(r[1]) +
        '</div></div>').join('') + '</div>';
  },
  barrow(name, v, max){
    return '<div style="display:grid;grid-template-columns:160px minmax(0,1fr) 62px;gap:12px;' +
      'align-items:center;padding:5px 0"><span style="font-size:12.5px;color:var(--muted)">' +
      esc(name) + '</span><span class="bar"><i style="width:' + (v / max * 100).toFixed(1) +
      '%"></i></span><span class="num" style="font-size:12.5px;text-align:right">' + M.n(v) +
      '</span></div>';
  },
  progRow(p){
    return '<a class="tr grid" href="#/p/' + p.id + '" style="grid-template-columns:minmax(0,1fr) ' +
      '200px 30px;height:56px;color:inherit">' +
      '<span style="font-size:14px;font-weight:600;letter-spacing:-.01em">' + esc(p.name) + '</span>' +
      '<span style="font-size:12.5px;color:var(--muted)">' + esc(M.type(p).name) + '</span>' +
      '<span style="color:var(--faint);justify-self:end">' + ic('arrow',15,2.2) + '</span></a>';
  },

  /* ---------------- 2 · initiatives ---------------- */
  PGROUPS:[
    ['live','Live','var(--ok)','running on the network now','background:var(--ok)'],
    ['draft','In draft','var(--warn)','yours to finish — nothing is public yet','background:var(--warn)'],
    ['unscoped','Not scoped yet','var(--warn)','with your initiatives team — their move',
     'border:1.5px solid var(--warn)'],
    ['closed','Closed','var(--muted)','the overview is the report','background:var(--line)']
  ],
  initiatives(){
    if(!DB.initiatives.length) return V.chrome(V.initiativesEmpty(), 'initiatives');
    return V.chrome(
      /* a listing, and nothing more. Capped narrow so a row reads as a row —
         at full page width the chevron sat 1,200px from the name it belonged to. */
      '<div class="wrap" style="padding-top:30px;max-width:880px">' +
        '<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:24px;' +
          'flex-wrap:wrap">' +
          '<div><h1 style="font-size:30px;font-weight:900">Initiatives</h1>' +
          '<p style="margin:9px 0 0;font-size:14px;color:var(--muted)">Grouped by where each one ' +
            'has got to. A row opens that initiative&#8217;s overview.</p></div>' +
          '<a class="btn p" href="#/initiatives/new">' + ic('plus',15,2.2) +
            'Create Initiative</a>' +
        '</div>' +
        /* one control row: a search box that stops short of the full width, and the
           four groups as filter chips carrying their own counts, so the page can be
           narrowed without scrolling to find out what is in it */
        '<div class="ibar">' +
          '<span class="isearch">' + ic('search',15,2) +
            '<span style="font-size:13.5px">Search initiatives</span></span>' +
          '<div class="ifilters">' +
            '<span class="fchip on">All' +
              '<span class="fct">' + DB.initiatives.length + '</span></span>' +
            V.PGROUPS.map(g => {
              const n = DB.initiatives.filter(x => x.state === g[0]).length;
              if(!n) return '';
              return '<span class="fchip">' +
                '<span class="fdot" style="' + g[4] + '"></span>' + g[1] +
                '<span class="fct">' + n + '</span></span>';
            }).join('') +
          '</div>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;gap:24px;margin-top:24px">' +
        V.PGROUPS.map(g => {
          const rows = DB.initiatives.filter(p => p.state === g[0]);
          if(!rows.length) return '';
          return '<div>' +
            /* the descriptor sits next to its own label, not at the far right edge */
            '<div class="ihead">' +
              '<span style="width:7px;height:7px;border-radius:50%;flex:none;' + g[4] +
                '"></span>' +
              '<span class="lbl" style="color:' + g[2] + '">' + g[1] + '</span>' +
              '<span class="num" style="font-size:12px;color:var(--muted)">' + rows.length +
                '</span>' +
              '<span style="font-size:12px;color:var(--faint)">&#183; ' + g[3] + '</span>' +
              '<span class="rule"></span></div>' +
            '<div class="box"' + (g[0] === 'closed'
              ? ' style="box-shadow:none;background:var(--bg-soft)"' : '') + '>' +
            rows.map(p => V.irow(p, g[0] === 'closed')).join('') + '</div></div>';
        }).join('') +
        '</div>' +
        '<p style="margin:24px 0 0;font-size:12px;color:var(--faint)">' +
          M.word(DB.initiatives.length).replace(/^./, c => c.toUpperCase()) +
          ' initiatives. Every number lives on the overview a row opens.</p>' +
      '</div>', 'initiatives');
  },

  /* name, what it is, when it runs, and an arrow. That is the whole row. */
  irow(p, dim){
    const w = M.window(p);
    const bits = [M.type(p).name];
    if(p.format.mode) bits.push(p.format.mode === 'virtual' ? 'Online'
      : (p.format.mode === 'hybrid' ? 'Hybrid' : 'In person') +
        (p.format.city ? ', ' + p.format.city : ''));
    bits.push(p.state === 'unscoped' ? 'enquiry raised'
      : (w ? M.date(w.start, false) + ' – ' + M.date(w.end) : 'dates not set'));
    return '<a class="irow' + (dim ? ' mute' : '') + '" href="#/p/' + p.id + '">' +
      '<div style="min-width:0">' +
        '<div class="inm">' + esc(p.name) + '</div>' +
        '<div class="isub">' + bits.map(esc).join(' &#183; ') + '</div></div>' +
      '<span class="ichev">' + ic('arrow',15,2.2) + '</span></a>';
  },

  initiativesEmpty(){
    return '<div class="wrap" style="padding-top:30px">' +
      '<h1 style="font-size:30px;font-weight:900">Initiatives</h1>' +
      '<p style="margin:9px 0 0;font-size:14px;color:var(--muted);max-width:70ch">Everything ' +
        esc(DB.org.short) + ' runs on Hack2skill, grouped by where it has got to.</p>' +
      '<div style="margin-top:26px;border:1.5px dashed var(--line);background:var(--bg-soft);' +
        'border-radius:var(--r);padding:64px 40px;text-align:center">' +
        '<span style="display:inline-grid;place-items:center;width:46px;height:46px;' +
          'border-radius:var(--r);background:var(--primary-soft);color:var(--primary)">' +
          ic('grid',22,1.7) + '</span>' +
        '<h2 style="font-size:23px;font-weight:800;margin-top:20px">No initiatives yet</h2>' +
        '<p style="margin:12px auto 0;max-width:56ch;font-size:14.5px;color:var(--muted)">Your ' +
          'first one starts with what it is for &#8212; an innovation challenge, an internal ' +
          'hackathon, a recruitment drive, a student challenge. Everything after that opens as one ' +
          'canvas you can fill in any order.</p>' +
        '<a class="btn p" href="#/initiatives/new" style="margin-top:24px;padding:11px 20px;' +
          'font-size:14.5px">' + ic('plus',16,2.2) + 'Create Initiative</a>' +
        '<p style="margin:18px 0 0;font-size:12.5px;color:var(--faint)">Nothing reaches the ' +
          'network until you sign it off.</p></div>' +
      '<div style="margin-top:22px;display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
        '<span class="lbl">They will sit in four groups</span>' +
        '<span style="height:1px;flex-grow:1;background:var(--line-soft);min-width:20px"></span>' +
        V.PGROUPS.map(g => '<span style="display:inline-flex;align-items:center;gap:7px;' +
          'font-size:13px;color:var(--muted)"><span style="width:7px;height:7px;' +
          'border-radius:50%;' + g[4] + '"></span>' + g[1] + '</span>').join('') +
      '</div></div>';
  },

  /* ---------------- 4 · create ---------------- */
  create(){
    if(APP.ui.creating) return V.creating();
    APP.ui.wizard = APP.ui.wizard || { step:1, type:null, audience:['anyone'], mode:'', shape:'', start:'', end:'' };
    const w = APP.ui.wizard;
    /* the numbered 1-2-3-4 strip is gone — it shouted louder than the question it
       sat above. Orientation is carried by one quiet line in the breadcrumb. */
    const crumb = '<div class="crumb"><a href="#/initiatives">Initiatives</a><i>&#8250;</i>' +
      '<span style="color:var(--ink);font-weight:500">Create Initiative</span>' +
      '<i>&#8250;</i><span class="num" style="color:var(--faint);font-size:12px">Step ' +
      w.step + ' of 4</span></div>';

    if(w.step === 1) return V.wizType(w, crumb);
    if(w.step === 2) return V.wizAudience(w, crumb);
    if(w.step === 3) return V.wizFormat(w, crumb);
    return V.wizDates(w, crumb);
  },

  /* every question in the wizard is answered with the same card */
  wizHead(title, sub){
    return '<div style="margin-top:20px;max-width:70ch">' +
      '<h1 style="font-size:30px;font-weight:900">' + title + '</h1>' +
      '<p style="margin:10px 0 0;font-size:14.5px;color:var(--muted);line-height:1.55">' +
        sub + '</p></div>';
  },

  optCard(o){
    return '<button class="tcard' + (o.on ? ' on' : '') + (o.multi ? ' sq' : '') + '" ' +
      'data-act="' + o.act + '" ' + (o.attr || 'data-v') + '="' + o.v + '" ' +
      'aria-pressed="' + (o.on ? 'true' : 'false') + '">' +
      (o.cta ? '' : '<span class="tmark">' + ic('tick',11,3.2) + '</span>') +
      '<div style="font-family:Archivo,sans-serif;font-size:16px;font-weight:700;' +
        'letter-spacing:-.02em">' + o.title + '</div>' +
      '<div style="font-size:13px;color:var(--muted);line-height:1.5">' + o.blurb + '</div>' +
      (o.meta ? '<div class="num" style="font-size:11px;color:var(--faint);line-height:1.5">' +
        o.meta + '</div>' : '') +
      (o.cta ? '<div style="font-size:12.5px;font-weight:600;color:var(--primary)">' + o.cta +
        '</div>' : '') +
      (o.note ? '<div style="font-size:11.5px;color:var(--faint);line-height:1.5">' + o.note +
        '</div>' : '') + '</button>';
  },

  wizq(label, hint, cards, two){
    return '<div class="wizq">' +
      '<div class="lbl">' + label + '</div>' +
      (hint ? '<p style="margin:7px 0 0;font-size:12.5px;color:var(--muted)">' + hint +
        '</p>' : '') +
      '<div class="mgrid' + (two ? ' g2' : '') + '" style="margin-top:14px">' + cards +
      '</div></div>';
  },

  wizNav(backable, next, ok){
    return '<div class="wizbar">' +
      (backable ? '<button class="btn" data-act="wizback">&#8592; Back</button>' : '') +
      '<button class="btn p" data-act="' + (next === 'create' ? 'wizcreate' : 'wiznext') + '"' +
      (ok ? '' : ' disabled style="opacity:.45;cursor:not-allowed"') + '>' +
      (next === 'create' ? 'Create initiative' : 'Continue') + ' &#8594;</button></div>';
  },

  wizType(w, crumb){
    return V.chrome(
      '<div class="wrap">' + crumb +
        V.wizHead('What is this initiative for?',
          'Decides which page templates and process modules you get, and auto-configures ' +
          'your participant journey and timeline.') +
        '<div class="mgrid" style="margin-top:26px">' +
          CATALOGUE.types.map(t => V.optCard({
            act:'wiztype', attr:'data-type', v:t.id, title:t.name, blurb:t.blurb,
            meta:t.scale, cta:'Continue &#8594;',
            note:'Flow: ' + t.flow.map(k => M.mod(k).name).join(' &#183; ')
          })).join('') +
        '</div>' +
        '<div style="margin-top:34px;padding-top:22px;border-top:1px solid var(--line-soft)">' +
          '<div style="min-width:300px;max-width:56ch">' +
            '<strong style="font-size:14px">Or have your initiatives team scope it</strong>' +
            '<p style="margin:8px 0 0;font-size:13px;color:var(--muted)">Raise it as an enquiry ' +
              'and it lands in <b>Not scoped yet</b> until ' + DB.org.manager.name.split(' ')[0] +
              ' has taken you through a kickoff call.</p>' +
            '<a class="link" style="display:inline-block;margin-top:10px" data-act="toast" ' +
              'data-msg="Enquiry raised — it will appear under Not scoped yet">Ask H2S to scope ' +
              'one &#8594;</a></div>' +
        '</div>' +
      '</div>', 'initiatives');
  },

  wizAudience(w, crumb){
    const on = k => w.audience.indexOf(k) > -1;
    const aud = [
      ['anyone','Anyone on the network',
       'Open to every innovator on Hack2skill, whatever they do.',
       'Registration asks the standard fields only'],
      ['students','Students',
       'Anyone currently enrolled at a school, college or university.',
       'Registration adds Institution and Year of study'],
      ['professionals','Professionals',
       'People entering from a job, in their own name.',
       'Registration adds Employer and Role'],
      ['freelancers','Freelancers',
       'Independents and contractors with no employer to name.',
       'Registration adds a Portfolio link']];
    return V.chrome(
      '<div class="wrap">' + crumb +
        V.wizHead('Who can register?',
          'Decides Registration&#8217;s eligibility and which fields it asks each entrant for.') +
        V.wizq('Eligibility', 'Pick any combination &#8212; &#8220;Anyone&#8221; stands alone.',
          aud.map(a => V.optCard({ act:'wizaud', v:a[0], title:a[1], blurb:a[2], meta:a[3],
            on:on(a[0]), multi:true })).join(''), true) +
        V.wizNav(true, 'next', w.audience.length > 0) +
      '</div>', 'initiatives');
  },

  wizFormat(w, crumb){
    const t = CATALOGUE.types.find(x => x.id === w.type);
    const hasTeam = t.flow.indexOf('team') > -1;
    const modes = [
      ['virtual','Virtual','Nothing to book, nowhere to be.',
       'No Venue step on the Initiative page'],
      ['hybrid','Hybrid','Runs online, with a finale in one place.',
       'Venue step appears, for the finale only'],
      ['inperson','In person','Everyone travels to one venue.',
       'Venue step is required before you publish']];
    const shapes = [
      ['individual','Individual entries only','One person, one entry, start to finish.',
       'Team formation leaves the flow'],
      ['team','Teams only','Every entry belongs to a team.',
       'Team formation stays in the flow'],
      ['either','Either &#8212; solo or team','The entrant decides when they register.',
       'Team formation stays, but nobody is forced through it']];
    return V.chrome(
      '<div class="wrap">' + crumb +
        V.wizHead('What is the format?',
          'Decides the Initiative page&#8217;s Format step' +
          (hasTeam ? ' and whether Team formation stays in the flow' : '') + '.') +
        V.wizq('Delivery', '', modes.map(m => V.optCard({ act:'wizmode', v:m[0], title:m[1],
          blurb:m[2], meta:m[3], on:w.mode === m[0] })).join('')) +
        (hasTeam ? V.wizq('How people take part', '',
          shapes.map(s => V.optCard({ act:'wizshape', v:s[0], title:s[1], blurb:s[2], meta:s[3],
            on:w.shape === s[0] })).join('')) : '') +
        V.wizNav(true, 'next', !!(w.mode && (!hasTeam || w.shape))) +
      '</div>', 'initiatives');
  },

  wizDates(w, crumb){
    const ok = !!(w.start && w.end);
    const bad = ok && M.days(w.start, w.end) < 1;
    return V.chrome(
      '<div class="wrap">' + crumb +
        V.wizHead('When does it run?',
          'Decides the initiative window &#8212; every module in the flow gets a proportional ' +
          'slot between these two dates, which you can re-time on the Timeline page.') +
        '<div class="wizq"><div class="lbl">The window</div>' +
          '<div class="card lift" style="margin-top:14px;max-width:720px">' +
            '<div class="spanrow">' +
              V.dateField('Initiative starts', 'wizstart', w.start, 'Registration opens this day') +
              '<span class="span-arrow">&#8594;</span>' +
              V.dateField('Initiative ends', 'wizend', w.end, 'Results are due by this day') +
              (ok && !bad ? '<span class="spanlen"><span class="num">' +
                Math.max(1, Math.round(M.days(w.start, w.end) / 7)) + '</span> weeks' +
                '<span>end to end</span></span>' : '') +
            '</div>' +
            (bad
              ? '<p class="wizerr">The end date needs to fall after the start date.</p>'
              : ok
                ? '<p style="margin:18px 0 0;font-size:12.5px;color:var(--muted)">Every module ' +
                  'in the flow gets an even slice of this window. Nothing is fixed &#8212; you ' +
                  'can move any of it on the Timeline page straight after.</p>'
                : '<p style="margin:18px 0 0;font-size:12.5px;color:var(--faint)">Both dates are ' +
                  'needed before the initiative can be created.</p>') +
          '</div></div>' +
        V.wizNav(true, 'create', ok && !bad) +
      '</div>', 'initiatives');
  },

  /* The handoff. Creating an initiative writes a journey, a timeline and a page in
     one go; dropping the person straight onto a full canvas hides that it happened.
     Three seconds, three lines, one bar — then the page they came to build. */
  creating(){
    /* two messages, 1.5s each — what was built, then what is left to do */
    const lines = ['Configuring your participant journey and timeline',
                   'Design the initiative and you are ready to go'];
    return V.chrome(
      '<div class="wrap" style="padding-top:0">' +
        '<div class="creating">' +
          '<span class="crspin">' + ic('grid',26,1.6) + '</span>' +
          '<h1 style="font-size:24px;font-weight:900;margin-top:22px">Setting it up</h1>' +
          '<div class="crlines">' +
            lines.map(l => '<span class="crl">' + l + '</span>').join('') +
          '</div>' +
          '<span class="crbar"><i></i></span>' +
          '<p class="crfoot">One click from here and it is yours to design.</p>' +
        '</div>' +
      '</div>', 'initiatives');
  },

  /* Where it has got to, in the rail. Seven stages across the page made every
     label a narrow column and put the dates on one hairline with nothing to
     follow. Read down a column, each stage is a row with room for its own
     dates, and the spine between the markers carries the order. */
  stagePanel(p){
    const t = M.today();
    const rows = p.modules.map(k => {
      const st = M.stageOf(p, k, t), d = p.dates[k];
      return { name:M.mod(k).name, st:st,
        when: !d ? 'no date yet'
          : st === 'closed' ? 'closed ' + M.date(d[1], false)
          : st === 'open' ? 'open now, to ' + M.date(d[1], false)
          : M.date(d[0], false) + ' – ' + M.date(d[1], false) };
    });
    rows.push({ name:'Results announced', st:'next',
      when: p.resultsAt ? M.date(p.resultsAt, false) : 'no date yet' });
    const done = rows.filter(r => r.st === 'closed').length;

    return '<div class="sp"><div class="sph">' +
      '<strong style="font-size:13.5px">Where it has got to</strong>' +
      '<span style="flex-grow:1"></span>' +
      '<span class="num" style="font-size:11.5px;color:var(--muted)">' + done + '/' +
        rows.length + ' done</span></div>' +
      '<div class="stg">' + rows.map((r, i) =>
        '<div class="stgr' + (r.st === 'open' ? ' on' : r.st === 'closed' ? ' done' : '') +
          (i === rows.length - 1 ? ' last' : '') + '">' +
          '<span class="stgm">' + (r.st === 'closed' ? ic('tick',10,3.4) : '') + '</span>' +
          '<span class="stgb"><span class="stgn">' + esc(r.name) + '</span>' +
          '<span class="stgw">' + r.when + '</span></span></div>').join('') +
      '</div></div>';
  },

  /* Health, rebuilt for the rail. It used to be a 400px amber slab above every
     number on the page, so the first thing you met when opening a running
     initiative was a list of what was wrong with it. Now: what needs you on the
     right, what is running on the left, and the checks that pass collapse to
     one line. */
  healthPanel(p, H){
    const bad = H.filter(h => !h.ok), good = H.filter(h => h.ok);
    const clear = good.length;
    const head = (attn) =>
      '<div class="sph"' + (attn ? '' : ' style="background:var(--ok-soft);' +
        'border-bottom-color:#cfe9db"') + '>' +
      '<span class="dot" style="background:var(--' + (attn ? 'warn' : 'ok') + ')"></span>' +
      '<strong style="font-size:13.5px">' + (attn ? 'Needs your attention' : 'On track') +
      '</strong><span style="flex-grow:1"></span>' +
      '<span class="num" style="font-size:11.5px;font-weight:600;color:var(--' +
        (attn ? 'warn' : 'ok') + ');background:#fff;border-radius:var(--r-pill);' +
        'padding:2px 9px">' + clear + '/' + H.length + '</span></div>';

    const rows = bad.map(h =>
      '<' + (h.route ? 'a class="spr" href="' + h.route + '"' : 'div class="spr"') + '>' +
      '<span style="min-width:0;flex-grow:1">' +
      '<span style="display:flex;align-items:baseline;gap:8px">' +
        '<span style="font-size:13px;font-weight:600;line-height:1.35;color:var(--warn)">' +
          h.title + '</span>' +
        '<span style="flex-grow:1"></span>' +
        '<span class="num" style="font-size:11px;font-weight:600;color:var(--warn);' +
          'white-space:nowrap">' + h.right + '</span></span>' +
      '<span style="display:block;font-size:12px;color:var(--muted);margin-top:5px;' +
        'line-height:1.45">' + h.body + '</span>' +
      (h.link ? '<span class="link" style="display:inline-block;margin-top:7px;font-size:12px">' +
        h.link + ' &#8594;</span>' : '') +
      '</span>' + (h.route ? '<span class="spc">' + ic('arrow',14,2.2) + '</span>' : '') +
      '</' + (h.route ? 'a' : 'div') + '>').join('');

    /* the passing checks are reassurance, not work — one quiet line, not five rows */
    const pass = good.length
      ? '<div style="padding:11px 16px;border-top:1px solid var(--line-soft);' +
          'background:var(--bg-soft)">' +
        '<div style="display:flex;align-items:center;gap:7px;font-size:11.5px;' +
          'color:var(--muted)"><span style="color:var(--ok);display:flex">' +
          ic('tick',13,2.6) + '</span>' + good.length + ' check' +
          (good.length > 1 ? 's' : '') + ' clear</div>' +
        '<div style="font-size:11.5px;color:var(--faint);margin-top:4px;line-height:1.5">' +
          good.map(h => h.title).join(' &#183; ') + '</div></div>'
      : '';

    if(!bad.length)
      return '<div class="sp">' + head(false) +
        '<div class="spb"><p style="margin:12px 0 4px;font-size:12.5px;color:var(--muted)">' +
        'Every check on this initiative is clear. Nothing is waiting on you.</p></div>' +
        pass + '</div>';

    return '<div class="sp attn">' + head(true) +
      '<div class="spb">' + rows + '</div>' + pass + '</div>';
  },

  /* ---------------- 3 · initiative overview ---------------- */
  initiative(p){
    const w = M.window(p), L = p.live, cur = M.currentStage(p);
    const meta = [];
    if(p.format.mode) meta.push(p.format.mode === 'virtual' ? 'Online'
      : (p.format.mode === 'hybrid' ? 'Hybrid' : 'In person') +
        (p.format.city ? ' · ' + p.format.city : ''));
    if(w) meta.push(M.date(w.start, false) + ' – ' + M.date(w.end));
    const st = { live:['ok','Live'], draft:['warn','In draft'],
                 unscoped:['warn','Not scoped yet'], closed:['','Closed'] }[p.state];

    /* The dark header block. The address and the way in belong with the title,
       not in a strip of their own underneath it — a boxed URL chip on one side
       and a button on the other was a toolbar pretending to be part of the page.
       Manage sits at the top right where a primary action belongs; the address
       is a quiet line under the meta, in the same register as the meta. */
    const url = 'hack2skill.com/p/' + p.slug;
    const published = p.state === 'live' || p.state === 'closed' || p.visibility === 'public';
    const head =
      '<div class="ihero"><div class="ihero-in">' +
        '<div class="ihero-body">' +
          '<div style="min-width:0">' +
            '<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px;' +
              'flex-wrap:wrap">' +
            '<span class="pill" style="background:rgba(255,255,255,.14);color:#fff">' +
              M.type(p).name + '</span>' +
            '<span class="pill ' + st[0] + '"' + (st[0] ? ''
              : ' style="background:rgba(255,255,255,.14);color:#fff"') + ' >' +
              (p.state === 'live'
              ? '<span style="display:inline-block;width:6px;height:6px;border-radius:50%;' +
                'background:var(--ok);margin-right:6px"></span>' : '') + st[1] + '</span></div>' +
            '<h1 style="color:#fff;font-size:33px;font-weight:900;max-width:22ch">' +
              esc(p.name) + '</h1>' +
            (p.purpose || p.tagline
              ? '<p style="margin:13px 0 0;max-width:56ch;color:rgba(255,255,255,.66);' +
                'font-size:14px">' + esc(p.purpose || p.tagline) + '</p>' : '') +
            '<div class="ihero-meta">' +
              (meta.length ? '<span>' + meta.map(esc).join(' &#183; ') + '</span>' +
                '<span class="ihero-sep"></span>' : '') +
              (published
                ? '<a class="iurl" href="#/public/' + p.id + '">' + ic('globe',14,1.8) +
                  '<span class="num">' + esc(url) + '</span></a>'
                : '<span class="iurl off">' + ic('globe',14,1.8) +
                  '<span class="num">' + esc(url) + '</span>' +
                  '<span class="iurl-tag">not published yet</span></span>') +
            '</div>' +
          '</div>' +

          /* the way in. Never wider than its label, never pushed off the banner:
             at narrow widths it drops under the title rather than shrinking. */
          '<a class="btn p imanage" href="#/p/' + p.id + '/manage/design">Manage ' +
            ic('arrow',14,2.2) + '</a>' +
        '</div>' +
      '</div></div>';

    if(!L) return V.chrome(head +
      '<div class="wrap" style="padding-top:28px">' +
      '<div style="border:1px dashed var(--line);border-radius:var(--r);padding:36px;' +
        'background:var(--bg-soft);max-width:70ch">' +
      '<strong style="font-size:15px">Nothing has happened yet</strong>' +
      '<p style="margin:8px 0 0;font-size:13.5px;color:var(--muted)">Registrations, teams and ' +
        'submissions appear the moment the initiative is live.</p>' +
      '<a class="btn p" href="#/p/' + p.id + '/manage/design" style="margin-top:16px">Open the ' +
        'canvas</a></div></div>', 'initiatives');

    const H = M.health(p), clear = H.filter(h => h.ok).length;
    const occ = [['Students',L.occupation[0],'#0f3583'],
                 ['Professionals',L.occupation[1],'#2f6ad0'],
                 ['Freelancers',L.occupation[2],'#8fb0ea']];

    return V.chrome(head +
      '<div class="ovbg"><div class="wrap wide" style="padding-top:26px">' +
      '<div class="ovgrid"><div class="ovmain">' +

      /* ---- at a glance ---- */
      '<div class="sec"><div class="lbl">At a glance</div>' +
        '<div class="card lift ovstats" style="padding:0;display:grid;' +
          'grid-template-columns:repeat(4,minmax(0,1fr));align-items:start">' +
        V.glance(M.n(L.registrations),'People registered',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:12px">across every ' +
          'problem statement</div>') +
        V.glance(M.n(L.entries),'Entries',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:12px">teams and solo ' +
          'participants</div>') +
        V.glance(M.n(L.submitted),'Submissions',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:12px">' +
          (M.pct(L.submitted, L.entries) == null ? 'one per entry'
            : M.pct(L.submitted, L.entries) + '% of entries, so far') + '</div>') +
        V.glance(M.n(L.scoredEntries || 0),'Fully scored',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:12px">' +
          (L.submitted ? 'of ' + M.n(L.submitted) + ' submissions, scored in every category'
                       : 'scored in every category') + '</div>') +
        '</div></div>' +

      /* ---- registrations ---- */
      V.progCurve(p) +

      /* ---- the two breakdowns ---- */
      '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:22px;' +
        'align-items:stretch">' +
        V.occCardP(p, occ, L) + V.ctryCardP(p, L) + '</div>' +

      /* ---- people and results ---- */
      '<div class="card lift"><div class="lbl">People and results</div>' +
        '<div style="display:flex;flex-wrap:wrap;gap:14px;margin-top:14px">' +
        '<a href="#/p/' + p.id + '/participants" style="flex-grow:1;min-width:240px;display:flex;' +
          'align-items:center;gap:12px;padding:14px 16px;border:1px solid var(--line);' +
          'border-radius:var(--r);color:inherit">' +
          '<div style="min-width:0;flex-grow:1"><div style="font-size:14px;font-weight:600">' +
            'Registered participants</div>' +
          '<div class="num" style="font-size:12px;color:var(--muted);margin-top:2px">' +
            M.n(L.registrations) + ' people &#183; ' + M.n(L.entries) + ' entries</div></div>' +
          '<span style="color:var(--faint)">' + ic('arrow',15,2.2) + '</span></a>' +
        '<a href="#/p/' + p.id + '/panel" style="flex-grow:1;min-width:240px;display:flex;' +
          'align-items:center;gap:12px;padding:14px 16px;border:1px solid var(--line);' +
          'border-radius:var(--r);color:inherit">' +
          '<div style="min-width:0;flex-grow:1"><div style="font-size:14px;font-weight:600">' +
            'Panel</div>' +
          '<div class="num" style="font-size:12px;color:var(--muted);margin-top:2px">' +
            p.panel.filter(e => !e.removed).length + ' evaluators' +
            (M.pct(L.scored, L.allocations) == null ? ' &#183; nothing allocated yet'
              : ' &#183; ' + M.pct(L.scored, L.allocations) + '% scored') + '</div></div>' +
          '<span style="color:var(--faint)">' + ic('arrow',15,2.2) + '</span></a>' +
        (M.gateOpen(p)
          ? '<a href="#/p/' + p.id + '/manage/result" style="flex-grow:1;min-width:240px;' +
            'display:flex;align-items:center;gap:12px;padding:14px 16px;border:1px solid ' +
            'var(--line);border-radius:var(--r);color:inherit"><div style="flex-grow:1">' +
            '<div style="font-size:14px;font-weight:600">Leaderboard</div>' +
            '<div style="font-size:12px;color:var(--muted);margin-top:2px">Open</div></div>' +
            '<span style="color:var(--faint)">' + ic('arrow',15,2.2) + '</span></a>'
          : '<div style="flex-grow:1;min-width:240px;display:flex;align-items:center;gap:12px;' +
            'padding:14px 16px;border:1px dashed var(--line);border-radius:var(--r);' +
            'background:var(--bg-soft)"><div style="min-width:0;flex-grow:1">' +
            '<div style="font-size:14px;font-weight:600;color:var(--faint)">Leaderboard</div>' +
            '<div style="font-size:12px;color:var(--muted);margin-top:2px">Opens once every ' +
            'category has scored.</div></div></div>') +
        '</div></div>' +

      '</div>' +
      /* ---- right: what is waiting on you ---- */
      '<div class="ovrail">' + V.healthPanel(p, H) + V.stagePanel(p) + '</div>' +
      '</div></div></div>', 'initiatives');
  },

  /* One initiative's registrations, in the same form the Overview uses: bars for
     what came in each week, a line for the running total. The old version was a
     single cumulative curve — it can only rise, so it hid which weeks actually
     brought people in, and a six-week sign-up window is exactly where that matters.
     Weekly rather than monthly because the window is weeks long, not months. */
  progCurve(p){
    const L = p.live, d = p.dates.registration;
    const span = d ? Math.max(1, M.days(d[0], d[1])) : 42;
    const weeks = Math.max(4, Math.min(14, Math.ceil(span / 7)));

    /* the seeded curve shape, resampled onto week boundaries */
    const shape = [0, .28, .45, .57, .66, .74, .82, .89, .96, 1];
    const ease = f => {
      const x = f * (shape.length - 1), i = Math.min(shape.length - 2, Math.floor(x));
      return shape[i] + (shape[i + 1] - shape[i]) * (x - i);
    };
    const running = [], weekly = []; let prev = 0;
    for(let i = 1; i <= weeks; i++){
      const cum = Math.round(L.registrations * ease(i / weeks));
      running.push(cum); weekly.push(cum - prev); prev = cum;
    }

    const nice = v => { const LAD = [1,1.5,2,2.5,3,4,5,6,8,10];
      const e = Math.pow(10, Math.floor(Math.log10(v || 1)));
      for(const l of LAD) if(v <= l * e) return l * e; return 10 * e; };
    /* halves, so both axes label round numbers on the same three gridlines */
    const maxBar = nice((Math.max.apply(null, weekly) || 1) / 2) * 2;
    /* the running-total axis is read off the data itself — there is no target here */
    const maxCum = nice((Math.max.apply(null, running) || 1) / 2) * 2;

    const W = 860, H = 248, Lx = 56, Rx = 796, T = 22, B = 186;
    const band = (Rx - Lx) / weeks, bw = Math.min(46, band * 0.58);
    const cx = i => Lx + band * (i + 0.5);
    const yb = v => B - (B - T) * (v / maxBar);
    const yc = v => B - (B - T) * (v / maxCum);
    const fmt = v => v >= 1000 ? M.n(Math.round(v / 100) / 10).replace('.0','') + 'k' : M.n(v);
    const label = i => d ? M.date(M.plusDays(d[0], Math.round(i * span / weeks)), false) : '';
    const closed = d && M.today() > d[1];

    const line = running.map((v, i) => (i ? 'L' : 'M') + cx(i).toFixed(1) + ' ' +
      yc(v).toFixed(1)).join(' ');

    const hover = weekly.map((v, i) => {
      const x = cx(i), flip = i > weeks - 3, tw = 126, tx = flip ? x - tw - 10 : x + 10;
      return '<g class="hg">' +
        '<line class="hline" x1="' + x.toFixed(1) + '" x2="' + x.toFixed(1) + '" y1="' + T +
          '" y2="' + B + '" stroke="#c9cbd4" stroke-width="1" stroke-dasharray="3 3"/>' +
        '<g class="ht"><rect x="' + tx.toFixed(1) + '" y="' + (T + 4) + '" width="' + tw +
          '" height="56" rx="4" fill="#101223"/>' +
        '<text x="' + (tx + 11) + '" y="' + (T + 23) + '" font-family="IBM Plex Sans, sans-serif" ' +
          'font-size="11.5" font-weight="600" fill="#fff">week of ' + label(i) + '</text>' +
        '<text x="' + (tx + 11) + '" y="' + (T + 39) + '" font-family="IBM Plex Mono, monospace" ' +
          'font-size="10.5" fill="#9ea0ab">+' + M.n(v) + ' new</text>' +
        '<text x="' + (tx + 11) + '" y="' + (T + 53) + '" font-family="IBM Plex Mono, monospace" ' +
          'font-size="10.5" fill="#9ea0ab">' + M.n(running[i]) + ' total</text></g>' +
        '<rect class="hbar" x="' + (x - bw / 2).toFixed(1) + '" y="' + yb(v).toFixed(1) +
          '" width="' + bw.toFixed(1) + '" height="' + Math.max(1, B - yb(v)).toFixed(1) +
          '" rx="2" fill="#c3d4f2"/>' +
        '<rect x="' + (Lx + band * i).toFixed(1) + '" y="' + T + '" width="' + band.toFixed(1) +
          '" height="' + (B - T) + '" fill="transparent"/></g>';
    }).join('');

    return '<div class="card lift">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:16px;' +
        'flex-wrap:wrap"><div class="lbl">Registrations</div>' +
        '</div>' +

      '<div style="display:flex;align-items:center;gap:18px;flex-wrap:wrap;margin-top:18px">' +
        '<span style="display:inline-flex;align-items:center;gap:7px;font-size:12px;' +
          'color:var(--muted)"><span style="width:11px;height:11px;border-radius:2px;' +
          'background:#c3d4f2"></span>New that week</span>' +
        '<span style="display:inline-flex;align-items:center;gap:7px;font-size:12px;' +
          'color:var(--muted)"><svg width="16" height="11" viewBox="0 0 16 11">' +
          '<path d="M0 8 L5 4 L11 6 L16 2" fill="none" stroke="#0f3583" stroke-width="2"/></svg>' +
          'Running total</span>' +
      '</div>' +

      '<svg class="rc" viewBox="0 0 ' + W + ' ' + H + '" style="width:100%;height:auto;' +
        'margin-top:8px;overflow:visible" role="img" aria-label="Registrations by week, ' +
        'running total ' + M.n(L.registrations) + '">' +
      [0, .5].map(t => '<line x1="' + Lx + '" x2="' + Rx + '" y1="' +
        (B - (B - T) * t).toFixed(1) + '" y2="' + (B - (B - T) * t).toFixed(1) + '" stroke="' +
        (t ? '#f0f1f5' : '#e4e6ec') + '" stroke-width="1"/>').join('') +
      [0, .5, 1].map(t => '<text x="' + (Lx - 10) + '" y="' +
        (B - (B - T) * t + 3.5).toFixed(1) + '" text-anchor="end" ' +
        'font-family="IBM Plex Mono, monospace" font-size="10" fill="#9ea0ab">' +
        fmt(maxBar * t) + '</text>').join('') +
      [0, .5, 1].map(t => '<text x="' + (Rx + 10) + '" y="' +
        (B - (B - T) * t + 3.5).toFixed(1) + '" font-family="IBM Plex Mono, monospace" ' +
        'font-size="10" fill="#9ea0ab">' + fmt(maxCum * t) + '</text>').join('') +
      hover +
      '<path d="' + line + '" fill="none" stroke="#0f3583" stroke-width="2.25" ' +
        'stroke-linejoin="round" stroke-linecap="round" pointer-events="none"/>' +
      running.map((v, i) => '<circle cx="' + cx(i).toFixed(1) + '" cy="' + yc(v).toFixed(1) +
        '" r="' + (i === weeks - 1 ? 4 : 2.6) + '" fill="' + (i === weeks - 1 ? '#0f3583' : '#fff') +
        '" stroke="#0f3583" stroke-width="' + (i === weeks - 1 ? 2 : 1.6) +
        '" pointer-events="none"/>').join('') +
      '<text x="' + (cx(weeks - 1) - 9).toFixed(1) + '" y="' +
        (yc(L.registrations) - 11).toFixed(1) + '" text-anchor="end" ' +
        'font-family="IBM Plex Mono, monospace" font-size="11" font-weight="600" ' +
        'fill="#0f3583">' + M.n(L.registrations) + '</text>' +
      weekly.map((v, i) => (weeks > 8 && i % 2) ? '' :
        '<text x="' + cx(i).toFixed(1) + '" y="' + (B + 20) + '" text-anchor="middle" ' +
        'font-family="IBM Plex Mono, monospace" font-size="10" fill="#9ea0ab">' + label(i) +
        '</text>').join('') +
      '</svg>' +
      '<p style="margin:14px 0 0;font-size:12px;color:var(--faint)">Bars are new registrations ' +
        'that week; the line is the running total' +
        (closed ? ', and registration is now closed' : '') + '.</p></div>';
  },

  occCardP(p, rows, L){
    const port = Math.round(DB.reach.students / DB.reach.total * 100);
    const here = M.pct(rows[0][1], L.registrations) || 0;
    return '<div class="card lift" style="display:flex;flex-direction:column">' +
      '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px">' +
        '<div class="lbl">Occupation</div>' +
        '<a class="link" href="#/p/' + p.id + '/participants">Participants &#8594;</a></div>' +
      /* three rows against Country's eight — centre the group in the shared height
         rather than leaving a hole under it */
      '<div style="display:flex;flex-direction:column;justify-content:center;flex-grow:1;' +
        'padding:22px 0">' +
      '<div style="display:flex;gap:2px;height:10px;border-radius:999px;overflow:hidden">' +
        rows.map(r => '<span style="flex-grow:' + r[1] + ';background:' +
        r[2] + '"></span>').join('') + '</div>' +
      '<div style="display:flex;flex-direction:column;gap:15px;margin-top:20px">' +
        rows.map(r => '<div style="display:flex;align-items:center;gap:10px">' +
          '<span style="width:9px;height:9px;border-radius:50%;background:' + r[2] +
          ';flex:none"></span><strong style="font-size:13.5px">' + r[0] + '</strong>' +
          '<span style="flex-grow:1"></span>' +
          '<span class="num" style="font-size:13.5px">' + M.n(r[1]) + '</span>' +
          '<span class="num" style="font-size:12px;color:var(--faint);width:34px;' +
          'text-align:right">' + (M.pct(r[1], L.registrations) || 0) + '%</span></div>').join('') +
      '</div></div>' +
      '<p style="margin:0;font-size:12px;color:var(--faint)">' + here + '% students here, ' +
        'against ' + port + '% across your portfolio.</p></div>';
  },
  ctryCardP(p, L){
    const list = L.countries, max = list[0][1];
    return '<div class="card lift">' +
      '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px">' +
        '<div class="lbl">Country</div>' +
        '<a class="link" href="#/p/' + p.id + '/participants">Participants &#8594;</a></div>' +

      '<div style="display:flex;flex-direction:column;gap:9px;margin-top:18px">' +
        list.map(x => {
          const last = x[0].indexOf('else') > -1 || x[0].indexOf('other') > -1;
          return '<div style="display:grid;grid-template-columns:112px minmax(0,1fr) 54px;gap:12px;' +
            'align-items:center"><span style="font-size:13px' +
            (last ? ';color:var(--muted)' : '') + '">' + esc(x[0]) + '</span>' +
            '<span class="bar"><i style="width:' + (x[1] / max * 100).toFixed(1) + '%' +
            (last ? ';background:var(--faint)' : '') + '"></i></span>' +
            '<span class="num" style="font-size:12.5px;text-align:right' +
            (last ? ';color:var(--muted)' : '') + '">' + M.n(x[1]) + '</span></div>';
        }).join('') + '</div>' +
      '<p style="margin:18px 0 0;font-size:12px;color:var(--faint)">' + list[0][0] + ' at ' +
        (M.pct(list[0][1], L.registrations) || 0) + '% here, against ' +
        Math.round(DB.reach.countries[0][1] / DB.reach.total * 100) + '% across your portfolio.' +
        '</p></div>';
  },
  agreed(p, w){
    const kv = (k, val) => '<div style="display:flex;justify-content:space-between;gap:12px;' +
      'padding:9px 0;border-bottom:1px solid var(--line-soft);font-size:14px">' +
      '<span style="color:var(--muted)">' + k + '</span><strong>' + val + '</strong></div>';
    const ev = p.config.evaluation || {};
    return '<div class="card lift">' +
      '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px">' +
        '<div class="lbl">What was agreed</div>' +
        '<span class="pill ' + M.signOff(p).pill + '">' + M.signOff(p).text + '</span></div>' +
      '<div style="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 40px;' +
        'margin-top:14px"><div>' +
        kv('Runs', w ? M.date(w.start, false) + ' – ' + M.date(w.end) : 'dates not set') +
        kv('Problem statements', p.focus.length ? p.focus.length + ' set' : 'none') +
        kv('Focus area', (p.tags || []).length ? p.tags.slice(0,2).join(', ') +
          (p.tags.length > 2 ? ' +' + (p.tags.length - 2) : '') : 'no tags') +
        kv('Cost to enter', M.feeLine(p)) +
        kv('Team size', (p.config.team || {}).min
          ? p.config.team.min + '–' + p.config.team.max +
            ((p.config.team.solo !== false) ? ', or solo' : '') : '—') +
        '</div><div>' +
        kv('Judging', M.judging(p)) +
        kv('Scoring', (ev.categories || []).map(c => c.name + ' ' + c.share + '%').join(' · ')
          || 'not set') +
        kv('Prizes', p.prizes.length
          ? M.money(M.prizeTotal(p)) + ' across ' + p.prizes.length + ' prizes'
          : 'none set') +
        '</div></div>' +
      '<p style="margin:16px 0 0;font-size:12px;color:var(--faint)">' + M.signOff(p).note +
      '</p></div>';
  },

  pills(p){
    const f = p.format.mode === 'virtual' ? 'Virtual'
      : p.format.mode ? ((p.format.mode === 'hybrid' ? 'Hybrid' : 'In person') +
         (p.format.city ? ' · ' + p.format.city : '')) : 'Format not set';
    const st = { live:['ok','Live'], draft:['warn','In draft'],
                 unscoped:['warn','Not scoped yet'], closed:['','Closed'] }[p.state];
    return '<div style="display:flex;align-items:center;gap:9px;margin-top:9px;flex-wrap:wrap">' +
      '<span class="pill">' + M.type(p).name + '</span>' +
      '<span class="pill">' + esc(f) + '</span>' +
      '<span class="pill ' + st[0] + '">' + st[1] + '</span></div>';
  },

  /* ---------------- 3a · participants ---------------- */
  participants(p){
    const L = p.live || {};
    const rows = p.entries;
    const chip = (t, n, on) => '<span class="chip' + (on ? ' on' : '') + '">' + t +
      (n == null ? '' : ' ' + M.n(n)) + '</span>';
    return V.chrome('<div class="wrap">' +
      '<div class="crumb"><a href="#/initiatives">Initiatives</a><i>&#8250;</i>' +
        '<a href="#/p/' + p.id + '">' + esc(p.name) + '</a><i>&#8250;</i>' +
        '<span style="color:var(--ink);font-weight:500">Participants</span></div>' +
      '<h1 style="font-size:26px;font-weight:900;margin-top:14px">Participants</h1>' +
      '<p style="margin:9px 0 0;font-size:13.5px;color:var(--muted);max-width:80ch">This ' +
        'initiative&#8217;s roster, and the only place you can act on it.</p>' +
      '<div class="tbl" style="margin-top:20px">' +
        '<div style="display:flex;align-items:center;gap:12px;padding:12px 16px;flex-wrap:wrap">' +
          '<span style="display:inline-flex;align-items:center;gap:9px;flex-grow:1;min-width:220px;' +
            'font-size:13.5px;color:var(--faint)">' + ic('search',15,2) + 'Search a name or an entry</span>' +
          '<span class="chip">People</span><span class="chip on">Teams</span>' +
        '</div>' +
        '<div style="display:flex;gap:8px;padding:0 16px 12px;flex-wrap:wrap">' +
          chip('All', L.entries, true) + chip('Submitted', L.submitted) +
          chip('Flagged', L.flagged) + chip('Removed', L.removed) +
          chip('Disqualified', L.disqualified) +
        '</div>' +
      '</div>' +
      '<div class="tbl" style="margin-top:16px">' +
        '<div class="tr grid th" style="grid-template-columns:minmax(0,1fr) 120px 116px 150px 130px;height:36px">' +
          '<span>Entry</span><span>Members</span><span>Country</span><span>State</span><span></span></div>' +
        rows.map((e, i) => V.entryRow(p, e, i)).join('') +
        V.pager('1–' + rows.length, M.n(L.entries || rows.length)) +
      '</div>' +
      '<p class="qn">Nothing is hard-deleted. <b>Removed</b> comes out of the counts; ' +
        '<b>disqualified</b> stays on the record, out of the ranking. Both reversible.</p>' +
    '</div>', 'initiatives');
  },
  entryRow(p, e, i){
    const state = { ok:['', 'In'], flagged:['warn','Flagged'],
                    removed:['','Removed'], disqualified:['warn','Disqualified'] }[e.state];
    const act = e.state === 'removed' ? 'Restore to initiative'
      : e.state === 'disqualified' ? 'Reinstate entry'
      : e.state === 'flagged' ? 'Review' : 'Remove';
    const dim = (e.state === 'removed') ? ';color:var(--muted)' : '';
    return '<div class="tr grid" style="grid-template-columns:minmax(0,1fr) 120px 116px 150px 130px;' +
      'height:60px' + (e.state === 'removed' || e.state === 'disqualified' ? ';background:var(--bg-soft)' : '') + '">' +
      '<span><span style="font-size:14px;font-weight:600' + dim + '">' + esc(e.name) + '</span>' +
      (e.reason ? '<div style="font-size:11.5px;color:var(--muted);margin-top:2px">' + esc(e.reason) +
        '</div>' : (e.mentored ? '<div style="font-size:11.5px;color:var(--warn);margin-top:2px">' +
        'mentored by a panel member</div>' : '')) + '</span>' +
      '<span class="num" style="font-size:13px;color:var(--muted)">' + e.members +
        (e.members === 1 ? ' · solo' : '') + '</span>' +
      '<span style="font-size:12.5px;color:var(--muted)">' + esc(e.country) + '</span>' +
      '<span class="' + (state[0] ? 'pill ' + state[0] : '') + '" style="font-size:12.5px;' +
        (state[0] ? '' : 'color:var(--muted)') + '">' + state[1] + '</span>' +
      '<button class="link" data-act="entry" data-p="' + p.id + '" data-i="' + i + '" ' +
        'style="justify-self:end">' + act + ' &#8594;</button></div>';
  },
  pager(shown, total){
    return '<div class="pager"><span class="num" style="font-size:12.5px;color:var(--muted)">' +
      shown + ' of ' + total + '</span><div style="display:flex;gap:6px;align-items:center">' +
      '<span class="pg" style="color:var(--faint)">' + ic('back',13,2.2) + '</span>' +
      '<span class="pg on">1</span><span class="pg">2</span><span class="pg">3</span>' +
      '<span class="pg">' + ic('arrow',13,2.2) + '</span></div></div>';
  },

  /* ---------------- talent pool ----------------
     Every person who registered for any of your initiatives, shown with exactly the
     fields an H2S registration carries. Find → scan → open the profile → act. The table
     has fixed column widths, so long names, emails or places truncate in their own cell
     instead of pushing the columns around. A private profile renders only what M.shown
     lets through. */
  POOLACT:{
    add:    ['Add to an initiative', 'Registers them in another of your initiatives.', 'Add'],
    drop:   ['Remove from one initiative', 'Partial. Leaves one initiative, stays in the others.', 'Remove from initiative'],
    dropall:['Remove completely', 'Leaves every initiative at once. The record stays.', 'Remove completely']
  },
  pav(u, big){
    return '<span class="pav' + (big ? ' big' : '') + '" aria-hidden="true">' +
      esc(u.name.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase()) + '</span>';
  },
  popt(v, label, cur, dis){
    return '<option value="' + esc(v) + '"' + (v === cur ? ' selected' : '') + (dis ? ' disabled' : '') + '>' +
      esc(label) + '</option>';
  },
  pstatus(s){
    return s === 'VERIFIED' ? '<span class="pbadge ok">' + ic('tick',11,3) + 'Verified</span>'
      : '<span class="pbadge warn">Not verified</span>';
  },
  pvis(u){
    return M.isPrivate(u) ? '<span class="pvis priv">' + ic('lock',12,2.2) + 'Private</span>'
      : '<span class="pvis">' + ic('globe',12,2) + 'Public</span>';
  },

  /* state = a preview route (#/pool/loading | empty | error | large) so every state can be reviewed */
  pool(state){
    const f = APP.poolUI();
    /* ponytail: the large preview clones the seed 100× in memory (never saved) — it
       exists to show the table and pager at scale, not to model real volume */
    f.people = state === 'large' ? (V._many = V._many || Array.from({ length:100 }, (_, i) =>
      (DB.people || []).map(u => Object.assign({}, u, { id:u.id + '~' + i, name:u.name + (i ? ' ' + (i + 1) : '') })))
      .flat()) : null;
    const all = f.people || DB.people || [];
    const empty = state === 'empty' || !all.length;
    const body = state === 'loading' ? V.poolSkeleton() : state === 'error' ? V.poolError()
      : empty ? V.poolEmpty() : V.poolPeople(f);
    const live = (!state || state === 'large') && !empty;
    return V.chrome('<div class="wrap wide poolpage">' +
      '<div class="crumb"><a href="#/overview">Overview</a><i>&#8250;</i>' +
        '<span style="color:var(--ink);font-weight:500">Talent Pool</span></div>' +
      '<div class="phead">' +
        '<div style="min-width:0"><h1>Talent Pool</h1>' +
        '<p>' + (live ? '<b>' + M.n(all.length) + '</b> participants across your ' + DB.initiatives.length +
          ' initiatives, one record per person' : 'Everyone who registers for any of your initiatives') + '</p></div>' +
        '<button class="btn" data-act="pool-csv"' + (live ? '' : ' disabled title="Nothing to export yet"') + '>' +
          ic('down',14,2) + 'Export CSV</button>' +
      '</div>' +
      (live ? V.poolBar(f, all) : '') +
      body +
      (live && f.open ? V.poolPanel(f) : '') +
    '</div>', 'pool');
  },

  /* search first, then the few filters that decide who you look at */
  poolBar(f, all){
    const pick = (k, label, opts) => '<label class="pf' + (f[k] ? ' on' : '') + '"><span>' + label + '</span>' +
      '<select data-bind="pool.' + k + '" aria-label="' + label + '">' +
      opts.map(o => V.popt(o[0], o[1], f[k] || '')).join('') + '</select></label>';
    const uniq = fn => Array.from(new Set(all.map(fn).filter(Boolean))).sort();
    const n = ['vis','country'].filter(k => f[k]).length;
    return '<div class="pbar">' +
      '<div class="pbar-1">' +
        ('<label class="psearch">' + ic('search',17,2) +
          '<input type="search" data-bind="pool.q" value="' + esc(f.q) + '" placeholder="Search by name, email, phone or place" aria-label="Search participants" autocomplete="off"><kbd title="Press / to search">/</kbd></label>') +
        '<label class="pscope"><span class="lbl">Initiative</span><select data-bind="pool.ini" ' +
          'aria-label="Initiative">' + V.popt('', 'All initiatives', f.ini) +
          DB.initiatives.map(x => V.popt(x.id, x.name, f.ini)).join('') + '</select></label>' +
      '</div>' +
      ('<div class="pbar-2">' +
        pick('vis', 'Profile', [['','Any'],['public','Public'],['private','Private']]) +
        pick('country', 'Country', [['','Any']].concat(uniq(u => u.country).map(c => [c, c]))) +
        (n ? '<button class="link" data-act="pool-clear">Clear ' + n + ' filter' + (n > 1 ? 's' : '') + '</button>' : '') +
      '</div>') +
    '</div>';
  },

  /* -- participants: one stable table -- */
  poolPeople(f){
    const rows = M.poolRows(f), per = +f.per || 25;
    const pages = Math.max(1, Math.ceil(rows.length / per)), pg = Math.min(f.page || 1, pages);
    const shown = rows.slice((pg - 1) * per, pg * per);
    const nums = Array.from({ length:pages }, (_, i) => i + 1).filter(i => i === 1 || i === pages || Math.abs(i - pg) <= 1);
    /* sortable headers: Name toggles A–Z; Registered flips newest/oldest */
    const sortTh = (label, keys) => { const on = keys.indexOf(f.sort || 'recent');
      const next = keys[on === 0 && keys[1] ? 1 : 0];
      return '<button class="psort' + (on >= 0 ? ' on' : '') + '" data-act="pool-filter" data-k="sort" data-v="' + next + '">' +
        label + (on >= 0 ? (keys[on] === 'oldest' ? ' &#8593;' : ' &#8595;') : '') + '</button>'; };
    return '<div class="plist">' +
        (shown.length ? '<div class="ptwrap"><table class="ptable">' +
          '<colgroup><col class="c-who"><col class="c-loc"><col class="c-occ">' +
            '<col class="c-reg"><col class="c-vis"><col class="c-act"></colgroup>' +
          '<thead><tr><th aria-sort="' + (f.sort === 'name' ? 'ascending' : 'none') + '">' + sortTh('Participant', ['name']) + '</th>' +
            '<th>Location</th><th>Occupation</th>' +
            '<th aria-sort="' + (f.sort === 'name' ? 'none' : f.sort === 'oldest' ? 'ascending' : 'descending') + '">' +
              sortTh('Registered', ['recent','oldest']) + '</th>' +
            '<th>Profile</th><th><span class="sr">Actions</span></th></tr></thead>' +
          '<tbody>' + shown.map(u => V.poolRow(u)).join('') + '</tbody></table></div>'
          : V.poolNone(f)) +
        (rows.length ? '<div class="pager"><span class="psize"><span class="num">' + M.n((pg - 1) * per + 1) + '–' +
            M.n(Math.min(pg * per, rows.length)) + '</span> of <b class="num">' + M.n(rows.length) + '</b>' +
            '<select class="psel" data-bind="pool.per" aria-label="Rows per page">' +
            [25, 50, 100].map(n => V.popt(String(n), n + ' per page', String(per))).join('') + '</select></span>' +
          (pages > 1 ? '<nav class="ppages" aria-label="Pages">' +
            '<button class="pg" data-act="pool-page" data-v="' + (pg - 1) + '"' + (pg === 1 ? ' disabled' : '') +
              ' aria-label="Previous page">' + ic('back',13,2.2) + '</button>' +
            nums.map((i, k) => (k && i - nums[k - 1] > 1 ? '<span class="pgap">…</span>' : '') +
              '<button class="pg' + (i === pg ? ' on' : '') + '" data-act="pool-page" data-v="' + i + '"' +
              (i === pg ? ' aria-current="page"' : '') + '>' + M.n(i) + '</button>').join('') +
            '<button class="pg" data-act="pool-page" data-v="' + (pg + 1) + '"' + (pg === pages ? ' disabled' : '') +
              ' aria-label="Next page">' + ic('arrow',13,2.2) + '</button></nav>' : '') +
          '</div>' : '') +
      '</div>';
  },
  /* each cell holds at most two short lines and truncates inside itself */
  poolRow(u){
    const s = M.shown(u), ts = (s.timestamp || '').split('T');
    const where = [s.city, s.state].filter(Boolean).join(', ');
    const cell = (main, sub, cls) => '<td' + (cls ? ' class="' + cls + '"' : '') + '><span class="pc1" title="' +
      esc(main) + '">' + (main ? esc(main) : '<span class="pnil">—</span>') + '</span>' +
      (sub != null ? '<span class="pc2" title="' + esc(sub) + '">' + esc(sub) + '</span>' : '') + '</td>';
    /* the whole row opens the profile; ⋯ carries its own data-act, so it wins */
    return '<tr data-act="pool-open" data-id="' + u.id + '">' +
      '<td class="c-who"><button class="pwho" data-act="pool-open" data-id="' + u.id + '">' + V.pav(u) +
        '<span class="pwho-t"><span class="pnm" title="' + esc(u.name) + '">' + esc(u.name) + '</span>' +
        (s.email == null ? '<span class="psub pmute">' + ic('lock',11,2.2) + 'Contact hidden</span>'
          : '<span class="psub" title="' + esc(s.email) + '">' + (s.email ? esc(s.email) : 'No email') + '</span>') +
        '</span></button></td>' +
      cell(where || s.country, where ? s.country : null) +
      cell(s.occupation, null) +
      cell(M.date(ts[0]), ts[1] ? M.stamp(s.timestamp).split(', ')[1] : null, 'tnum') +
      '<td>' + V.pvis(u) + '</td>' +
      '<td class="c-act"><button class="pdots" data-act="pool-manage" data-id="' + u.id + '" title="Manage" ' +
        'aria-label="Manage ' + esc(u.name) + '">&#8943;</button></td>' +
    '</tr>';
  },
  /* a search that finds nobody and filters that leave nobody are different problems */
  poolNone(f){
    const q = (f.q || '').trim(), byQuery = q && !M.poolRows({ q, people:f.people, ini:f.ini }).length;
    return '<div class="pstate">' + ic('search',26,1.6) +
      (byQuery ? '<h3>No participant matches “' + esc(q) + '”</h3><p>Check the spelling, or search by email, ' +
          'phone, city or country. Private profiles can only be found by name or region.</p>' +
          '<button class="btn" data-act="pool-filter" data-k="q" data-v="">Clear search</button>'
        : '<h3>No participants match these filters</h3><p>Try removing a filter or picking another status.</p>' +
          '<button class="btn" data-act="pool-clear">Clear filters</button>') + '</div>';
  },
  poolSkeleton(){
    const bar = w => '<span class="psk" style="width:' + w + '"></span>';
    return '<div class="plist" aria-busy="true" aria-label="Loading participants">' +
      '<div class="ptwrap"><table class="ptable">' +
      '<colgroup><col class="c-who"><col class="c-loc"><col class="c-occ">' +
        '<col class="c-reg"><col class="c-vis"><col class="c-act"></colgroup><tbody>' +
      Array.from({ length:8 }, () => '<tr class="pskrow"><td class="c-who"><span class="pwho"><span class="pav psk">' +
        '</span><span class="pwho-t" style="flex:1">' + bar('70%') + bar('50%') + '</span></span></td><td>' + bar('80%') + bar('40%') + '</td><td>' + bar('70%') + '</td><td>' + bar('80%') + bar('40%') +
        '</td><td>' + bar('60px') + '</td><td></td></tr>').join('') +
      '</tbody></table></div></div>';
  },
  poolEmpty(){
    return '<div class="pstate big">' + ic('people',30,1.6) + '<h3>No participants yet</h3>' +
      '<p>People appear here as soon as they register for any of your initiatives — one record each, ' +
      'however many they join.</p><a class="btn p" href="#/initiatives">Go to Initiatives</a></div>';
  },
  poolError(){
    return '<div class="pstate big" role="alert">' + ic('x',30,1.6) + '<h3>We couldn’t load the Talent Pool</h3>' +
      '<p>Nothing was lost. Check your connection and try again.</p>' +
      '<a class="btn p" href="#/pool">Try again</a></div>';
  },

  /* -- the drawer: Profile to read, Manage to act, both over the list so your place is kept -- */
  psheet(label, head, body, foot){
    return '<div class="pscrim" data-act="pool-close"></div>' +
      '<aside class="psheet" role="dialog" aria-modal="true" aria-label="' + esc(label) + '">' +
        '<div class="psheet-h">' + head + '</div>' +
        '<div class="psheet-b">' + body + '</div>' +
        (foot ? '<div class="psheet-f">' + foot + '</div>' : '') +
      '</aside>';
  },
  pclose(){ return '<button class="pdots" data-act="pool-close" aria-label="Close">' + ic('x',15,2.2) + '</button>'; },
  /* the drawer's toolbar, the same in every view: optional back, title, close */
  ptool(title, back){
    return '<div class="ptool">' + (back ? '<button class="pdots" data-act="' + back[0] + '" aria-label="' + back[1] +
      '" title="' + back[1] + '">' + ic('back',16,2.2) + '</button>' : '') +
      '<span class="ptool-t">' + esc(title) + '</span>' + V.pclose() + '</div>';
  },
  poolPanel(f){
    return f.mode === 'profile' && f.open.length === 1 ? V.poolProfile(f) : V.poolManage(f);
  },
  /* the H2S fields, grouped the way a person reads them; what the participant hid is listed
     as hidden rather than left out, so a private profile reads as a choice, not a gap */
  poolProfile(f){
    const u = M.person(f.open[0]), s = M.shown(u), priv = M.isPrivate(u);
    const first = esc(u.name.trim().split(/\s+/)[0]);
    /* WhatsApp stays in the record and the CSV export, but isn't shown on the profile */
    const fields = M.PFIELDS.filter(x => x[0] !== 'whatsapp');
    const val = (k, v) => {
      if(!v) return '<span class="pnil">Not provided</span>';
      if(k === 'email') return '<a href="mailto:' + esc(v) + '">' + esc(v) + '</a>';
      if(k === 'mobile') return '<span class="num">' + esc(v) + '</span>';
      if(k === 'dob') return M.date(v) + ' <span class="pnil">· ' + M.age(v) + ' yrs</span>';
      if(k === 'github' || k === 'linkedin') return M.safeUrl(v)
        ? '<a href="' + esc(v) + '" target="_blank" rel="noopener noreferrer">' + esc(v.replace(/^https?:\/\//i, '')) + '</a>'
        : '<span class="pnil">Not a valid link</span>';
      return esc(v);
    };
    const groups = ['Contact','Personal','Location','Links'].map(g => {
      const fs = fields.filter(x => x[2] === g && s[x[0]] !== null);
      return fs.length ? '<section class="psec"><h3>' + g + '</h3><dl class="pdl">' + fs.map(x =>
        '<div><dt>' + x[1] + '</dt><dd>' + val(x[0], s[x[0]]) + '</dd></div>').join('') + '</dl></section>' : '';
    }).join('');
    const hidden = fields.filter(x => s[x[0]] === null);
    const utm = M.UTM.filter(x => s.utm[x[0]]);
    const quick = [s.email && ['mailto:' + s.email, 'Email', ''],
      M.safeUrl(s.github) && [s.github, 'GitHub', ' target="_blank" rel="noopener noreferrer"'],
      M.safeUrl(s.linkedin) && [s.linkedin, 'LinkedIn', ' target="_blank" rel="noopener noreferrer"']].filter(Boolean);
    const head = V.ptool('Participant profile') +
      '<div class="pprof">' + V.pav(u, true) + '<div style="min-width:0"><h2>' + esc(s.name) + '</h2>' +
        '<p>' + esc([s.occupation, M.place3(s)].filter(Boolean).join(' · ') || 'No details provided') + '</p>' +
        '<div class="row" style="margin-top:8px;gap:6px">' + V.pstatus(s.status) + V.pvis(u) + '</div></div></div>' +
      (quick.length ? '<div class="pquick">' + quick.map(q => '<a class="btn sm" href="' + esc(q[0]) + '"' + q[2] + '>' +
        q[1] + '</a>').join('') + '</div>' : '');
    const body =
      (priv ? '<div class="pnote">' + ic('lock',16,2) + '<div><b>' + first + ' has a private profile.</b> You can see ' +
        'their status, occupation, region and how they registered. Their contact details and personal information ' +
        'stay hidden.</div></div>' : '') +
      groups +
      (hidden.length ? '<section class="psec"><h3>Hidden by ' + first + '</h3><div class="phid">' +
        hidden.map(x => '<span>' + ic('lock',11,2.2) + x[1] + '</span>').join('') + '</div></section>' : '') +
      '<section class="psec"><h3>Registration</h3><dl class="pdl">' +
        '<div><dt>Registered</dt><dd>' + (s.timestamp ? M.stamp(s.timestamp) : '<span class="pnil">Not recorded</span>') + '</dd></div>' +
        '<div><dt>Status</dt><dd>' + V.pstatus(s.status) + '</dd></div>' +
        (utm.length ? utm.map(x => '<div><dt>UTM ' + x[1].toLowerCase() + '</dt><dd>' + esc(s.utm[x[0]]) + '</dd></div>').join('')
          : '<div><dt>Source</dt><dd><span class="pnil">Not tracked</span></dd></div>') + '</dl></section>' +
      '<section class="psec"><h3>In your initiatives</h3>' + (u.in.length ? M.history(u).map(h => V.poolWhere(u, h)).join('')
        : '<p class="pnil">Not in any of your initiatives yet.</p>') + '</section>';
    return V.psheet('Profile of ' + u.name, head, body,
      '<span class="psub" style="flex-grow:1;white-space:normal">Change team, add to an initiative or remove</span>' +
      '<button class="btn p" data-act="pool-manage" data-id="' + f.open[0] + '">Manage participant</button>');
  },
  poolWhere(u, h){
    const m = h.m, p = h.p, shut = !p || p.state === 'closed', gone = m.state === 'removed';
    return '<div class="pwhere' + (gone ? ' gone' : '') + '"><div style="min-width:0">' +
      '<b title="' + esc(p ? p.name : m.p) + '">' + esc(p ? p.name : m.p) + '</b>' +
      '<span class="psub">' + (gone ? 'Removed · ' : '') + 'joined ' + M.date(m.at) + (h.result ? ' · <b class="pres">' + h.result + '</b>' : '') + '</span></div>' +
      (p ? '<span class="pill">' + esc(p.state) + '</span>' : '') +
      (gone && !shut ? '<button class="link" data-act="pool-restore" data-id="' + u.id + '" data-pid="' + m.p +
        '">Restore</button>' : '') + '</div>';
  },
  poolManage(f){
    const ids = f.open, us = ids.map(M.person), one = ids.length === 1 ? us[0] : null, a = f.act;
    /* one back, always in the same place: from an action to the list, from the list to the profile */
    const head = V.ptool(one ? 'Manage participant' : 'Manage participants',
        a ? ['pool-back', 'Back to all actions'] : one ? ['pool-profile', 'Back to profile'] : null) +
      (one ? '<div class="pprof sm">' + V.pav(one) + '<div style="min-width:0"><h2>' + esc(one.name) + '</h2>' +
          '<p>' + esc([one.occupation, one.country].filter(Boolean).join(' · ')) + '</p></div></div>'
        : '<h2 class="pmulti">' + M.n(ids.length) + ' participants selected</h2><div class="row" style="margin-top:10px;gap:6px">' +
          us.slice(0, 8).map(u => '<span class="chip">' + esc(u.name) + '</span>').join('') +
          (us.length > 8 ? '<span class="chip">+' + M.n(us.length - 8) + ' more</span>' : '') + '</div>');
    if(a) return V.psheet('Manage', head,
      '<h3 class="ptitle">' + V.POOLACT[a.type][0] + '</h3><p class="pnil" style="margin-top:4px">' +
      V.POOLACT[a.type][1] + '</p>' + V.poolFields(f, ids),
      '<button class="btn" data-act="pool-back">Cancel</button>' +
      '<button class="btn ' + (a.type === 'drop' || a.type === 'dropall' ? 'pdanger-s' : 'p') +
        '" data-act="pool-go">' + V.POOLACT[a.type][2] + '</button>');
    const why = M.poolActs(ids);
    const group = (title, keys) => '<h3 class="pgrp">' + title + '</h3>' + keys.map(k => '<button class="pact' +
      (k === 'dropall' ? ' red' : '') + '" data-act="pool-pick" data-v="' + k + '"' + (why[k] ? ' disabled' : '') + '>' +
      '<b>' + V.POOLACT[k][0] + '</b><span>' + (why[k] ? esc(why[k]) : V.POOLACT[k][1]) + '</span>' +
      ic('arrow',14,2) + '</button>').join('');
    return V.psheet('Manage', head, '<p class="pnil">What do you want to do?</p>' +
      group('Initiative', ['add','drop']) +
      group('Everything', ['dropall']) +
      (one && one.in.some(m => m.state === 'removed') ? '<h3 class="pgrp">Removed earlier</h3>' +
        M.history(one).filter(h => h.m.state === 'removed').map(h => V.poolWhere(one, h)).join('') : ''));
  },
  poolFields(f, ids){
    const a = f.act, inis = M.actInis(ids, a.type);
    const said = a.pid || a.type === 'dropall' ? M.impact(ids, a) : [];
    return (a.type === 'dropall' ? '' : '<div class="f" style="margin:18px 0 0"><label>Initiative</label>' +
        '<select class="in" data-bind="pool.a.pid">' + V.popt('', 'Pick one', a.pid) +
        inis.map(id => V.popt(id, M.initiative(id).name, a.pid)).join('') + '</select>' +
        (a.type === 'add' ? '<span class="hint">Closed initiatives take nobody new.</span>' : '') + '</div>') +
      (said.length ? '<div class="pimpact"><div class="lbl">What will happen</div><ul>' +
        said.map(s => '<li>' + esc(s) + '</li>').join('') + '</ul></div>' : '') +
      (f.err ? '<p class="perr" role="alert">' + esc(f.err) + '</p>' : '');
  },
  /* ---------------- 8 · panel ---------------- */
  panel(p, open){
    const L = p.live || {};
    const act = p.panel.filter(e => !e.removed);
    return V.chrome('<div class="wrap">' +
      '<div class="crumb"><a href="#/initiatives">Initiatives</a><i>&#8250;</i>' +
        '<a href="#/p/' + p.id + '">' + esc(p.name) + '</a><i>&#8250;</i>' +
        '<span style="color:var(--ink);font-weight:500">Panel</span></div>' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;' +
        'flex-wrap:wrap;margin-top:14px">' +
        '<div style="max-width:78ch"><h1 style="font-size:26px;font-weight:900">Panel</h1>' +
        '<p style="margin:9px 0 0;font-size:13.5px;color:var(--muted)">Who is on it, what each holds, and what each has given. Added from your organisation’s roster.</p></div>' +
        '<a class="btn p" data-act="toast" data-msg="Roster picker — not in this pass">' +
          ic('plus',13,2.4) + 'Add to this panel</a>' +
      '</div>' +
      '<div class="stat" style="margin-top:22px;padding-bottom:20px;border-bottom:1px solid var(--line-soft)">' +
        V.bignum(act.length, 'Evaluators','') +
        V.bignum(((p.config.evaluation || {}).categories || []).length, 'Categories','') +
        V.bignum(M.n(L.allocations), 'Allocations',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:3px">' +
          (p.config.evaluation || {}).perEntry + ' per entry, per category</div>') +
        V.bignum((M.pct(L.scored, L.allocations) == null ? '—'
          : M.pct(L.scored, L.allocations) + '%'), 'Scored',
          '<div style="font-size:11.5px;color:var(--faint);margin-top:3px">' + M.n(L.scored) +
          ' of ' + M.n(L.allocations) + '</div>') +
      '</div>' +
      (L.shortBusiness ? '<div class="ban warn" style="margin-top:20px"><span class="dot"></span>' +
        '<div><strong style="font-size:13.5px;color:var(--warn)">' + M.n(L.shortBusiness) +
        ' entries are short of an evaluator in Business</strong>' +
        '<p style="margin:5px 0 0;font-size:13px">They hold one score where the rule says two, so ' +
          'they cannot be ranked. Two more Business evaluators, or drop that category to one score ' +
          'per entry.</p></div></div>' : '') +
      '<div class="tbl" style="margin-top:20px">' +
        '<div class="tr grid th" style="grid-template-columns:minmax(0,1fr) 126px 108px 96px 112px 116px;height:36px">' +
          '<span>Evaluator</span><span>Category</span><span>Allocated</span><span>Scored</span>' +
          '<span>Avg given</span><span>State</span></div>' +
        p.panel.map(e => V.panelRow(p, e, open)).join('') +
        V.pager('1–' + p.panel.length, p.panel.length) +
      '</div>' +
      '<div class="three" style="margin-top:26px;padding-top:22px;border-top:1px solid var(--line-soft)">' +
        V.note3('Removing keeps the scores','A removed evaluator holds nothing new, but every score ' +
          'they gave stays and still counts — deleting them would change a leaderboard partly built ' +
          'on them.') +
        V.note3('Deallocating is not removing','The entry returns to the pool for that category. An ' +
          'existing score is kept and the entry goes to somebody else for a second opinion.') +
        V.note3('Category decides what they see','An evaluator only ever sees their own ' +
          'category&#8217;s parameters. Moving someone between categories does not carry scores across.') +
      '</div></div>', 'initiatives');
  },
  panelRow(p, e, open){
    const pct = M.pct(e.scored, e.allocated) || 0;
    const isOpen = (open === e.ini);
    const href = isOpen ? '#/p/' + p.id + '/panel' : '#/p/' + p.id + '/panel/open/' + e.ini;
    return '<a class="tr grid" href="' + href + '" ' +
      'style="grid-template-columns:minmax(0,1fr) 126px 108px 96px 112px 116px;height:62px;' +
      'color:inherit' + (e.removed ? ';background:var(--bg-soft)' : '') + '">' +
      '<span style="display:flex;align-items:center;gap:11px;min-width:0">' +
        '<span class="avatar" style="width:30px;height:30px;font-size:11px;background:' +
        (e.removed ? 'var(--line-soft);color:var(--faint)' : 'var(--primary-soft);color:var(--primary-dark)') +
        '">' + e.ini + '</span><span style="min-width:0">' +
        '<span style="font-size:14px;font-weight:600' + (e.removed ? ';color:var(--muted)' : '') +
        '">' + esc(e.name) + '</span>' +
        '<div style="font-size:12px;color:var(--muted);margin-top:2px">' + esc(e.org) + '</div>' +
        '</span></span>' +
      '<span class="pill">' + e.cat + '</span>' +
      '<span class="num" style="font-size:13.5px' + (e.removed ? ';color:var(--faint)' : '') + '">' +
        M.n(e.allocated) + '</span>' +
      '<span><span class="num" style="font-size:13.5px">' + M.n(e.scored) + '</span>' +
        (e.removed ? '<div style="font-size:12px;color:var(--muted)">kept</div>'
                   : '<span class="bar" style="margin-top:5px"><i style="width:' + pct + '%"></i></span>') +
        '</span>' +
      '<span class="num" style="font-size:13.5px;color:' + (e.flag ? 'var(--warn)' : 'var(--ink)') +
        '">' + e.avg.toFixed(1) + '</span>' +
      '<span style="font-size:12px;color:' + (e.removed ? 'var(--muted)' : e.flag ? 'var(--warn)' : 'var(--ok)') +
        '">' + (e.removed ? 'Removed' : e.flag || 'On track') + '</span></a>' +
      (isOpen ? V.panelOpen(p, e) : '');
  },

  /* what one evaluator has scored — three most recent, then its own page */
  panelOpen(p, e){
    const rows = p.entries.filter(x => x.state === 'ok').slice(0, 3);
    return '<div style="background:var(--bg-soft);border-bottom:1px solid var(--line)">' +
      '<div style="padding:14px 18px 10px 62px;display:flex;justify-content:space-between;' +
        'align-items:baseline;gap:16px;flex-wrap:wrap">' +
        '<div style="min-width:0"><div class="lbl">What ' + e.name.split(' ')[0] +
          ' has scored</div>' +
        (e.flag === 'Scores high'
          ? '<p style="margin:7px 0 0;font-size:12.5px;color:var(--muted);max-width:76ch">Average ' +
            e.avg.toFixed(1) + ' against a panel average of 7.4. Every entry she holds sits above ' +
            'every entry she does not.</p>' : '') + '</div>' +
        '<a class="link" href="#/p/' + p.id + '/panel/' + e.ini + '">Deallocate in bulk</a></div>' +
      '<div style="display:grid;grid-template-columns:minmax(0,1fr) 128px 104px 150px 116px;' +
        'column-gap:14px;padding:0 18px 0 62px;height:32px;align-items:center">' +
        ['Entry','Allocated','Score given','',''].map(h =>
          '<span class="tag">' + h + '</span>').join('') + '</div>' +
      rows.map(x =>
        '<div style="display:grid;grid-template-columns:minmax(0,1fr) 128px 104px 150px 116px;' +
          'column-gap:14px;padding:0 18px 0 62px;height:50px;align-items:center;' +
          'border-bottom:1px solid var(--line-soft)">' +
        '<span><span style="font-size:13.5px;font-weight:500">' + esc(x.name) + '</span>' +
        '<div style="font-size:12px;color:var(--muted)">' + x.members +
          (x.members === 1 ? ' member · solo entry' : ' members') + ' · ' + esc(x.country) +
        '</div></span>' +
        '<span style="font-size:12.5px;color:var(--muted)">' + esc(x.allocated || '—') + '</span>' +
        (x.score ? '<span><span class="num" style="font-size:14px;font-weight:600">' +
          x.score.toFixed(1) + '</span><div style="font-size:12px;color:var(--muted)">out of 10' +
          '</div></span>' : '<span style="font-size:13px;color:var(--warn)">Not scored</span>') +
        '<a class="link" href="#/p/' + p.id + '/score/' + encodeURIComponent(x.name) +
          '">Open the score sheet</a>' +
        '<span class="link" style="color:var(--muted)">Deallocate</span></div>').join('') +
      '<div style="padding:13px 18px 16px 62px;display:flex;align-items:baseline;gap:16px">' +
        '<a class="link" href="#/p/' + p.id + '/panel/' + e.ini + '">Show all ' +
          M.n(e.allocated) + '</a>' +
        '<span style="font-size:11.5px;color:var(--faint)">Three most recent. The full list opens ' +
          'as its own page.</span></div></div>';
  },
  note3(t, b){
    return '<div><strong style="font-size:14px">' + t + '</strong>' +
      '<p style="margin:7px 0 0;font-size:12.5px;color:var(--muted)">' + b + '</p></div>';
  },

  /* ---------------- 8a · one evaluator ---------------- */
  evaluator(p, ini){
    const e = p.panel.find(x => x.ini === ini);
    if(!e) return V.chrome('<div class="wrap">No such evaluator.</div>', 'initiatives');
    const left = e.allocated - e.scored;
    const panelAvg = 7.4;
    const rows = p.entries.filter(x => x.state !== 'removed');
    return V.chrome('<div class="wrap">' +
      '<div class="crumb"><a href="#/p/' + p.id + '">' + esc(p.name) + '</a><i>&#8250;</i>' +
        '<a href="#/p/' + p.id + '/panel">Panel</a><i>&#8250;</i>' +
        '<span style="color:var(--ink);font-weight:500">' + esc(e.name) + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;' +
        'flex-wrap:wrap;margin-top:16px">' +
        '<div style="display:flex;align-items:center;gap:13px">' +
          '<span class="avatar" style="background:var(--primary-soft);color:var(--primary-dark)">' +
            e.ini + '</span>' +
          '<div><h1 style="font-size:24px;font-weight:900">' + esc(e.name) + '</h1>' +
          '<div style="display:flex;gap:9px;margin-top:7px;align-items:center;flex-wrap:wrap">' +
          '<span class="pill">' + e.cat + '</span><span style="font-size:12.5px;color:var(--muted)">' +
          esc(e.org) + '</span></div></div></div>' +
        '<div style="display:flex;gap:10px">' +
          '<button class="btn" data-act="toast" data-msg="Allocation picker — not in this pass">Allocate more</button>' +
          '<button class="btn" data-act="toast" data-msg="Removing keeps every score they gave">Remove from panel</button>' +
        '</div></div>' +
      '<div class="stat" style="margin-top:22px;padding-bottom:20px;border-bottom:1px solid var(--line-soft)">' +
        V.bignum(M.n(e.allocated),'Allocated','') +
        V.bignum(M.n(e.scored),'Scored','<div style="font-size:11.5px;color:var(--faint);margin-top:3px">' +
          (M.pct(e.scored, e.allocated) || 0) + '% · panel is at 71%</div>') +
        V.bignum(M.n(left),'Left to score','<div style="font-size:11.5px;color:var(--faint);margin-top:3px">' +
          '20 days to ' + M.date(p.dates.evaluation[1], false) + '</div>') +
        V.bignum(e.avg.toFixed(1),'Avg given','<div style="font-size:11.5px;color:var(--faint);margin-top:3px">' +
          e.cat + ' panel: ' + panelAvg + '</div>') +
      '</div>' +
      '<div style="display:flex;align-items:center;gap:18px;padding:11px 18px;border-radius:var(--r);' +
        'background:var(--primary-soft);flex-wrap:wrap;margin-top:20px">' +
        '<span style="font-size:13.5px;font-weight:600;color:var(--primary-dark)">3 selected</span>' +
        '<a class="link" data-act="toast" data-msg="Deallocated — the scores they already gave are kept">Deallocate</a>' +
        '<a class="link" data-act="toast" data-msg="Moved to another evaluator">Move to another evaluator</a>' +
        '<a class="link" data-act="toast" data-msg="Flagged for a second opinion">Flag for a second opinion</a>' +
        '<div style="flex-grow:1"></div>' +
        '<span style="font-size:12px;color:var(--primary)">Scores already given are kept whatever ' +
          'you choose.</span></div>' +
      '<div class="tbl" style="margin-top:14px">' +
        '<div class="tr grid th" style="grid-template-columns:minmax(0,1fr) 128px 118px 132px 128px;height:36px">' +
          '<span>Entry</span><span>Allocated</span><span>Score given</span><span>Scored on</span>' +
          '<span></span></div>' +
        rows.map(x =>
          '<div class="tr grid" style="grid-template-columns:minmax(0,1fr) 128px 118px 132px 128px;height:58px">' +
          '<span><span style="font-size:13.5px;font-weight:500">' + esc(x.name) + '</span>' +
          '<div style="font-size:12px;color:var(--muted);margin-top:2px">' + x.members +
            (x.members === 1 ? ' member · solo entry' : ' members') + ' · ' + esc(x.country) +
            (x.mentored ? ' · <span style="color:var(--warn)">you mentored this team</span>' : '') +
          '</div></span>' +
          '<span style="font-size:12.5px;color:var(--muted)">' + esc(x.allocated || '—') + '</span>' +
          (x.score
            ? '<span><span class="num" style="font-size:14.5px;font-weight:600">' + x.score.toFixed(1) +
              '</span><span style="font-size:11.5px;color:var(--faint)"> / 10</span></span>'
            : '<span style="font-size:13px;color:var(--warn)">Not scored</span>') +
          '<span style="font-size:12.5px;color:var(--muted)">' + esc(x.scoredOn || '—') + '</span>' +
          '<a class="link" href="#/p/' + p.id + '/score/' + encodeURIComponent(x.name) + '">Score sheet</a>' +
          '</div>').join('') +
        V.pager('1–' + rows.length, M.n(e.allocated)) +
      '</div>' +
      '<div class="three" style="margin-top:26px;padding-top:22px;border-top:1px solid var(--line-soft)">' +
        V.note3('Why this is its own page','The Panel row shows the three most recent. 482 rows ' +
          'inside an expanded row is a list hiding inside a list.') +
        V.note3('Deallocating never loses a score','It stays on the record and still counts. The ' +
          'entry goes to somebody else as a second opinion, not a replacement.') +
        V.note3('The mentoring flag is shown, not enforced','Panels are small, so it is recorded on ' +
          'the row and on the score rather than blocked.') +
      '</div></div>', 'initiatives');
  },

  /* ---------------- 8b · score sheet ---------------- */
  score(p, entryName){
    const e = p.entries.find(x => x.name === entryName) || p.entries[0];
    const cat = (p.config.evaluation.categories || []).find(c => c.name === 'Technical');
    const given = { 'Working solution':10, 'Code quality':9,
                    'Architecture and scalability':10, 'Use of the ICC data set':9 };
    const reasons = {
      'Working solution':'Cloned and ran on a Pixel 7 with the sample footage. Tracked 41 of 43 ' +
        'deliveries; both misses were wides bowled from behind the umpire.',
      'Code quality':'78% coverage on the tracking module, and the commit history shows real ' +
        'iteration rather than one dump the night before.',
      'Architecture and scalability':'Inference is on the phone, so server cost does not move with ' +
        'the number of grounds. That is the right call and they explain why.',
      'Use of the ICC data set':'Ball-by-ball schema matched exactly, so the output drops into the ' +
        'club scorebook with no mapping.'
    };
    let total = 0;
    cat.params.forEach(pr => total += given[pr[0]] * pr[3] / 100);

    return V.chrome('<div class="wrap wide">' +
      '<div class="crumb"><a href="#/p/' + p.id + '/panel">Panel</a><i>&#8250;</i>' +
        '<span style="color:var(--ink);font-weight:500">' + esc(e.name) + '</span></div>' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;' +
        'flex-wrap:wrap;margin-top:14px">' +
        '<div><h1 style="font-size:25px;font-weight:900">' + esc(e.name) + '</h1>' +
        '<div style="display:flex;gap:9px;margin-top:9px;flex-wrap:wrap;align-items:center">' +
        '<span class="pill">' + e.members + ' members · ' + esc(e.country) + '</span>' +
        '<span class="pill blue">Technical · your category</span>' +
        '<span class="tag">entry 2 of 482</span></div></div>' +
        '<div style="display:flex;gap:8px"><span class="pg">' + ic('back',15,2.2) + '</span>' +
        '<span class="pg">' + ic('arrow',15,2.2) + '</span>' +
        '<button class="btn" style="margin-left:6px" data-act="toast" data-msg="Skipped — it stays in your queue">Skip for now</button></div>' +
      '</div>' +
      '<div style="display:grid;grid-template-columns:minmax(0,420px) minmax(0,1fr);gap:34px;' +
        'margin-top:22px;align-items:start">' +

        '<div style="position:sticky;top:86px">' +
          '<div class="lbl">What you are judging</div>' +
          '<div class="card" style="margin-top:12px">' +
            '<div style="font-family:Archivo,sans-serif;font-size:16px;font-weight:700;' +
              'letter-spacing:-.02em">Powerplay — ball-tracking for community grounds</div>' +
            '<p style="margin:8px 0 0;font-size:13px;color:var(--muted)">A phone-camera pipeline ' +
              'that tracks deliveries on grounds with no fixed cameras, and writes the ball-by-ball ' +
              'record straight into the club scorebook.</p>' +
            '<div style="margin-top:14px;padding-top:13px;border-top:1px solid var(--line-soft)">' +
            [['Problem statement','Grassroots data capture'],['Repository','github.com/powerplay/track'],
             ['Demo video','2 min 48 s'],['Presentation','powerplay-deck.pdf · 11 pages'],
             ['Submitted','8 Jan, 22:41 · edited once']]
              .map(r => '<div style="display:flex;align-items:center;gap:11px;padding:10px 0;' +
                'border-bottom:1px solid var(--line-soft)">' +
                '<span style="font-size:12.5px;color:var(--muted);min-width:112px">' + r[0] +
                '</span><span style="font-size:13.5px;font-weight:500">' + r[1] + '</span></div>')
              .join('') + '</div></div>' +
          '<div class="card" style="margin-top:16px;background:var(--bg-soft)">' +
            '<div style="display:flex;align-items:center;gap:9px;color:var(--faint)">' + ic('lock',13,2) +
            '<strong style="font-size:13.5px;color:var(--ink)">The AI round has already scored this ' +
              'entry</strong></div>' +
            '<p style="margin:7px 0 0 22px;font-size:12.5px;color:var(--muted)">You will see it the ' +
              'moment you submit yours. Reading it first would make it your answer rather than a ' +
              'second one.</p></div>' +
        '</div>' +

        '<div style="min-width:0">' +
          '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px">' +
            '<div><h2 style="font-size:19px;font-weight:700">Technical</h2>' +
            '<p style="margin:6px 0 0;font-size:13px;color:var(--muted)">Four parameters, your ' +
              'category only. Ideation and Business are scored by other people and you never see ' +
              'them.</p></div>' +
            '<span class="num" style="font-size:12px;color:var(--warn)">draft, not submitted</span></div>' +
          cat.params.map(pr => {
            const v = given[pr[0]];
            return '<div style="padding:18px 0;border-bottom:1px solid var(--line-soft)">' +
              '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:16px">' +
              '<div><div style="font-size:14.5px;font-weight:600">' + pr[0] + '</div>' +
              (pr[1] ? '<div style="font-size:12.5px;color:var(--muted);margin-top:4px">' + pr[1] +
                '</div>' : '') + '</div>' +
              '<span class="tag">' + pr[3] + '% of the category</span></div>' +
              '<div style="display:flex;align-items:center;gap:16px;margin-top:13px;flex-wrap:wrap">' +
              '<div style="display:flex;gap:3px">' +
              Array.from({length:10}, (_, i) =>
                '<span style="width:26px;height:26px;border-radius:2px;display:grid;place-items:center;' +
                'font-family:\'IBM Plex Mono\',monospace;font-size:11.5px;' +
                (i < v ? 'background:var(--primary);color:#fff;font-weight:600'
                       : 'border:1px solid var(--line);color:var(--muted)') + '">' + (i + 1) +
                '</span>').join('') + '</div>' +
              '<span class="num" style="font-size:16px;font-weight:600">' + v +
              '</span><span style="font-size:12px;color:var(--faint);margin-left:-10px">/ 10</span></div>' +
              '<div style="border:1px solid var(--line);border-radius:3px;padding:9px 11px;' +
                'font-size:13px;margin-top:11px">' + reasons[pr[0]] + '</div></div>';
          }).join('') +
          '<div class="card" style="margin-top:20px;display:flex;justify-content:space-between;' +
            'align-items:center;gap:20px;flex-wrap:wrap">' +
            '<div><div class="lbl" style="margin-bottom:6px">Your score for Technical</div>' +
            '<div style="font-size:12.5px;color:var(--muted)">' +
            cat.params.map(pr => given[pr[0]] + '×' + pr[3] + '%').join(' + ') +
            ' — the weightage does the arithmetic, you never type a total.</div></div>' +
            '<div class="num" style="font-size:32px;font-weight:700;letter-spacing:-.02em">' +
            total.toFixed(1) + '<span style="font-size:15px;color:var(--faint);font-weight:500"> / 10' +
            '</span></div></div>' +
          '<div style="display:flex;align-items:center;gap:12px;margin-top:18px;flex-wrap:wrap">' +
            '<button class="btn p" data-act="toast" data-msg="Score submitted — the AI score is now visible">Submit score</button>' +
            '<button class="btn" data-act="toast" data-msg="Saved. Next entry loaded.">Save and take the next one</button>' +
            '<div style="flex-grow:1"></div>' +
            '<span class="num" style="font-size:12px;color:var(--ok)">draft saved 4:07 pm</span></div>' +
          '<p class="qn">Submitting is not final — you can change a score until the window closes ' +
            'on ' + M.date(p.dates.evaluation[1]) + ', and every change is kept with its reason. ' +
            'What you cannot do is see the AI score first.</p>' +
        '</div>' +
      '</div></div>', 'initiatives', true);
  },

  /* ---------------- 9 · communications ---------------- */
  comms(p){
    const groups = [['registration','Registration'],['team','Team formation'],['quiz','Quiz'],
                    ['submission','Project submission'],['evaluation','Evaluation'],
                    ['result','Results & prizes'],['any','Any time']];
    const inFlow = k => k === 'any' || k === 'result' || p.modules.indexOf(k) > -1;
    const msgs = p.messages.filter(m => inFlow(m[0]));
    return V.chrome('<div class="wrap">' +
      '<div class="crumb"><a href="#/p/' + p.id + '">' + esc(p.name) + '</a><i>&#8250;</i>' +
        '<span style="color:var(--ink);font-weight:500">Communications</span></div>' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-end;gap:20px;' +
        'flex-wrap:wrap;margin-top:14px">' +
        '<div style="max-width:80ch"><h1 style="font-size:26px;font-weight:900">Communications</h1>' +
        '<p style="margin:9px 0 0;font-size:13.5px;color:var(--muted)">Grouped by the process that sets it off. Remove a module and its messages leave with it.</p></div>' +
        '<button class="btn p" data-act="toast" data-msg="Composer — not in this pass">' +
          ic('plus',13,2.4) + 'New message</button></div>' +
      '<div class="card" style="margin-top:20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap">' +
        '<span style="font-size:13px"><b>Quiet rules</b> · at most <b>2</b> messages to one person ' +
          'per day · nothing between <b>21:00 and 08:00</b> their time · unsubscribing stops ' +
          'announcements, never the ones they need</span>' +
        '<div style="flex-grow:1"></div><a class="link" data-act="toast" data-msg="Quiet rules — not in this pass">Change</a></div>' +
      '<div class="tbl" style="margin-top:18px">' +
        '<div class="tr grid th" style="grid-template-columns:minmax(0,1fr) 178px 168px 120px 118px 40px 88px;height:34px">' +
          '<span>Message</span><span>Goes to</span><span>Sets it off</span><span>Channel</span>' +
          '<span>Last sent</span><span>On</span><span></span></div>' +
        groups.map(([k, label]) => {
          const rows = msgs.filter(m => m[0] === k);
          if(!rows.length) return '';
          return '<div style="display:flex;align-items:center;gap:11px;padding:11px 18px;' +
            'border-top:1px solid var(--line);border-bottom:1px solid var(--line-soft)">' +
            '<span class="lbl" style="color:var(--ink);font-size:10px">' + label + '</span>' +
            '<span style="font-size:12px;color:var(--faint)">' + rows.length +
            (rows.length === 1 ? ' message' : ' messages') + '</span></div>' +
            rows.map(m =>
              '<div class="tr grid" style="grid-template-columns:minmax(0,1fr) 178px 168px 120px 118px 40px 88px;height:60px">' +
              '<span><span style="font-size:13.5px;font-weight:500">' + esc(m[1]) + '</span>' +
              '<div style="font-size:12px;color:var(--muted);margin-top:2px">' + esc(m[2]) + '</div></span>' +
              '<span style="font-size:12.5px;color:var(--muted)">' + esc(m[3]) + '</span>' +
              '<span style="font-size:12.5px;color:var(--muted)">' + esc(m[4]) + '</span>' +
              '<span style="font-size:12.5px;color:var(--muted)">' + esc(m[5]) + '</span>' +
              '<span style="font-size:12.5px;color:' + (m[6] === 'Scheduled' ? 'var(--warn)' :
                m[6] === '—' || m[6] === 'Not sent' ? 'var(--faint)' : 'var(--muted)') + '">' +
                esc(m[6]) + '</span>' +
              '<span class="sw' + (m[7] ? ' on' : '') + '"><i></i></span>' +
              (m[8] ? '<button class="link" data-act="toast" data-msg="Send now → it names the ' +
                'count and the audience rule before it goes">Send now</button>' : '<span></span>') +
              '</div>').join('');
        }).join('') +
        '<div class="pager"><span class="num" style="font-size:12.5px;color:var(--muted)">' +
          msgs.length + ' of ' + msgs.length + '</span>' +
          '<span style="font-size:12px;color:var(--faint)">Grouped in flow order, the same order as ' +
            'the timeline.</span></div>' +
      '</div>' +
      '<div class="three" style="margin-top:26px;padding-top:22px;border-top:1px solid var(--line-soft)">' +
        V.note3('The triggers are the flow','You can only hang a message on a process this initiative ' +
          'runs. Remove a module and its messages are archived, not deleted.') +
        V.note3('Automatic and manual are one object','One row, one switch. An automatic message can ' +
          'still be sent by hand to the people it missed.') +
        V.note3('Sending by hand asks first','Send now names the number and the audience rule before ' +
          'it goes. A mail is the one action here with no undo.') +
      '</div></div>', 'initiatives');
  }
};
