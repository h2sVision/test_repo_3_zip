/* ============================================================
   public.js — the participant-facing initiative page.
   Composed from the rungs. Nothing here is authored twice.
   ============================================================ */

const PUB = {

  /* full page, used by #/public/:id and by the preview frame */
  page(p){
    return '<div class="pub">' + PUB.nav(p) + PUB.body(p, false) + PUB.foot(p) + '</div>';
  },

  nav(p){
    const on = id => M.sectionState(p, id).state === 'ready';
    const links = [['about','About'],['problems','Problems'],['steps','How it works'],
                   ['timeline','Timeline'],['prizes','Prizes'],['mentors','Mentors']]
      .filter(l => on(l[0]));
    return '<div class="pubnav">' +
      '<span class="avatar" style="width:26px;height:26px;border-radius:4px;font-size:9px">' +
        esc(DB.org.short) + '</span>' +
      '<span style="font-family:Archivo,sans-serif;font-weight:700;font-size:14px;' +
        'letter-spacing:-.02em">' + esc(p.name) + '</span>' +
      '<div style="flex-grow:1"></div>' +
      links.map(l => '<span class="pnav">' + l[1] + '</span>').join('') +
      /* the deadline travels with the button — a date the reader cannot see when
         they reach the button is a date that does not influence them */
      (function(){
        const close = p.dates.registration ? p.dates.registration[1] : null;
        const left = close ? M.days(M.today(), close) : null;
        return (left != null && left > 0
          ? '<span class="pclose">' + (left <= 14
              ? '<b>' + left + ' days left</b>' : 'Closes ' + M.date(close, false)) + '</span>'
          : '') +
          '<span class="btn p pcta">Register &#8212; ' + (M.fee(p) || 'free') + '</span>';
      })() + '</div>';
  },

  /* preview = true renders amber bands where content is missing */
  body(p, preview){
    return CATALOGUE.sections.map(id => PUB.section(p, id.id, preview)).join('');
  },

  section(p, id, preview){
    const st = M.sectionState(p, id);
    if(st.state === 'off') return '';
    if(st.state === 'waiting'){
      if(!preview) return '';
      return '<div class="wait"><div class="wt">' + M.section(id).name + ' · waiting</div>' +
        '<div style="font-size:12.5px;color:var(--ink);margin-top:6px;line-height:1.55">' +
        (st.what || st.sub) + '</div>' +
        (st.route ? '<a class="link" href="' + st.route + '" style="display:inline-block;' +
          'margin-top:8px">' + st.link + ' &#8594;</a>' : '') + '</div>';
    }
    const f = PUB[id];
    return f ? f(p, preview) : '';
  },

  /* ---------------- the sections ---------------- */
  hero(p){
    const bits = [M.type(p).name];
    if(p.format.mode) bits.push(p.format.mode === 'virtual' ? 'Virtual'
      : (p.format.mode === 'hybrid' ? 'Hybrid' : 'In person') +
        (p.format.city ? ' · ' + p.format.city : ''));
    const close = p.dates.registration ? p.dates.registration[1] : null;
    const b = M.brand(p), cover = M.coverCss(p);
    return '<div class="hero"' + (cover ? ' style="background:' + cover + ';position:relative"' +
      '><div style="position:absolute;inset:0;background:linear-gradient(115deg,' +
      'rgba(16,18,35,.72),rgba(16,18,35,.34))"></div><div style="position:relative"' : '') + '>' +
      '<div style="display:flex;gap:9px;flex-wrap:wrap">' + bits.map(b =>
        '<span style="border-radius:999px;padding:4px 12px;font-size:12px;font-weight:500;' +
        'background:rgba(255,255,255,.16)">' + esc(b) + '</span>').join('') + '</div>' +
      '<div style="font-family:Archivo,sans-serif;font-size:40px;font-weight:800;' +
        'letter-spacing:-.03em;line-height:1.08;margin-top:18px;max-width:20ch">' + esc(p.name) +
        '</div>' +
      (p.tagline ? '<p style="margin:14px 0 0;font-size:17px;color:rgba(255,255,255,.86);' +
        'max-width:52ch">' + esc(p.tagline) + '</p>' : '') +
      ((p.tags || []).length ? '<div style="display:flex;gap:7px;flex-wrap:wrap;margin-top:18px">' +
        p.tags.map(t => '<span style="border-radius:999px;padding:4px 11px;font-size:12px;' +
        'border:1px solid rgba(255,255,255,.34);color:rgba(255,255,255,.9)">' + esc(t) +
        '</span>').join('') + '</div>' : '') +
      '<div style="display:flex;align-items:center;gap:18px;margin-top:26px;flex-wrap:wrap">' +
        '<span class="btn" style="background:#fff;color:' + b.accent + ';border:0;padding:12px 24px;' +
          'font-size:14.5px;font-weight:700">Register — ' + (M.fee(p) || 'free') + '</span>' +
        (close ? '<span style="font-size:13.5px;color:rgba(255,255,255,.8)">Registration closes ' +
          M.date(close) + '</span>' : '') +
      '</div>' + (cover ? '</div>' : '') + '</div>';
  },

  facts(p){
    const c = p.config, t = c.team || {}, r = c.registration || {};
    const rows = [
      ['Format', p.format.mode === 'virtual' ? 'Virtual'
        : (p.format.mode === 'hybrid' ? 'Hybrid' : 'In person') +
          (p.format.city ? ' · ' + p.format.city : '')],
      ['Who can enter', (r.audience || ['anyone']).indexOf('anyone') > -1 ? 'Anyone on the network'
        : (r.audience || []).map(a => a[0].toUpperCase() + a.slice(1)).join(', ')],
      ['Team size', t.min ? t.min + ' to ' + t.max + (t.solo !== false ? ', or solo' : '') : '—'],
      ['Entries', r.cap ? 'Capped at ' + M.n(r.cap) : '—'],
      ['Cost to enter', M.feeLine(p)],
      ['Prizes', p.prizes.length ? M.money(M.prizeTotal(p)) + ' across ' + p.prizes.length : '—']
    ];
    return '<div style="padding:26px 60px;background:var(--bg-soft);border-bottom:1px solid ' +
      'var(--line-soft)"><div style="display:flex;gap:46px;flex-wrap:wrap">' +
      rows.map(r2 => '<div><div class="lbl">' + r2[0] + '</div>' +
        '<div style="font-size:15px;font-weight:600;margin-top:5px">' + esc(r2[1]) + '</div></div>')
        .join('') + '</div></div>';
  },

  about(p){
    if(p.about.mode === 'html' && p.about.html)
      return '<div class="pubsec">' + (p.about.title ? '<div class="pubt">About</div>' +
        '<div class="pubh">' + esc(p.about.title) + '</div>' : '') +
        '<div style="margin-top:14px">' + PUB.sanitize(p.about.html) + '</div></div>';
    return '<div class="pubsec"><div class="pubt">About</div>' +
      '<div class="pubh">' + esc(p.about.title || 'About this initiative') + '</div>' +
      p.about.body.map(x => '<p class="pubb" style="margin:14px 0 0;max-width:70ch">' + esc(x) +
        '</p>').join('') + '</div>';
  },
  /* the same filter the editor promises: scripts, forms and unlisted iframes come out */
  sanitize(html){
    return String(html)
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/<\/?(form|input|button|iframe|object|embed)\b[^>]*>/gi, '')
      .replace(/ on[a-z]+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  },

  problems(p){
    return '<div class="pubsec"><div class="pubt">Problem statements</div>' +
      '<div class="pubh">Pick the one you want to solve</div>' +
      '<p class="pubsub">Every entry answers one of these. You choose when you submit.</p>' +
      '<div class="pbgrid pubbody">' + p.focus.map((f, i) =>
        '<article class="pbcard">' +
          '<span class="pbn num">' + String(i + 1).padStart(2, '0') + '</span>' +
          '<h3 class="pbh">' + esc(f.title) + '</h3>' +
          '<p class="pbb">' + esc(f.body) + '</p>' +
        '</article>').join('') + '</div></div>';
  },

  /* one step per module, in flow order, described for a participant */
  STEPTEXT:{
    registration:'Fill in the form. Five minutes, and you are in.',
    team:'Build your team, or enter alone — a solo entry competes on the same terms.',
    quiz:'Sit the quiz. It decides who goes through.',
    submission:'Hand in your project: a repository, a demo and a deck. One per entry.',
    evaluation:'Judging. Every entry is scored once by each panel.',
    feedback:'Tell us how it went.',
    webinar:'Join the session.',
    mentor:'Book time with a mentor.',
    custom:'One more step, set by the organisers.'
  },
  steps(p){
    return '<div class="pubsec"><div class="pubt">How it works</div>' +
      '<div class="pubh">' + p.modules.length + ' steps, start to finish</div>' +
      '<div style="margin-top:18px;max-width:74ch">' + p.modules.map((k, i) =>
        '<div style="display:grid;grid-template-columns:30px minmax(0,1fr);column-gap:16px;' +
          'padding:15px 0;border-bottom:1px solid var(--line-soft)">' +
        '<span style="width:26px;height:26px;border-radius:50%;background:var(--primary-soft);' +
          'color:var(--primary-dark);display:grid;place-items:center;font-family:\'IBM Plex Mono\',' +
          'monospace;font-size:11.5px;font-weight:600">' + (i + 1) + '</span>' +
        '<span><span style="font-size:15px;font-weight:600">' + M.mod(k).name + '</span>' +
        '<div style="font-size:13.5px;color:var(--muted);margin-top:4px;line-height:1.55">' +
        (PUB.STEPTEXT[k] || M.mod(k).sub) + '</div></span></div>').join('') + '</div></div>';
  },

  timeline(p){
    const pub = M.timelineRows(p).filter(r => r.isPublic && r.open);
    const hidden = M.timelineRows(p).filter(r => !r.isPublic && r.open);
    return '<div class="pubsec" style="background:var(--bg-soft)">' +
      '<div class="pubt">Timeline</div><div class="pubh">Dates to keep</div>' +
      '<div style="margin-top:18px;max-width:74ch">' + pub.map(r =>
        '<div style="display:grid;grid-template-columns:170px minmax(0,1fr);column-gap:20px;' +
          'padding:13px 0;border-bottom:1px solid var(--line-soft)">' +
        '<span class="num" style="font-size:13px;color:var(--primary);font-weight:600">' +
        M.date(r.open, false) + ' — ' + M.date(r.close, false) + '</span>' +
        '<span><span style="font-size:14.5px;font-weight:600">' + r.name + '</span></span></div>')
        .join('') +
      (p.resultsAt ? '<div style="display:grid;grid-template-columns:170px minmax(0,1fr);' +
        'column-gap:20px;padding:13px 0">' +
        '<span class="num" style="font-size:13px;color:var(--primary);font-weight:600">' +
        M.date(p.resultsAt, false) + '</span><span style="font-size:14.5px;font-weight:600">Results' +
        '</span></div>' : '') + '</div>' +
      (hidden.length ? '<p style="margin:16px 0 0;font-size:12.5px;color:var(--faint)">' +
        hidden.map(h => h.name).join(' and ') + ' ' + (hidden.length > 1 ? 'happen' : 'happens') +
        ' between ' + M.date(hidden[0].open, false) + ' and ' +
        M.date(hidden[hidden.length - 1].close, false) + '. Nothing is asked of you in that ' +
        'window.</p>' : '') + '</div>';
  },

  prizes(p){
    const ranks = p.prizes.filter(z => z.level.kind === 'rank' && z.level.from === z.level.to)
      .slice(0, 3);
    const rest = p.prizes.filter(z => ranks.indexOf(z) === -1);
    /* The top three were cards and the other six were plain text at the same
       weight as a caption — the page stopped caring halfway down its own prize
       list. Everything below the podium is now a proper row with its value. */
    return '<div class="pubsec"><div class="pubt">Prizes</div>' +
      '<div class="pubh">' + M.money(M.prizeTotal(p)) + ' on the table</div>' +
      '<p class="pubsub">Across ' + p.prizes.length + ' prizes. Cash goes to the entry ' +
        'unless a prize says otherwise.</p>' +
      (ranks.length ? '<div class="pzpod pubbody">' + ranks.map((z, i) =>
        '<div class="pzp' + (i === 0 ? ' first' : '') + '">' +
          '<span class="pzpl">' + M.prizeLevel(z.level) + '</span>' +
          '<span class="pzpv">' + (z.cash ? M.money(z.cash) : '&#8212;') + '</span>' +
          (z.items.length > 1 ? '<span class="pzpi">' +
            z.items.slice(1).map(x => esc(x[0])).join(' &#183; ') + '</span>' : '') +
        '</div>').join('') + '</div>' : '') +
      (rest.length ? '<div class="pzmore">' + rest.map(z =>
        '<div class="pzm">' +
          '<span class="pzmn">' + M.prizeLevel(z.level) + '</span>' +
          '<span class="pzmi">' + z.items.map(x => esc(x[0])).join(', ') + '</span>' +
          '<span class="pzmv num">' + (z.cash ? M.money(z.cash) : '&#8212;') + '</span>' +
        '</div>').join('') + '</div>' : '') + '</div>';
  },

  mentors(p){
    return PUB.people(p.mentors, p.mentors.filter(m => m.shown).length +
      ' people you can book time with', 'Mentors',
      'One session per category, bookable once your team is formed.', true);
  },
  jury(p){
    /* deliberately prints no count — shown and scoring are different numbers */
    return PUB.people(p.jury, 'Who picks the winner', 'Jury',
      'The jury sees every panel score and every reason behind it, then orders the shortlist.', false);
  },

  /* one roster component, used by Mentors and Jury. Restored after a range edit
     removed it — the static guard below is what names this class of loss. */
  people(list, title, tag, note, bg){
    const shown = list.filter(x => x.shown);
    if(!shown.length) return '';
    return '<div class="pubsec"' + (bg ? ' style="background:var(--bg-soft)"' : '') + '>' +
      '<div class="pubt">' + tag + '</div><div class="pubh">' + title + '</div>' +
      '<div class="ppl pubbody">' + shown.map(x =>
        '<div class="pp"><span class="ppa">' + x.ini + '</span>' +
        '<span class="ppn">' + esc(x.name) + '</span>' +
        '<span class="ppr">' + esc(x.role) + '</span></div>').join('') + '</div>' +
      (note ? '<p class="pubsub" style="margin-top:22px">' + note + '</p>' : '') +
      '</div>';
  },

  partners(p){
    const tiers = [];
    p.partners.filter(x => x.shown).forEach(x => {
      let t = tiers.find(y => y[0] === x.tier);
      if(!t){ t = [x.tier, []]; tiers.push(t); }
      t[1].push(x);
    });
    if(!tiers.length) return '';
    return '<div class="pubsec" style="background:var(--bg-soft)">' +
      '<div class="pubt">Partners</div><div class="pubh">Who is behind it</div>' +
      '<div class="pubbody">' + tiers.map(t =>
        '<div class="ptier"><div class="ptl">' + esc(t[0]) + '</div>' +
        '<div class="pgrid' + (t[0] === 'Title partner' ? ' lead' : '') + '">' +
          t[1].map(x => '<div class="plogo"><span>' + esc(x.name) + '</span></div>').join('') +
        '</div></div>').join('') + '</div></div>';
  },

  faq(p){
    return '<div class="pubsec"><div class="pubt">FAQ</div>' +
      '<div class="pubh">Before you ask</div>' +
      '<div style="margin-top:18px;max-width:76ch">' + p.faq.map(q =>
        '<div style="padding:14px 0;border-bottom:1px solid var(--line-soft)">' +
        '<div style="font-size:14.5px;font-weight:600">' + esc(q[0]) + '</div>' +
        '<div style="font-size:13.5px;color:var(--muted);margin-top:5px">' + esc(q[1]) +
        '</div></div>').join('') + '</div></div>';
  },

  register(p){
    const close = p.dates.registration ? p.dates.registration[1] : null;
    return '<div style="padding:52px 60px;text-align:center">' +
      '<div class="pubh" style="font-size:30px;margin-top:0">' +
      (close ? 'Registration closes ' + M.date(close) : 'Registration is open') + '</div>' +
      '<p style="margin:12px auto 0;font-size:15px;color:var(--muted);max-width:56ch">Five minutes ' +
        'to enter. You can build your team afterwards.</p>' +
      '<div style="margin-top:22px"><span class="btn p" style="padding:12px 24px;font-size:14.5px">' +
        'Register — ' + (M.fee(p) || 'free') + '</span></div></div>';
  },

  foot(p){
    return '<div style="padding:22px 60px;border-top:1px solid var(--line-soft);display:flex;' +
      'align-items:center;gap:16px;background:var(--bg-soft);flex-wrap:wrap">' +
      '<span style="font-size:12.5px;color:var(--muted)">Hosted by ' + esc(DB.org.name) +
        ' on Hack2skill</span><div style="flex-grow:1"></div>' +
      ['Rules','Privacy','Contact'].map(t => '<span style="font-size:12.5px;color:var(--muted)">' +
        t + '</span>').join('') + '</div>';
  },

  /* the standalone route */
  screen(p){
    return '<div style="background:var(--bg-soft);min-height:100vh;padding:0 0 40px">' +
      '<div style="display:flex;align-items:center;gap:14px;padding:12px 24px;background:#fff;' +
        'border-bottom:1px solid var(--line)">' +
      '<a class="btn" href="#/p/' + p.id + '/manage/design/preview">' + ic('back',14,2.2) +
        'Back to the canvas</a>' +
      '<span class="num" style="font-size:12px;color:var(--muted)">hack2skill.com/p/' + esc(p.slug) +
        '</span>' +
      '<span class="pill ' + (p.state === 'live' ? 'ok' : 'warn') + '">' +
        (p.state === 'live' ? 'Live' : 'Draft — not published') + '</span>' +
      '<div style="flex-grow:1"></div>' +
      '<span style="font-size:12px;color:var(--faint)">This is what a participant sees. Sections ' +
        'with no content do not appear at all.</span></div>' +
      '<div style="padding:24px"><div class="frame" style="max-width:1140px;margin:0 auto">' +
      PUB.page(p) + '</div></div></div>';
  }
};
